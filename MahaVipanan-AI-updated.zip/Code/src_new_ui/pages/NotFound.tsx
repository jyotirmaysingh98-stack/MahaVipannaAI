import { Link } from 'react-router-dom'
import { Compass } from 'lucide-react'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/States'

export function NotFoundPage() {
  return (
    <div className="grid min-h-screen place-items-center p-6">
      <div className="w-full max-w-md">
        <Logo size={40} className="mx-auto" />
        <div className="mt-6 rounded-2xl border border-line bg-surface p-6 shadow-card">
          <EmptyState
            icon={Compass}
            title="This page isn't on the map"
            description="The link may be out of date. Head back to your command center."
            action={
              <Link to="/app">
                <Button>Back to dashboard</Button>
              </Link>
            }
          />
        </div>
      </div>
    </div>
  )
}
