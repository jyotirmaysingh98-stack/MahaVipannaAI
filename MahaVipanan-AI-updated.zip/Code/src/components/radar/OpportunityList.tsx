import { LayoutGroup } from 'framer-motion'
import type { OpportunityResponse } from '@/api/types'
import { OpportunityCard } from './OpportunityCard'

/**
 * The ranked ladder. Kept in engine order (eligible-by-net desc); when a freight
 * override changes that order, LayoutGroup animates every card to its new slot —
 * the visible re-rank. Cards are keyed by buyer id so identity (and its spring)
 * follows the buyer, not the position.
 */
export function OpportunityList({
  opportunities,
  recommendedBuyerId,
  onOpenBreakdown,
}: {
  opportunities: OpportunityResponse[]
  recommendedBuyerId?: string
  onOpenBreakdown?: (o: OpportunityResponse) => void
}) {
  return (
    <LayoutGroup>
      <div className="space-y-3">
        {opportunities.map((o) => (
          <OpportunityCard
            key={o.buyer.id}
            opportunity={o}
            isRecommended={o.buyer.id === recommendedBuyerId}
            onOpenBreakdown={onOpenBreakdown}
          />
        ))}
      </div>
    </LayoutGroup>
  )
}
