from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user_optional, require_roles
from ..models.core import GovernmentScheme, User, generate_uuid
from ..schemas.core import GovernmentSchemeCreate, GovernmentSchemeResponse
from ..services.scheme_sources import OFFICIAL_SOURCES, sync_sources, compute_relevance

schemes_router = APIRouter(prefix="/api/schemes", tags=["schemes"])


@schemes_router.get("/")
def get_schemes(
    state: Optional[str] = Query(None),
    crop: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_current_user_optional),
):
    role = user.role.value if user else None
    schemes = db.query(GovernmentScheme).filter(GovernmentScheme.status == "published").order_by(GovernmentScheme.created_at.desc()).all()

    out = []
    for s in schemes:
        rel = compute_relevance(s, role=role, state=state, crop=crop)
        item = GovernmentSchemeResponse.model_validate(s).model_dump()
        item["relevance_score"] = rel["score"]
        item["relevance_label"] = rel["label"]
        out.append(item)
    out.sort(key=lambda x: x["relevance_score"], reverse=True)
    return {"success": True, "data": out}


@schemes_router.get("/sources")
def get_sources(db: Session = Depends(get_db), user: User = Depends(require_roles("government", "admin"))):
    latest = db.query(GovernmentScheme.source_key, GovernmentScheme.source_last_checked).filter(GovernmentScheme.source_key.isnot(None)).all()
    last_checked_by_key = {}
    for key, ts in latest:
        if ts and (key not in last_checked_by_key or ts > last_checked_by_key[key]):
            last_checked_by_key[key] = ts
    data = [
        {"key": k, "name": v["name"], "url": v["url"], "last_checked": last_checked_by_key.get(k)}
        for k, v in OFFICIAL_SOURCES.items()
    ]
    return {"success": True, "data": data}


@schemes_router.post("/sync")
async def sync_official_sources(db: Session = Depends(get_db), user: User = Depends(require_roles("government", "admin"))):
    results = await sync_sources(db)
    return {"success": True, "data": {"sources": results, "synced_at": max((r["checked_at"] for r in results), default=None)}}


@schemes_router.post("/")
def create_scheme(payload: GovernmentSchemeCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("government", "admin"))):
    scheme = GovernmentScheme(id=generate_uuid(), created_by_user_id=user.id, **payload.model_dump())
    db.add(scheme)
    db.commit()
    db.refresh(scheme)
    return {"success": True, "data": GovernmentSchemeResponse.model_validate(scheme)}


@schemes_router.put("/{scheme_id}")
def update_scheme(scheme_id: str, payload: GovernmentSchemeCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("government", "admin"))):
    scheme = db.query(GovernmentScheme).filter(GovernmentScheme.id == scheme_id).first()
    if not scheme:
        raise HTTPException(status_code=404, detail="Scheme not found")
    if scheme.created_by_user_id and scheme.created_by_user_id != user.id and user.role.value != "admin":
        raise HTTPException(status_code=403, detail="You can only edit schemes you published")
    for field, value in payload.model_dump().items():
        setattr(scheme, field, value)
    db.commit()
    db.refresh(scheme)
    return {"success": True, "data": GovernmentSchemeResponse.model_validate(scheme)}
