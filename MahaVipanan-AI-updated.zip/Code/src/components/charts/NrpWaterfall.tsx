import { useMemo } from 'react'
import { cn } from '@/lib/cn'
import { inr } from '@/lib/format'
import type { OpportunityResponse } from '@/api/types'

interface Step {
  key: string
  label: string
  amount: number
  kind: 'gross' | 'deduction' | 'net'
  top: number
  height: number
  overridden?: boolean
}

const TRACK = 248 // px

/**
 * The signature chart: a gross → deductions → net waterfall. Amber quoted price
 * steps down through clay-coloured cost bars to the pine net-realizable bar —
 * the one number the FPO actually keeps. Heights animate via CSS transitions,
 * so a freight override visibly pushes the transport bar down and shrinks net.
 *
 * Colour here is semantic, not categorical: every deduction is the same "cost"
 * category (one clay hue), differentiated by label — so the palette stays within
 * the validated set.
 */
export function NrpWaterfall({
  opportunity,
  className,
  compact,
}: {
  opportunity: OpportunityResponse
  className?: string
  compact?: boolean
}) {
  const gross = opportunity.breakdown.gross_price
  const net = opportunity.nrp_per_qt
  const trackH = compact ? 180 : TRACK

  const steps = useMemo<Step[]>(() => {
    const yFor = (v: number) => (1 - v / gross) * trackH
    const out: Step[] = []
    out.push({ key: 'gross', label: 'Quoted price', amount: gross, kind: 'gross', top: 0, height: trackH })
    let running = gross
    
    const d = opportunity.breakdown
    const deductions = [
      { key: 'transport', label: 'Transport', amountPerQt: d.transport_cost, overridden: opportunity.freight_override_applied },
      { key: 'loading', label: 'Loading', amountPerQt: d.loading_cost },
      { key: 'commission', label: 'Commission', amountPerQt: d.commission_amount },
      { key: 'quality', label: 'Quality', amountPerQt: d.quality_deduction },
      { key: 'misc', label: 'Misc', amountPerQt: d.misc_cost },
    ].filter(x => x.amountPerQt > 0)

    for (const ded of deductions) {
      const before = running
      const after = running - ded.amountPerQt
      out.push({
        key: ded.key,
        label: ded.label,
        amount: ded.amountPerQt,
        kind: 'deduction',
        top: yFor(before),
        height: Math.max(2, (ded.amountPerQt / gross) * trackH),
        overridden: ded.overridden,
      })
      running = after
    }
    out.push({ key: 'net', label: 'Net realizable', amount: net, kind: 'net', top: yFor(net), height: (net / gross) * trackH })
    return out
  }, [opportunity, gross, net, trackH])

  return (
    <div className={cn('w-full', className)}>
      <div className="overflow-x-auto pb-2">
        <div className="flex min-w-[520px] items-end gap-2" style={{ height: trackH + 8 }}>
          {steps.map((s, i) => (
            <div key={s.key} className="group relative flex-1" style={{ height: trackH }}>
              {/* connector from previous step's landing level */}
              {i > 0 && (
                <span
                  aria-hidden
                  className="absolute left-0 z-0 h-px w-2 -translate-x-2 bg-line-strong"
                  style={{ top: s.kind === 'net' ? s.top : s.top }}
                />
              )}
              <div
                className={cn(
                  'absolute inset-x-[15%] rounded-md transition-[top,height] duration-500 ease-spring',
                  s.kind === 'gross' && 'bg-gradient-to-b from-amber-300 to-amber-400/90',
                  s.kind === 'deduction' && 'bg-gradient-to-b from-clay-300 to-clay-500',
                  s.kind === 'net' && 'bg-gradient-to-b from-pine-400 to-pine-600 shadow-glow-pine ring-1 ring-pine-600/20',
                  s.overridden && 'ring-2 ring-teal-500 ring-offset-1 ring-offset-surface animate-pulse-ring',
                )}
                style={{ top: s.top, height: s.height }}
              />
              {/* amount label */}
              <span
                className={cn(
                  'tnum absolute inset-x-0 text-center text-[0.7rem] font-semibold transition-all duration-500',
                  s.kind === 'deduction' ? 'text-clay-600' : s.kind === 'net' ? 'text-pine-700' : 'text-amber-700',
                )}
                style={{ top: Math.max(0, s.top - 18) }}
              >
                {s.kind === 'deduction' ? `−${inr(s.amount)}` : inr(s.amount)}
              </span>
              {/* hover detail */}
              <div className="pointer-events-none absolute -top-2 left-1/2 z-20 hidden -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-lg bg-ink px-2.5 py-1.5 text-[0.7rem] font-medium text-white shadow-float group-hover:block">
                {s.label}: <span className="tnum">{s.kind === 'deduction' ? `−${inr(s.amount)}` : inr(s.amount)}</span>/qt
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* category axis */}
      <div className="flex min-w-[520px] gap-2 border-t border-line pt-2">
        {steps.map((s) => (
          <div
            key={s.key}
            className={cn(
              'flex-1 text-center text-[0.68rem] leading-tight',
              s.kind === 'net' ? 'font-semibold text-pine-700' : 'text-ink-3',
            )}
          >
            {s.label}
          </div>
        ))}
      </div>
    </div>
  )
}
