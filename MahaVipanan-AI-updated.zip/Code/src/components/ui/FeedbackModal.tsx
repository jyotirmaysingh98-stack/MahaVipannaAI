import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Star, X, CheckCircle2 } from 'lucide-react'
import { Button } from './Button'
import { api } from '@/api/client'
import { useI18n } from '@/lib/i18n'

interface FeedbackModalProps {
  isOpen: boolean
  onClose: () => void
  orderId?: string
  fromUserId: string
}

export function FeedbackModal({ isOpen, onClose, orderId, fromUserId }: FeedbackModalProps) {
  const { t } = useI18n()
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [comment, setComment] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async () => {
    if (rating === 0) {
      setError('Please select a rating')
      return
    }
    setIsSubmitting(true)
    setError('')
    try {
      const res = await api.submitFeedback({
        from_user_id: fromUserId,
        order_id: orderId,
        rating,
        comments: comment || undefined
      })
      if (res.success) {
        setSubmitted(true)
      } else {
        setError(res.error || 'Failed to submit feedback')
      }
    } catch (err: any) {
      setError(err.message || 'Network error')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClose = () => {
    setRating(0)
    setHoverRating(0)
    setComment('')
    setSubmitted(false)
    setError('')
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 backdrop-blur-sm p-4"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl bg-surface border border-line shadow-2xl p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl font-bold text-ink">
                {submitted ? t('feedback.thankYou') : t('feedback.rateExperience')}
              </h3>
              <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-surface-sunk transition-colors text-ink-3">
                <X size={18} />
              </button>
            </div>

            {submitted ? (
              <div className="text-center py-8">
                <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-pine-600/10 mb-4">
                  <CheckCircle2 size={32} className="text-pine-600" />
                </div>
                <p className="text-ink-2 text-sm">{t('feedback.submittedSuccess')}</p>
                <Button onClick={handleClose} className="mt-6 bg-pine-600 hover:bg-pine-700 text-white">
                  {t('feedback.close')}
                </Button>
              </div>
            ) : (
              <>
                {/* Star Rating */}
                <div className="mb-6">
                  <label className="text-sm font-semibold text-ink-2 mb-2 block">{t('feedback.overallRating')}</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="p-1 transition-transform hover:scale-110"
                      >
                        <Star
                          size={28}
                          className={
                            star <= (hoverRating || rating)
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-line-strong'
                          }
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Comment */}
                <div className="mb-6">
                  <label className="text-sm font-semibold text-ink-2 mb-2 block">{t('feedback.commentOpt')}</label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder={t('feedback.shareExp') as any}
                    rows={3}
                    className="w-full rounded-xl border border-line bg-surface-sunk px-4 py-3 text-sm text-ink placeholder:text-ink-3 focus:outline-none focus:ring-2 focus:ring-pine-500 resize-none"
                  />
                </div>

                {error && (
                  <div className="mb-4 p-3 text-sm rounded-lg bg-red-600/10 text-red-600 border border-red-600/20">
                    {error}
                  </div>
                )}

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={handleClose}
                    className="flex-1"
                  >
                    {t('feedback.cancel')}
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={isSubmitting || rating === 0}
                    className="flex-1 bg-pine-600 hover:bg-pine-700 text-white"
                  >
                    {isSubmitting ? t('feedback.submitting') : t('feedback.submitFeedback')}
                  </Button>
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
