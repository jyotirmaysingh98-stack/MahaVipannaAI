import { motion } from 'framer-motion'
import { cn } from '@/lib/cn'
import { pct } from '@/lib/format'
import type { OpportunityMatchScore } from '@/api/types'
import { MatchBandBadge } from '@/components/domain/badges'
import { SystemCalculatedTag } from '@/components/brand/Provenance'


/**
 * The weighted buyer-match score, opened up so the FPO sees what drives it — and
 * which input is synthetic. Net realization carries the most weight; reliability
 * is a demo signal and is labelled as such, never dressed up as a real rating.
 */
export function MatchScorePanel({ match, className }: { match: OpportunityMatchScore; className?: string }) {
  const factors = [
    { key: 'nrp', label: 'Net realization', score: match.nrp_score, weight: 0.4 },
    { key: 'qty', label: 'Quantity fit', score: match.quantity_fit_score, weight: 0.2 },
    { key: 'pay', label: 'Payment terms', score: match.payment_terms_score, weight: 0.15 },
    { key: 'qual', label: 'Quality fit', score: match.quality_fit_score, weight: 0.15 },
    { key: 'rel', label: 'Reliability', score: match.reliability_score, weight: 0.1, synthetic: true },
  ]
  const hasSynthetic = true

  return (
    <div className={cn('rounded-2xl border border-line bg-surface p-5 shadow-card', className)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-ink">Buyer match score</h3>
            <SystemCalculatedTag />
          </div>
          <p className="mt-0.5 text-xs text-ink-3">Weighted fit across five factors</p>
        </div>
        <div className="text-right">
          <div className="tnum font-display text-2xl font-bold text-ink">{match.total_score}</div>
          <MatchBandBadge band={match.label} />
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {factors.map((f, i) => (
          <div key={f.key}>
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 text-ink-2">
                {f.label}
              </span>
              <span className="tnum text-ink-3">
                <span className="font-medium text-ink-2">{pct(f.score, 0)}</span> · wt {pct(f.weight, 0)}
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-surface-sunk">
              <motion.div
                className={cn('h-full rounded-full', f.synthetic ? 'bg-amber-400' : 'bg-pine-500')}
                initial={{ width: 0 }}
                animate={{ width: `${Math.round(f.score * 100)}%` }}
                transition={{ duration: 0.6, delay: 0.05 * i, ease: [0.22, 1, 0.36, 1] }}
              />
            </div>
          </div>
        ))}
      </div>

      {hasSynthetic && (
        <p className="mt-4 border-t border-line pt-3 text-xs text-ink-3">
          Reliability is a synthetic demo signal, shown for illustration. In production it would draw on the FPO's own
          settlement history with each buyer.
        </p>
      )}
    </div>
  )
}
