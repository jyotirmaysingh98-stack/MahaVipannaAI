from typing import Optional
from ..models.core import ProduceLot, Buyer
from ..schemas.core import ItemizedBreakdown

def calculate_nrp(
    buyer: Buyer, 
    lot: ProduceLot, 
    freight_override_total: Optional[float] = None
) -> tuple[float, float, ItemizedBreakdown, bool]:
    """
    Calculates the Expected Net Realizable Price for an opportunity.
    Returns:
        nrp_per_qt, total_nrp, breakdown, freight_override_applied
    """
    # If freight_override is provided, it's typically the total cost for the truck/lot.
    # Convert it to per quintal.
    if freight_override_total is not None and lot.total_quantity_q > 0:
        transport_cost = freight_override_total / lot.total_quantity_q
        override_applied = True
    else:
        transport_cost = buyer.transport_cost_per_qt
        override_applied = False

    commission_amount = buyer.gross_price_per_qt * buyer.commission_rate
    
    nrp = (
        buyer.gross_price_per_qt 
        - transport_cost 
        - buyer.loading_cost_per_qt
        - commission_amount
        - buyer.quality_deduction_per_qt
        - buyer.misc_cost_per_qt
    )
    
    # Avoid negative total NRP
    nrp = max(nrp, 0.0)
    
    breakdown = ItemizedBreakdown(
        gross_price=buyer.gross_price_per_qt,
        transport_cost=round(transport_cost, 2),
        loading_cost=buyer.loading_cost_per_qt,
        commission_amount=round(commission_amount, 2),
        quality_deduction=buyer.quality_deduction_per_qt,
        misc_cost=buyer.misc_cost_per_qt
    )
    
    total_nrp = nrp * lot.total_quantity_q
    
    return round(nrp, 2), round(total_nrp, 2), breakdown, override_applied
