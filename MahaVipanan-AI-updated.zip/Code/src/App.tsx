import { useEffect, useState } from 'react'
import { createBrowserRouter, Navigate, useNavigate } from 'react-router-dom'
import { LandingPage } from './pages/Landing'
import { LoginPage } from './pages/Login'
import { SignupPage } from './pages/Signup'
import { DashboardPage } from './pages/Dashboard'
import { OpportunitiesPage } from './pages/Opportunities'
import { AppShell } from './components/layout/AppShell'
import { NotFoundPage } from './pages/NotFound'
import { useApp } from './state/AppContext'
import { api } from './api/client'
import { Skeleton } from './components/ui/Skeleton'

import { FarmerDashboard } from './pages/FarmerDashboard'
import { BuyerDashboard } from './pages/BuyerDashboard'
import { DeliveryDashboard } from './pages/DeliveryDashboard'
import { GovtDashboard } from './pages/GovtDashboard'
import { AdminPage } from './pages/Admin'
import SchemesPage from './pages/Schemes'

function Protected({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, fpoLoading } = useApp()
  if (fpoLoading) return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="space-y-3 w-64">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
    </div>
  )
  if (!isAuthenticated) return <Navigate to="/login" replace />
  return <>{children}</>
}

function LotListRedirect() {
  const navigate = useNavigate()
  const [error, setError] = useState(false)

  useEffect(() => {
    api.getLots()
      .then((res) => {
        const lots = res.data
        if (lots && lots.length > 0) {
          navigate(`/app/fpo/lots/${lots[0].id}`, { replace: true })
        } else {
          navigate('/app', { replace: true })
        }
      })
      .catch(() => setError(true))
  }, [navigate])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <p className="text-lg font-semibold text-ink">Could not load lots</p>
        <p className="mt-2 text-sm text-ink-3">
          Make sure the backend is running at the configured URL.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-3 py-8">
      <Skeleton className="h-8 w-56" />
      <Skeleton className="h-4 w-96" />
      <Skeleton className="mt-4 h-48 w-full rounded-2xl" />
    </div>
  )
}

function DashboardRedirect() {
  const { role } = useApp()
  if (role) return <Navigate to={role} replace />
  return <Navigate to="fpo" replace />
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { role } = useApp()
  if (role !== 'admin') return <Navigate to="/app" replace />
  return <>{children}</>
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <LandingPage />
  },
  {
    path: '/login',
    element: <LoginPage />
  },
  {
    path: '/signup',
    element: <SignupPage />
  },
  {
    path: '/app',
    element: (
      <Protected>
        <AppShell />
      </Protected>
    ),
    errorElement: <NotFoundPage />,
    children: [
      {
        index: true,
        element: <DashboardRedirect />
      },
      {
        path: 'fpo',
        element: <DashboardPage />
      },
      {
        path: 'farmer',
        element: <FarmerDashboard />
      },
      {
        path: 'buyer',
        element: <BuyerDashboard />
      },
      {
        path: 'delivery',
        element: <DeliveryDashboard />
      },
      {
        path: 'government',
        element: <GovtDashboard />
      },
      {
        path: 'admin',
        element: (
          <AdminRoute>
            <AdminPage />
          </AdminRoute>
        )
      },
      {
        path: 'fpo/lots',
        element: <LotListRedirect />
      },
      {
        path: 'fpo/lots/:lotId',
        element: <OpportunitiesPage />
      },
      {
        path: 'fpo/orders',
        element: <div className="p-8 text-center text-ink-3">Deliveries tracking coming soon</div>
      },
      {
        path: 'schemes',
        element: <SchemesPage />
      }
    ]
  },
  {
    path: '*',
    element: <NotFoundPage />
  }
])
