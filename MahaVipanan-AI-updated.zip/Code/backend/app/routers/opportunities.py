from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from ..database import get_db
from ..models.core import ProduceLot, Buyer
from ..schemas.core import FreightOverrideRequest, BuyerResponse, OpportunityResponse
from ..services.nrp_engine import calculate_nrp
from ..services.opportunity_ranker import rank_opportunities
from ..services.buyer_match import calculate_match_score
from ..services.decision_engine import generate_decision

router = APIRouter(prefix="/api/opportunities", tags=["Opportunities"])

def _process_opportunities(lot: ProduceLot, buyers: list[Buyer], freight_override: Optional[float] = None):
    ops_responses = []
    nrp_values = []
    
    # First pass: calculate NRP for all buyers to get max NRP for match scoring
    for buyer in buyers:
        nrp_per_qt, total_nrp, breakdown, override_applied = calculate_nrp(
            buyer, lot, freight_override
        )
        nrp_values.append(nrp_per_qt)
        
    # Second pass: compute match scores and build responses
    for idx, buyer in enumerate(buyers):
        nrp_per_qt = nrp_values[idx]
        
        # We need total_nrp and breakdown again, or we can just call calculate_nrp again (it's fast)
        _, total_nrp, breakdown, override_applied = calculate_nrp(buyer, lot, freight_override)
        
        match_score = calculate_match_score(buyer, lot, nrp_values, nrp_per_qt)
        
        b_res = BuyerResponse.model_validate(buyer)
        
        op = OpportunityResponse(
            buyer=b_res,
            rank=0, # placeholder, assigned by ranker
            nrp_per_qt=nrp_per_qt,
            total_nrp=total_nrp,
            breakdown=breakdown,
            match_score=match_score,
            freight_override_applied=override_applied
        )
        ops_responses.append(op)
        
    # Rank opportunities
    ranked_ops = rank_opportunities(ops_responses)
    
    # Generate decision
    decision = generate_decision(ranked_ops, hold_feasible=True)
    
    return ranked_ops, decision

@router.get("/{lot_id}", response_model=dict)
def get_opportunities(lot_id: str, db: Session = Depends(get_db)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    # For MVP demo, we fetch all seeded buyers. In real app, filter by crop compatibility
    buyers = db.query(Buyer).all()
    
    ranked_ops, decision = _process_opportunities(lot, buyers)
    
    return {
        "success": True,
        "data": {
            "opportunities": [op.model_dump() for op in ranked_ops],
            "recommendation": decision.model_dump()
        },
        "data_label": "DEMO_DATA"
    }

@router.post("/{lot_id}/recalculate", response_model=dict)
def recalculate_opportunities(
    lot_id: str, 
    request: FreightOverrideRequest, 
    db: Session = Depends(get_db)
):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    buyers = db.query(Buyer).all()
    
    # freight_override in the request is the total negotiated truck cost
    ranked_ops, decision = _process_opportunities(lot, buyers, freight_override=request.freight_cost)
    
    return {
        "success": True,
        "data": {
            "opportunities": [op.model_dump() for op in ranked_ops],
            "recommendation": decision.model_dump()
        },
        "data_label": "DEMO_DATA"
    }
