from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ..database import get_db
from ..models.core import User, UserRole
from ..schemas.core import UserLogin, UserResponse
from ..auth_utils import hash_password, verify_password, create_access_token
from pydantic import BaseModel

auth_router = APIRouter(prefix="/api/auth", tags=["auth"])

class SignupRequest(BaseModel):
    name: str
    email: str = None
    phone: str = None
    password: str
    role: UserRole

@auth_router.post("/login")
def login(payload: UserLogin, db: Session = Depends(get_db)):
    if not payload.email and not payload.phone:
        raise HTTPException(status_code=400, detail="Must provide email or phone")
        
    user = None
    if payload.email:
        user = db.query(User).filter(User.email == payload.email).first()
    elif payload.phone:
        user = db.query(User).filter(User.phone == payload.phone).first()
        
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No account was found with these credentials or invalid password."
        )
        
    token = create_access_token({"sub": user.id, "role": user.role.value})
    
    return {
        "success": True, 
        "token": token, 
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "phone": user.phone,
            "role": user.role.value
        },
        "message": "Logged in successfully."
    }

@auth_router.post("/signup")
def signup(payload: SignupRequest, db: Session = Depends(get_db)):
    if not payload.email and not payload.phone:
        raise HTTPException(status_code=400, detail="Must provide email or phone")
        
    if payload.email and db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="An account with this email already exists.")
        
    if payload.phone and db.query(User).filter(User.phone == payload.phone).first():
        raise HTTPException(status_code=400, detail="An account with this phone already exists.")
        
    hashed_pw = hash_password(payload.password)
    
    # SQLite has a NOT NULL constraint on email from the old schema
    email_to_save = payload.email if payload.email else f"{payload.phone}@no-email.local"
    
    new_user = User(
        name=payload.name,
        email=email_to_save,
        phone=payload.phone,
        password_hash=hashed_pw,
        role=payload.role
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    return {"success": True, "message": "Signed up successfully."}
