import { motion } from 'framer-motion'
import { ChevronDown, Clock, Crown, MapPin, Receipt } from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/cn'
import { days, inr, inrCompact, km, perQt } from '@/lib/format'
import { rankLayout } from '@/lib/motion'
import type { OpportunityResponse } from '@/api/types'
import { AnimatedNumber } from '@/components/ui/AnimatedNumber'
import { BuyerTypeChip, DemandIndicator, MatchBandBadge } from '@/components/domain/badges'
import { SystemCalculatedTag } from '@/components/brand/Provenance'

/**
 * One ranked buyer. The quoted price is deliberately quiet (struck through); the
 * net realizable price is the hero. On a freight override the parent reorders
 * the list and this card springs to its new position (layout animation) while
 * its net figure counts to the new value — that pairing is the demo's "flip".
 */
export function OpportunityCard({
  opportunity: o,
  isRecommended,
  onOpenBreakdown,
}: {
  opportunity: OpportunityResponse
  isRecommended?: boolean
  onOpenBreakdown?: (o: OpportunityResponse) => void
}) {
  const [open, setOpen] = useState(false)
  const leader = o.rank === 1

  const d = o.breakdown
  const deductions = [
    { key: 'transport', label: 'Transport', amountPerQt: d.transport_cost, overridden: o.freight_override_applied },
    { key: 'loading', label: 'Loading', amountPerQt: d.loading_cost },
    { key: 'commission', label: 'Commission', amountPerQt: d.commission_amount },
    { key: 'quality', label: 'Quality', amountPerQt: d.quality_deduction },
    { key: 'misc', label: 'Misc', amountPerQt: d.misc_cost },
  ].filter(x => x.amountPerQt > 0)

  return (
    <motion.div
      layout
      transition={rankLayout}
      className={cn(
        'group relative overflow-hidden rounded-2xl border bg-surface transition-shadow',
        leader
          ? 'border-pine-200 shadow-card-lg ring-1 ring-pine-500/15'
          : 'border-line shadow-card hover:shadow-card-lg',
      )}
    >
      {/* leader accent rail */}
      <span
        aria-hidden
        className={cn(
          'absolute inset-y-0 left-0 w-1',
          leader ? 'bg-gradient-to-b from-pine-400 to-pine-600' : 'bg-transparent',
        )}
      />

      <div className="p-5 pl-6">
        <div className="flex items-start justify-between gap-4">
          {/* identity */}
          <div className="flex items-start gap-3">
            <span
              className={cn(
                'grid h-9 w-9 shrink-0 place-items-center rounded-xl text-sm font-bold tnum',
                leader ? 'bg-pine-500 text-white shadow-glow-pine' : 'bg-surface-sunk text-ink-2 ring-1 ring-inset ring-line',
              )}
            >
              {leader ? <Crown size={16} strokeWidth={2.5} /> : o.rank}
            </span>
            <div>
              <h3 className="font-display text-lg font-semibold leading-tight text-ink">{o.buyer.name}</h3>
              <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                <BuyerTypeChip type={o.buyer.type} />
                <DemandIndicator level={o.buyer.demand_signal || 'MEDIUM'} />
              </div>
            </div>
          </div>
          <MatchBandBadge band={o.match_score.label} score={o.match_score.total_score} />
        </div>

        {/* the number that matters */}
        <div className="mt-4 flex items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="eyebrow text-ink-3">Net realizable</span>
              <SystemCalculatedTag />
            </div>
            <div className="mt-0.5 flex items-baseline gap-1.5">
              <AnimatedNumber
                value={o.nrp_per_qt}
                format={inr}
                className={cn('font-display text-4xl font-bold tracking-tight', leader ? 'text-pine-600' : 'text-ink')}
              />
              <span className="text-sm font-medium text-ink-3">/qt</span>
            </div>
            <p className="mt-1 text-sm text-ink-3">
              Quoted <span className="tnum text-ink-3 line-through">{perQt(o.breakdown.gross_price)}</span>
            </p>
          </div>

          <div className="text-right">
            {leader ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-pine-50 px-2.5 py-1 text-xs font-semibold text-pine-700 ring-1 ring-inset ring-pine-200">
                Highest net kept
              </span>
            ) : (
              <span className="tnum inline-flex items-center rounded-full bg-clay-50 px-2.5 py-1 text-xs font-semibold text-clay-600 ring-1 ring-inset ring-clay-100">
                Rank #{o.rank}
              </span>
            )}
            <p className="mt-2 text-xs text-ink-3">Total realization</p>
            <p className="tnum text-lg font-semibold text-ink">{inrCompact(o.total_nrp)}</p>
          </div>
        </div>

        {/* meta */}
        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-line pt-3 text-xs text-ink-2">
          <span className="inline-flex items-center gap-1.5">
            <MapPin size={13} className="text-ink-3" /> {o.buyer.location} · {km(o.buyer.distance_km)}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Clock size={13} className="text-ink-3" /> Paid in {days(o.buyer.payment_terms_days ?? 0)}
          </span>
          <button
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            className="ml-auto inline-flex items-center gap-1 rounded-lg px-2 py-1 font-medium text-ink-2 transition-colors hover:bg-black/[0.04] hover:text-ink"
          >
            Deductions
            <ChevronDown size={14} className={cn('transition-transform duration-300', open && 'rotate-180')} />
          </button>
        </div>

        {/* expandable ledger */}
        <motion.div
          initial={false}
          animate={{ height: open ? 'auto' : 0, opacity: open ? 1 : 0 }}
          transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
          className="overflow-hidden"
        >
          <dl className="mt-3 space-y-1.5 rounded-xl bg-surface-sunk/60 p-3 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-ink-2">Quoted price</dt>
              <dd className="tnum font-medium text-ink">{perQt(o.breakdown.gross_price)}</dd>
            </div>
            {deductions.map((d) => (
              <div key={d.key} className="flex items-center justify-between">
                <dt className="flex items-center gap-1.5 text-ink-2">
                  {d.label}
                  {d.overridden && (
                    <span className="rounded bg-teal-50 px-1.5 py-0.5 text-[0.62rem] font-semibold uppercase tracking-wide text-teal-700 ring-1 ring-inset ring-teal-100">
                      Override
                    </span>
                  )}
                </dt>
                <dd className="tnum font-medium text-clay-600">−{inr(d.amountPerQt)}</dd>
              </div>
            ))}
            <div className="flex items-center justify-between border-t border-line pt-1.5">
              <dt className="font-semibold text-pine-700">Net realizable</dt>
              <dd className="tnum font-semibold text-pine-700">{perQt(o.nrp_per_qt)}</dd>
            </div>
          </dl>
          {onOpenBreakdown && (
            <button
              onClick={() => onOpenBreakdown(o)}
              className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-pine-600 transition-colors hover:text-pine-700"
            >
              <Receipt size={14} /> Full breakdown &amp; waterfall
            </button>
          )}
        </motion.div>
      </div>

      {isRecommended && (
        <div className="border-t border-pine-100 bg-pine-50/60 px-6 py-2 text-xs font-medium text-pine-700">
          Recommended by the decision engine
        </div>
      )}
    </motion.div>
  )
}
