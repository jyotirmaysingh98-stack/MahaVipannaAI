"""Official government source registry + deterministic scheme matching.

Real, verified official URLs only (no fabricated links). Several of these
portals are JS-rendered / access-controlled and do not expose a public,
stable structured feed, so this module does NOT attempt aggressive HTML
scraping of them (that would be unreliable and risks violating access
controls). Instead it implements the safe strategy the project explicitly
allows: keep the official hyperlink, let a government user create/curate
scheme entries that cite it, and let "sync" mean "check the source is still
reachable and record when we last checked" rather than "guess at scraping
its markup". This is stated plainly in the API response (source_type).
"""
import logging
from datetime import datetime

import httpx
from sqlalchemy.orm import Session

from ..models.core import GovernmentScheme

logger = logging.getLogger(__name__)

OFFICIAL_SOURCES = {
    "up_emandi": {"name": "UP e-Mandi", "url": "https://emandi.up.gov.in/"},
    "enam": {"name": "e-NAM", "url": "https://enam.gov.in/"},
    "up_agri": {"name": "Uttar Pradesh Agriculture Department", "url": "https://agridarshan.up.gov.in/"},
    "pmfby": {"name": "Pradhan Mantri Fasal Bima Yojana", "url": "https://pmfby.gov.in/"},
    "myscheme": {"name": "MyScheme", "url": "https://www.myscheme.gov.in/"},
    "soil_health": {"name": "Soil Health Card", "url": "https://soilhealth.dac.gov.in/"},
}


async def sync_sources(db: Session) -> list[dict]:
    """Checks each official source is reachable and stamps the check time on
    any schemes tagged with it. Never lets one bad source break the others,
    and never fabricates 'new' schemes from unstructured HTML."""
    results = []
    now = datetime.utcnow()
    async with httpx.AsyncClient(timeout=httpx.Timeout(6.0), follow_redirects=True) as client:
        for key, src in OFFICIAL_SOURCES.items():
            status = "unreachable"
            try:
                res = await client.get(src["url"])
                status = "ok" if res.status_code < 400 else f"http_{res.status_code}"
            except Exception as e:
                logger.info(f"Source check failed for {key}: {e}")
                status = "unreachable"

            updated = (
                db.query(GovernmentScheme)
                .filter(GovernmentScheme.source_key == key)
                .update({"source_last_checked": now}, synchronize_session=False)
            )
            results.append({"key": key, "name": src["name"], "url": src["url"], "status": status, "schemes_linked": updated, "checked_at": now})
    db.commit()
    return results


def compute_relevance(scheme: GovernmentScheme, *, role: str, state: str | None, crop: str | None) -> dict:
    """Transparent, deterministic relevance score. AI never decides eligibility."""
    score = 0
    if scheme.target_role and scheme.target_role != "all":
        if role and scheme.target_role == role:
            score += 2
    else:
        score += 1  # applies to everyone

    if scheme.state and state:
        if scheme.state.strip().lower() == state.strip().lower():
            score += 2
    elif not scheme.state:
        score += 1  # no state restriction => broadly applicable

    if scheme.crops and crop:
        crop_tags = [c.strip().lower() for c in scheme.crops.split(",") if c.strip()]
        if crop.strip().lower() in crop_tags:
            score += 2
    elif not scheme.crops:
        score += 1  # no crop restriction

    if score >= 5:
        label = "Relevant to you"
    elif score >= 2:
        label = "Potentially relevant"
    else:
        label = "General scheme"
    return {"score": score, "label": label}
