import { motion } from 'framer-motion'
import { ShoppingCart, Activity, MapPin } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'

export function BuyerDashboard() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">Procurement Marketplace</h1>
        <p className="mt-1 text-ink-2">Discover lots, negotiate, and track incoming orders.</p>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-50 text-pine-600">
              <ShoppingCart size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Active Procurement</p>
              <p className="text-2xl font-bold text-ink">1,250 qt</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-indigo-50 text-indigo-600">
              <Activity size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Live Orders</p>
              <p className="text-2xl font-bold text-ink">3 In Transit</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-50 text-amber-600">
              <MapPin size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Sourcing Regions</p>
              <p className="text-2xl font-bold text-ink">4 Districts</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">Available Market Lots</h2>
          <div className="rounded-2xl border border-line bg-surface p-6 text-center">
            <p className="text-ink-2 text-sm">Marketplace listings will appear here.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
