from anthropic import Anthropic
from ..schemas.core import OpportunityResponse
from ..config import settings
import logging

logger = logging.getLogger(__name__)

EXPLANATION_TEMPLATES = {
    "SELL": "Buyer {buyer} is recommended because it offers the highest Net Realizable Price "
            "of Rs. {nrp}/q, which is Rs. {delta} more than the next best option after accounting "
            "for all transportation and commission costs."
}

def generate_ai_explanation(top: OpportunityResponse, alt: OpportunityResponse = None) -> str:
    """
    Generates a 3-sentence plain-language explanation of why the top buyer is recommended.
    Uses Anthropic Claude API if available, else falls back to a template.
    """
    if not settings.LLM_API_KEY or settings.LLM_API_KEY == "your_anthropic_api_key_here":
        return _fallback_explanation(top, alt)
        
    try:
        client = Anthropic(api_key=settings.LLM_API_KEY)
        
        prompt = f"""
You are a concise agricultural market advisor.
Given the following FPO lot and buyer ranking data, explain in exactly 3 sentences why the 
top-ranked buyer is recommended. Use only the numbers provided. Do not invent any values.

Top Buyer (Recommended): {top.buyer.name}, NRP = ₹{top.nrp_per_qt}/q
"""
        if alt:
            prompt += f"Alternative: {alt.buyer.name}, NRP = ₹{alt.nrp_per_qt}/q, Gross = ₹{alt.buyer.gross_price_per_qt}/q\n"
        
        prompt += f"Freight override applied: {top.freight_override_applied}\n"
        prompt += "Explain the recommendation in plain language for an FPO Director in Maharashtra."

        response = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=150,
            temperature=0.0, # Deterministic explanation
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        return response.content[0].text
    except Exception as e:
        logger.error(f"AI Explanation failed: {e}")
        return _fallback_explanation(top, alt)

def _fallback_explanation(top: OpportunityResponse, alt: OpportunityResponse = None) -> str:
    delta = round(top.nrp_per_qt - alt.nrp_per_qt, 2) if alt else 0.0
    return EXPLANATION_TEMPLATES["SELL"].format(
        buyer=top.buyer.name,
        nrp=top.nrp_per_qt,
        delta=delta
    )
