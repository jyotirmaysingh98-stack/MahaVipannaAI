from app.database import Base, engine, SessionLocal
from app.seed.demo_data import create_demo_data

def main():
    print("Dropping existing tables...")
    Base.metadata.drop_all(bind=engine)
    
    print("Creating tables...")
    Base.metadata.create_all(bind=engine)
    
    print("Seeding database...")
    db = SessionLocal()
    try:
        create_demo_data(db)
    finally:
        db.close()
        
if __name__ == "__main__":
    main()
