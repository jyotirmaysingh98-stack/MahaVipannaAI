import { Moon, Sun } from 'lucide-react'
import { useTheme } from '@/state/ThemeProvider'

export function ThemeToggle({ className }: { className?: string }) {
  const { theme, setTheme } = useTheme()

  return (
    <button
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      className={`p-2 rounded-full hover:bg-surface-sunk transition-colors text-ink-2 hover:text-ink ${className || ''}`}
      aria-label="Toggle theme"
    >
      {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  )
}
