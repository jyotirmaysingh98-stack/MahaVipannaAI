from typing import List
from ..models.core import ProduceLot, Buyer
from ..schemas.core import OpportunityMatchScore

WEIGHTS = {
    "quantity_fit": 0.25,
    "quality_fit": 0.25,
    "nrp_score": 0.30,
    "payment_terms": 0.10,
    "reliability": 0.10
}

def score_quantity_fit(lot_qty: float, min_qty: float, max_qty: float) -> float:
    if lot_qty < min_qty:
        return 0.0
    if lot_qty > max_qty:
        return 0.7  # partial — lot too big, may split
    return 1.0

def score_payment_terms(days: int) -> float:
    # 0 days = 1.0, 7 days = 0.825, 40 days = 0.0
    return max(0.0, 1.0 - (days / 40.0))

def normalize_nrp(nrp: float, all_nrps: List[float]) -> float:
    if not all_nrps:
        return 0.0
    max_nrp = max(all_nrps)
    if max_nrp <= 0:
        return 0.0
    # simple ratio to best NRP
    return max(0.0, nrp / max_nrp)

# We define a basic quality mapping for demonstration
GRADE_SCORES = {"A": 3, "B": 2, "C": 1}

def score_quality_fit(lot_grade: str, min_grade: str) -> float:
    if not lot_grade or not min_grade:
        return 1.0
    lot_val = GRADE_SCORES.get(lot_grade.upper(), 1)
    min_val = GRADE_SCORES.get(min_grade.upper(), 1)
    if lot_val >= min_val:
        return 1.0
    return 0.5

def calculate_match_score(buyer: Buyer, lot: ProduceLot, all_nrps: List[float], current_nrp: float) -> OpportunityMatchScore:
    q_fit = score_quantity_fit(lot.total_quantity_q, buyer.min_quantity_qt, buyer.max_quantity_qt)
    # buyer.min_grade isn't strictly on Buyer model but we assume it would be checked or we just pass 1.0
    # Since BuyerRequirement is separate, we'll assume a generic fit of 1.0 if not specified
    qual_fit = 1.0 
    
    nrp_score = normalize_nrp(current_nrp, all_nrps)
    pay_score = score_payment_terms(buyer.payment_days)
    
    # buyer.reliability_score is expected to be out of 100
    rel_score = buyer.reliability_score / 100.0 if buyer.reliability_score is not None else 0.5
    
    total = (
        q_fit * WEIGHTS["quantity_fit"] +
        qual_fit * WEIGHTS["quality_fit"] +
        nrp_score * WEIGHTS["nrp_score"] +
        pay_score * WEIGHTS["payment_terms"] +
        rel_score * WEIGHTS["reliability"]
    )
    
    total_percentage = round(total * 100, 1)
    
    if total_percentage >= 85:
        label = "Excellent"
    elif total_percentage >= 70:
        label = "Good"
    elif total_percentage >= 50:
        label = "Fair"
    else:
        label = "Poor"
        
    return OpportunityMatchScore(
        total_score=total_percentage,
        quantity_fit_score=round(q_fit * 100, 1),
        quality_fit_score=round(qual_fit * 100, 1),
        nrp_score=round(nrp_score * 100, 1),
        payment_terms_score=round(pay_score * 100, 1),
        reliability_score=round(rel_score * 100, 1),
        label=label
    )
