from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db

admin_router = APIRouter(prefix="/api/admin", tags=["admin"])

@admin_router.get("/users")
def get_users(db: Session = Depends(get_db)):
    return {"success": True, "data": []}
