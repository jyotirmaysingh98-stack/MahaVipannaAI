import { useCallback, useEffect, useState } from 'react'
import { api } from '@/api/client'
import { LotResponse, OpportunitiesData } from '@/api/types'

export interface RadarState {
  lot: LotResponse | null
  radar: OpportunitiesData | null
  loading: boolean
  error: string | null
  /** Active per-buyer freight overrides, ₹/qt. */
  overrides: Record<string, number>
  setOverride: (buyerId: string, perQt: number) => void
  clearOverride: (buyerId: string) => void
  resetOverrides: () => void
  reload: () => void
}

/**
 * Loads a lot's opportunities from the backend engine. Freight
 * overrides hit the backend's recalculate endpoint.
 */
export function useRadar(lotId: string | undefined): RadarState {
  const [lot, setLot] = useState<LotResponse | null>(null)
  const [radar, setRadar] = useState<OpportunitiesData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [overrides, setOverrides] = useState<Record<string, number>>({})

  const loadData = useCallback(async () => {
    if (!lotId) return
    setLoading(true)
    setError(null)
    try {
      const [lotRes, oppsRes] = await Promise.all([
        api.getLot(lotId),
        api.getOpportunities(lotId)
      ])
      setLot(lotRes.data!)
      setRadar(oppsRes.data!)
    } catch (err: any) {
      setError(err.message || 'Failed to load opportunities')
    } finally {
      setLoading(false)
    }
  }, [lotId])

  useEffect(() => {
    loadData()
    setOverrides({})
  }, [loadData])

  const setOverride = useCallback(async (buyerId: string, totalFreightCost: number) => {
    if (!lotId) return
    setOverrides((prev) => ({ ...prev, [buyerId]: totalFreightCost }))
    setLoading(true)
    try {
      // For the demo, we assume the override applies globally to the truck payload
      const res = await api.recalculateFreight(lotId, { freight_cost: totalFreightCost })
      setRadar(res.data!)
    } catch (err: any) {
      setError(err.message || 'Recalculation failed')
    } finally {
      setLoading(false)
    }
  }, [lotId])

  const clearOverride = useCallback((buyerId: string) => {
    setOverrides((prev) => {
      const next = { ...prev }
      delete next[buyerId]
      return next
    })
    // Revert to original
    loadData()
  }, [loadData])

  const resetOverrides = useCallback(() => {
    setOverrides({})
    loadData()
  }, [loadData])

  return {
    lot,
    radar,
    loading,
    error,
    overrides,
    setOverride,
    clearOverride,
    resetOverrides,
    reload: loadData,
  }
}
