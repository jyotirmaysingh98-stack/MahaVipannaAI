import { motion, useScroll, useTransform } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  Route,
  Sparkles,
  Truck,
  Leaf,
  BarChart3,
  ShieldCheck,
  Tractor
} from 'lucide-react'
import { inr, perQt } from '@/lib/format'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { useRef } from 'react'

const heroLot = { crop: 'Onion', totalQuantityQt: 250 }

const topGross = { buyer: 'FreshMart Retail', gross: 2100, net: 1850, rank: 5 }
const heroBest = {
  buyer: 'Nashik Exports Ltd',
  gross: 2050,
  transport: 100,
  loading: 20,
  misc: 10,
  net: 1920,
  rank: 1,
}

const steps = [
  { label: 'Quoted price', value: heroBest.gross, kind: 'gross' as const },
  { label: 'Transport', value: -heroBest.transport, kind: 'deduction' as const },
  { label: 'Loading', value: -heroBest.loading, kind: 'deduction' as const },
  { label: 'Misc costs', value: -heroBest.misc, kind: 'deduction' as const },
  { label: 'Net realizable', value: heroBest.net, kind: 'net' as const },
]

export function LandingPage() {
  const targetRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end start"]
  })

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"])
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0])

  return (
    <div className="min-h-screen bg-paper overflow-hidden">
      {/* ── Nav ── */}
      <header className="fixed top-0 w-full z-50 glass">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <Logo size={38} />
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-sm font-semibold hover:text-pine-600 transition-colors">
              Sign In
            </Link>
            <Link to="/login">
              <Button size="sm" className="shadow-float hover:shadow-glow-pine transition-shadow">
                Get Started <ArrowRight size={15} className="ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* ── Hero ── */}
      <section ref={targetRef} className="relative pt-24 pb-16 lg:pt-32 lg:pb-24 perspective-1000">
        <motion.div style={{ y, opacity }} className="absolute inset-0 -z-20">
          <div className="absolute inset-0 bg-ink/70 mix-blend-multiply z-10" />
          <img 
            src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=2070&auto=format&fit=crop" 
            alt="Agriculture Field" 
            className="w-full h-full object-cover"
          />
        </motion.div>
        
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 preserve-3d">
          {/* Copy */}
          <motion.div variants={staggerContainer} initial="hidden" animate="show" className="relative z-20 text-white">
            <motion.div variants={fadeUp}>
              <span className="inline-flex items-center gap-2 rounded-full bg-white/20 backdrop-blur-md px-4 py-1.5 text-sm font-semibold text-white ring-1 ring-inset ring-white/30 shadow-lg">
                <Leaf size={14} className="text-pine-300" /> Enterprise Intelligence for FPOs
              </span>
            </motion.div>

            <motion.h1
              variants={fadeUp}
              className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl text-white"
            >
              Find the highest realistic return —<br />
              <span className="text-pine-300">not just the highest quote.</span>
            </motion.h1>

            <motion.p variants={fadeUp} className="mt-6 max-w-lg text-lg leading-relaxed text-white/80">
              MahaVipanan AI calculates <strong className="font-semibold text-white">true net realizable price</strong> for every buyer — gross quote minus freight, commission, loading and deductions — and ranks them by what you actually keep.
            </motion.p>

            <motion.div variants={fadeUp} className="mt-8 flex flex-wrap items-center gap-4">
              <Link to="/login">
                <Button size="lg" className="bg-pine-500 hover:bg-pine-600 shadow-glow-pine">
                  Launch Command Center <ArrowRight size={17} className="ml-2" />
                </Button>
              </Link>
              <a href="#how">
                <Button variant="secondary" size="lg" className="bg-white/10 text-white hover:bg-white/20 border-white/20 backdrop-blur-md">
                  Explore Features
                </Button>
              </a>
            </motion.div>
          </motion.div>

          {/* Hero Visual — 3D Waterfall */}
          <motion.div
            initial={{ opacity: 0, rotateY: 15, rotateX: 5, z: -100 }}
            animate={{ opacity: 1, rotateY: -5, rotateX: 2, z: 0 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
            className="rounded-3xl glass-dark p-8 shadow-2xl relative preserve-3d animate-float"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="absolute -inset-0.5 bg-gradient-to-br from-pine-400 to-transparent rounded-3xl opacity-30 blur-md -z-10" />
            
            <div className="mb-6 flex items-start justify-between translate-z-20">
              <div>
                <p className="eyebrow text-pine-300">{heroBest.buyer}</p>
                <p className="font-display text-2xl font-semibold text-white">Quoted → Net Realization</p>
              </div>
            </div>

            <div className="space-y-2.5 translate-z-30">
              {steps.map((step, i) => {
                const isGross = step.kind === 'gross'
                const isDed = step.kind === 'deduction'
                const isNet = step.kind === 'net'
                const barWidth = isGross
                  ? '100%'
                  : isNet
                  ? `${(heroBest.net / heroBest.gross) * 100}%`
                  : `${(Math.abs(step.value) / heroBest.gross) * 100}%`

                return (
                  <motion.div
                    key={step.label}
                    initial={{ opacity: 0, x: -20, rotateX: -10 }}
                    animate={{ opacity: 1, x: 0, rotateX: 0 }}
                    transition={{ delay: 0.5 + i * 0.15, duration: 0.6 }}
                    className={`relative flex items-center gap-4 rounded-xl px-4 py-3 ${
                      isNet
                        ? 'bg-pine-900/80 ring-1 ring-inset ring-pine-500 shadow-glow-pine'
                        : isDed
                        ? 'bg-white/5'
                        : 'bg-amber-900/30 ring-1 ring-inset ring-amber-500/30'
                    }`}
                  >
                    <span
                      className={`w-32 shrink-0 text-sm font-medium ${
                        isNet ? 'font-semibold text-pine-300' : isDed ? 'text-white/60' : 'text-amber-300'
                      }`}
                    >
                      {step.label}
                    </span>

                    <div className="relative h-5 flex-1 overflow-hidden rounded-full bg-black/40 shadow-inner">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: barWidth }}
                        transition={{ delay: 0.8 + i * 0.1, duration: 0.8, ease: "easeOut" }}
                        className={`absolute inset-y-0 left-0 rounded-full ${
                          isNet
                            ? 'bg-gradient-to-r from-pine-400 to-pine-500 shadow-[0_0_10px_rgba(21,115,79,0.8)]'
                            : isDed
                            ? 'bg-gradient-to-r from-clay-500 to-clay-400'
                            : 'bg-gradient-to-r from-amber-400 to-amber-300'
                        }`}
                      />
                    </div>

                    <span
                      className={`tnum w-24 shrink-0 text-right text-base font-semibold ${
                        isNet ? 'text-pine-300' : isDed ? 'text-clay-300' : 'text-amber-300'
                      }`}
                    >
                      {isDed ? `−${inr(Math.abs(step.value))}` : inr(step.value)}
                    </span>
                  </motion.div>
                )
              })}
            </div>

            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 1.5, type: 'spring' }}
              className="mt-6 flex items-center justify-between rounded-xl bg-gradient-to-r from-pine-600 to-pine-500 p-4 translate-z-30 shadow-lg"
            >
              <span className="text-base font-semibold text-white">Highest Realistic Return</span>
              <span className="tnum font-display text-2xl font-bold text-white shadow-sm">{perQt(heroBest.net)}</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Feature Highlight ── */}
      <section className="relative -mt-10 z-30 px-5">
        <div className="mx-auto max-w-6xl grid md:grid-cols-3 gap-6">
          <FeatureCard 
            icon={BarChart3}
            title="Market Intelligence"
            desc="Real-time aggregation and evaluation of market opportunities mapped directly to your inventory."
            delay={0.1}
          />
          <FeatureCard 
            icon={Truck}
            title="Logistics & Freight"
            desc="Automated freight impact calculations adjusting the net realizable price live as transport costs shift."
            delay={0.2}
          />
          <FeatureCard 
            icon={ShieldCheck}
            title="Buyer Reliability"
            desc="Data-driven matching based on quality parameters, payment history, and logistical constraints."
            delay={0.3}
          />
        </div>
      </section>

      {/* ── The gross-price trap ── */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-50/40 via-paper to-paper -z-10" />
        <div className="mx-auto max-w-6xl px-5">
          <div className="mx-auto max-w-2xl text-center">
            <motion.div initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}}>
              <p className="eyebrow text-clay-600">The gross-price trap</p>
              <h2 className="mt-3 font-display text-4xl font-bold text-ink">
                The highest quote often loses.
              </h2>
              <p className="mt-4 text-lg text-ink-2">
                On this {heroLot.crop.toLowerCase()} lot, the buyer quoting the most per quintal is not
                the one that puts the most money in the pool's account.
              </p>
            </motion.div>
          </div>

          <div className="mx-auto mt-12 grid max-w-3xl gap-6 sm:grid-cols-2 perspective-1000">
            <CompareCard
              tag="Highest quoted price"
              tone="clay"
              name={topGross.buyer}
              gross={topGross.gross}
              net={topGross.net}
              rank={topGross.rank}
              delay={0.1}
            />
            <CompareCard
              tag="Highest net kept ✓"
              tone="pine"
              name={heroBest.buyer}
              gross={heroBest.gross}
              net={heroBest.net}
              rank={heroBest.rank}
              delay={0.2}
            />
          </div>
        </div>
      </section>

      {/* ── How it works ── */}
      <section id="how" className="py-24 bg-surface relative">
        <div className="mx-auto max-w-6xl px-5">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="eyebrow text-pine-600">Decision Intelligence</p>
              <h2 className="mt-3 font-display text-4xl font-bold text-ink">
                A deterministic engine decides.<br/>The AI explains.
              </h2>
              <p className="mt-4 text-lg text-ink-2">
                The recommendation comes from a deterministic formula the FPO can audit line by line.
                The AI layer never chooses — it only translates complex financials into plain words.
              </p>

              <div className="mt-8 space-y-6">
                <FeatureRow icon={Tractor} title="Farmer-First Aggregation" desc="Easily track which farmer owns which lot inside the FPO warehouse." />
                <FeatureRow icon={Route} title="Sell, Hold, or Redirect" desc="Actionable intelligence on whether to sell locally or redirect to better markets." />
                <FeatureRow icon={Sparkles} title="Conversational Insights" desc="Ask questions like 'What happens if freight increases by ₹2/kg?'" />
              </div>
            </div>

            {/* 3D Flow diagram */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, rotateY: 10 }}
              whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="glass p-8 rounded-3xl relative"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-br from-teal-400 to-pine-400 rounded-3xl opacity-20 blur -z-10" />
              <p className="mb-8 text-center text-sm font-semibold uppercase tracking-widest text-ink-3">
                Intelligence Pipeline
              </p>
              <div className="space-y-4">
                <PipelineStep num="01" title="Lot & Quality Data" highlight={false} />
                <div className="w-0.5 h-6 bg-line mx-auto" />
                <PipelineStep num="02" title="NRP Calculation Engine" highlight={true} />
                <div className="w-0.5 h-6 bg-line mx-auto" />
                <PipelineStep num="03" title="Buyer Matching & Ranking" highlight={true} />
                <div className="w-0.5 h-6 bg-line mx-auto" />
                <PipelineStep num="04" title="AI Strategic Explanation" highlight={false} isAi />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-line bg-paper py-12">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 px-5 sm:flex-row">
          <Logo size={40} />
          <p className="text-sm text-ink-3 text-center sm:text-left">
            MahaVipanan AI &copy; 2026<br/>
            Premium Agricultural Intelligence Platform
          </p>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon: Icon, title, desc, delay }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay }}
      className="glass rounded-2xl p-6 hover:shadow-glow-pine transition-all duration-300 hover:-translate-y-1 group"
    >
      <div className="h-12 w-12 rounded-xl bg-pine-50 flex items-center justify-center text-pine-600 mb-5 group-hover:scale-110 transition-transform">
        <Icon size={24} />
      </div>
      <h3 className="text-xl font-display font-semibold text-ink mb-2">{title}</h3>
      <p className="text-ink-2 leading-relaxed">{desc}</p>
    </motion.div>
  )
}

function CompareCard({ tag, tone, name, gross, net, rank, delay }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, rotateX: -10, y: 20 }}
      whileInView={{ opacity: 1, rotateX: 0, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className={`rounded-3xl border bg-surface p-6 shadow-card hover:shadow-lg transition-shadow preserve-3d ${
        tone === 'pine' ? 'border-pine-300 ring-4 ring-pine-500/10' : 'border-line'
      }`}
    >
      <div className="flex items-center justify-between mb-4">
        <span
          className={`rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wide ring-1 ring-inset ${
            tone === 'pine'
              ? 'bg-pine-100 text-pine-800 ring-pine-300'
              : 'bg-clay-50 text-clay-700 ring-clay-200'
          }`}
        >
          {tag}
        </span>
        <span className="text-sm font-semibold text-ink-3">Rank #{rank}</span>
      </div>
      <p className="font-display text-2xl font-bold text-ink mb-6">{name}</p>
      
      <div className="space-y-3 bg-surface-sunk p-4 rounded-2xl">
        <div className="flex items-center justify-between">
          <span className="text-ink-2 font-medium">Quoted</span>
          <span className="tnum text-ink-2 font-semibold text-lg">{perQt(gross)}</span>
        </div>
        <div className="flex items-center justify-between border-t border-line/50 pt-3">
          <span className="font-bold text-ink">Net Keep</span>
          <span
            className={`tnum font-black text-2xl ${tone === 'pine' ? 'text-pine-600' : 'text-clay-600'}`}
          >
            {perQt(net)}
          </span>
        </div>
      </div>
    </motion.div>
  )
}

function FeatureRow({ icon: Icon, title, desc }: any) {
  return (
    <div className="flex gap-4">
      <div className="mt-1 shrink-0 h-10 w-10 rounded-full bg-pine-100 flex items-center justify-center text-pine-600 ring-1 ring-pine-200">
        <Icon size={20} />
      </div>
      <div>
        <h4 className="font-display text-lg font-semibold text-ink">{title}</h4>
        <p className="text-ink-2 mt-1">{desc}</p>
      </div>
    </div>
  )
}

function PipelineStep({ num, title, highlight, isAi = false }: any) {
  return (
    <div className={`flex items-center gap-4 p-4 rounded-2xl border ${
      highlight ? 'bg-pine-50 border-pine-200 shadow-sm' : 
      isAi ? 'bg-indigo-50 border-indigo-200' : 'bg-surface border-line'
    }`}>
      <span className={`font-display font-bold text-xl ${
        highlight ? 'text-pine-500' : isAi ? 'text-indigo-500' : 'text-ink-3'
      }`}>{num}</span>
      <span className={`font-semibold text-lg ${
        highlight ? 'text-pine-900' : isAi ? 'text-indigo-900' : 'text-ink'
      }`}>{title}</span>
    </div>
  )
}
