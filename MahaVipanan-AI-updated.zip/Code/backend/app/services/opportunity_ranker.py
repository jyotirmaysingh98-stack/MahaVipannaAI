from typing import List
from ..schemas.core import OpportunityResponse

def rank_opportunities(opportunities: List[OpportunityResponse]) -> List[OpportunityResponse]:
    """
    Sorts opportunities by NRP descending.
    Assigns the rank property based on the sorted order.
    """
    # Sort descending by NRP per quintal
    sorted_ops = sorted(opportunities, key=lambda o: o.nrp_per_qt, reverse=True)
    
    # Assign ranks
    for index, op in enumerate(sorted_ops):
        op.rank = index + 1
        
    return sorted_ops
