import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { inr, inrCompact } from '@/lib/format'
import type { OpportunityResponse } from '@/api/types'
import { CHART } from './theme'

interface Row {
  name: string
  gross: number
  net: number
  isBest: boolean
  rank: number
}

function ChartTooltip({ active, payload }: { active?: boolean; payload?: { payload: Row }[] }) {
  if (!active || !payload?.length) return null
  const row = payload[0].payload
  const deductions = row.gross - row.net
  return (
    <div className="rounded-xl border border-line bg-surface/95 p-3 shadow-float backdrop-blur">
      <p className="mb-1.5 text-sm font-semibold text-ink">{row.name}</p>
      <dl className="tnum space-y-1 text-xs">
        <div className="flex items-center justify-between gap-6">
          <dt className="flex items-center gap-1.5 text-ink-2">
            <span className="h-2 w-2 rounded-sm" style={{ background: CHART.gross }} /> Quoted
          </dt>
          <dd className="font-medium text-ink">{inr(row.gross)}/qt</dd>
        </div>
        <div className="flex items-center justify-between gap-6">
          <dt className="text-clay-600">Deductions</dt>
          <dd className="font-medium text-clay-600">−{inr(deductions)}/qt</dd>
        </div>
        <div className="flex items-center justify-between gap-6 border-t border-line pt-1">
          <dt className="flex items-center gap-1.5 font-semibold text-pine-700">
            <span className="h-2 w-2 rounded-sm" style={{ background: CHART.net }} /> Net kept
          </dt>
          <dd className="font-semibold text-pine-700">{inr(row.net)}/qt</dd>
        </div>
      </dl>
    </div>
  )
}

/**
 * Quoted vs net realizable, per buyer. Two validated series (amber gross, pine
 * net) from a zero baseline; net values are direct-labelled and the #1 net gets
 * a rank marker — rank is shown by annotation, never by recolouring the series.
 */
export function BuyerComparisonChart({ opportunities }: { opportunities: OpportunityResponse[] }) {
  const rows: Row[] = opportunities
    .map((o) => ({
      name: o.buyer.name.replace(/\s*\(.*\)/, ''),
      gross: Math.round(o.breakdown.gross_price),
      net: Math.round(o.nrp_per_qt),
      isBest: o.rank === 1,
      rank: o.rank,
    }))

  return (
    <div>
      <div className="mb-3 flex items-center gap-4 text-xs text-ink-2">
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: CHART.gross }} /> Quoted price
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: CHART.net }} /> Net realizable
        </span>
        <span className="ml-auto text-ink-3">Bars from ₹0 · ₹/qt</span>
      </div>
      <ResponsiveContainer width="100%" height={264}>
        <BarChart data={rows} margin={{ top: 24, right: 8, left: 4, bottom: 4 }} barGap={4} barCategoryGap="28%">
          <CartesianGrid vertical={false} stroke={CHART.grid} />
          <XAxis
            dataKey="name"
            tickLine={false}
            axisLine={false}
            tick={{ fill: CHART.axis, fontSize: 12 }}
            interval={0}
          />
          <YAxis
            tickFormatter={(v) => inrCompact(v)}
            tickLine={false}
            axisLine={false}
            width={52}
            tick={{ fill: CHART.axis, fontSize: 11 }}
          />
          <Tooltip cursor={{ fill: 'rgba(21,115,79,0.05)' }} content={<ChartTooltip />} />
          <Bar dataKey="gross" fill={CHART.gross} radius={[4, 4, 0, 0]} maxBarSize={30} isAnimationActive={false} />
          <Bar dataKey="net" radius={[4, 4, 0, 0]} maxBarSize={30}>
            {rows.map((r) => (
              <Cell key={r.name} fill={CHART.net} />
            ))}
            <LabelList
              dataKey="net"
              position="top"
              formatter={(v: number) => inr(v)}
              style={{ fill: CHART.net, fontSize: 11, fontWeight: 600 }}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
