import { useState, useRef, useEffect } from 'react'
import { Globe, Check } from 'lucide-react'
import { useI18n } from '@/lib/i18n'

const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिंदी' },
  { code: 'mr', label: 'मराठी' },
  { code: 'te', label: 'తెలుగు' },
] as const

export function LanguageSelector({ className }: { className?: string }) {
  const { lang, setLang } = useI18n()
  const [isOpen, setIsOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div className={`relative ${className || ''}`} ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-2 rounded-full hover:bg-surface-sunk transition-colors text-ink-2 hover:text-ink"
        aria-label="Select Language"
      >
        <Globe size={18} />
        <span className="text-sm font-semibold uppercase">{lang}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-32 origin-top-right rounded-xl bg-surface shadow-card-lg ring-1 ring-line overflow-hidden z-50">
          <div className="py-1">
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                onClick={() => {
                  setLang(l.code)
                  setIsOpen(false)
                }}
                className={`flex w-full items-center justify-between px-4 py-2 text-sm transition-colors hover:bg-surface-sunk ${
                  lang === l.code ? 'text-pine-600 font-semibold bg-pine-50/50' : 'text-ink-2'
                }`}
              >
                {l.label}
                {lang === l.code && <Check size={14} />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
