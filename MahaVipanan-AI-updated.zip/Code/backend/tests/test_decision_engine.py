from app.services.decision_engine import generate_decision, MINIMUM_VIABLE_NRP
from app.schemas.core import OpportunityResponse, BuyerResponse, OpportunityMatchScore, ItemizedBreakdown, DecisionAction
from app.models.core import BuyerType

def _mock_op(nrp: float, name: str, is_freight_override: bool = False) -> OpportunityResponse:
    buyer = BuyerResponse(
        id="mock_id",
        name=name,
        type=BuyerType.trader,
        distance_km=10.0,
        gross_price_per_qt=nrp + 100,
        transport_cost_per_qt=10,
        loading_cost_per_qt=10,
        commission_rate=0.0,
        quality_deduction_per_qt=0,
        misc_cost_per_qt=0,
        min_quantity_qt=10,
        max_quantity_qt=100,
        reliability_score=100,
        data_label="DEMO_DATA"
    )
    breakdown = ItemizedBreakdown(
        gross_price=nrp + 100,
        transport_cost=10,
        loading_cost=10,
        commission_amount=0,
        quality_deduction=0,
        misc_cost=0
    )
    score = OpportunityMatchScore(
        total_score=90.0,
        quantity_fit_score=100.0,
        quality_fit_score=100.0,
        nrp_score=90.0,
        payment_terms_score=100.0,
        reliability_score=100.0,
        label="Excellent"
    )
    return OpportunityResponse(
        buyer=buyer,
        rank=1,
        nrp_per_qt=nrp,
        total_nrp=nrp * 10,
        breakdown=breakdown,
        match_score=score,
        freight_override_applied=is_freight_override
    )

def test_generate_decision_sell():
    top = _mock_op(2000.0, "Top Buyer")
    alt = _mock_op(1800.0, "Alt Buyer")
    
    rec = generate_decision([top, alt], hold_feasible=True)
    assert rec.action == DecisionAction.sell
    assert rec.recommended_buyer_name == "Top Buyer"
    # Delta logic: 2000 - 1800 = 200
    assert any("Rs. 200.0/q more net return" in j for j in rec.justification_points)

def test_generate_decision_hold():
    # Below minimum viable NRP
    top = _mock_op(800.0, "Top Buyer")
    
    rec = generate_decision([top], hold_feasible=True)
    assert rec.action == DecisionAction.hold
    assert rec.recommended_buyer_name is None
    assert any("below acceptable threshold" in j for j in rec.justification_points)

def test_generate_decision_redirect():
    # Below minimum viable NRP and hold not feasible
    top = _mock_op(800.0, "Top Buyer")
    
    rec = generate_decision([top], hold_feasible=False)
    assert rec.action == DecisionAction.redirect
    assert rec.recommended_buyer_name is None
    assert any("Seek alternative markets" in j for j in rec.justification_points)

def test_generate_decision_empty():
    rec = generate_decision([])
    assert rec.action == DecisionAction.hold
    assert "No matching buyer" in rec.justification_points[0]
