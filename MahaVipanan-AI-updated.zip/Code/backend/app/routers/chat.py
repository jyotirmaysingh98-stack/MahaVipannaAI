from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user_optional
from ..models.core import GovernmentScheme, User
from ..services import ai_provider

chat_router = APIRouter(prefix="/api/chat", tags=["chat"])


class ChatRequest(BaseModel):
    message: str
    lang: Optional[str] = "en"
    # Minimal optional negotiation/lot context — never send the whole app state.
    context: Optional[dict] = None


FALLBACK_REPLY = {
    "en": "I'm the MahaVipanan AI assistant. You can ask me about your lots, negotiations, schemes, or order tracking.",
    "hi": "मैं महाविपणन AI सहायक हूं। आप मुझसे अपने लॉट, बातचीत, योजनाओं या ऑर्डर ट्रैकिंग के बारे में पूछ सकते हैं।",
    "mr": "मी महाविपणन AI सहाय्यक आहे. तुम्ही मला तुमचे लॉट, वाटाघाटी, योजना किंवा ऑर्डर ट्रॅकिंगबद्दल विचारू शकता.",
    "te": "నేను మహావిపణన్ AI సహాయకుడిని. మీరు మీ లాట్‌లు, చర్చలు, పథకాలు లేదా ఆర్డర్ ట్రాకింగ్ గురించి నన్ను అడగవచ్చు.",
}


@chat_router.post("/message")
async def send_message(payload: ChatRequest, db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    lang = payload.lang or "en"
    role = user.role.value if user else "guest"

    # Scheme questions: retrieve deterministic matches instead of letting the
    # LLM invent scheme names/URLs.
    lowered = payload.message.lower()
    scheme_hint = ""
    if any(w in lowered for w in ["scheme", "subsidy", "yojana", "सब्सिडी", "योजना", "పథకం"]):
        top = db.query(GovernmentScheme).filter(GovernmentScheme.status == "published").order_by(GovernmentScheme.created_at.desc()).limit(3).all()
        if top:
            scheme_hint = " Known schemes on record: " + "; ".join(f"{s.title} ({s.official_url})" for s in top)

    prompt = f"User role: {role}. Question: {payload.message}.{scheme_hint}"
    if payload.context:
        prompt += f" Context: {payload.context}"
    system = (
        "You are the MahaVipanan AI assistant for an Indian agricultural marketplace app. "
        "Only use scheme names/URLs given to you verbatim; never invent government scheme links. "
        + ai_provider.lang_instruction(lang)
    )

    result = await ai_provider.get_ai_text(prompt, system=system, fallback=FALLBACK_REPLY.get(lang, FALLBACK_REPLY["en"]))
    return {"success": True, "data": {"reply": result["text"], "source": result["source"]}}
