import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowRight,
  BarChart3,
  CheckCircle2,
  Layers,
  Package,
  TrendingUp,
  Wheat,
  Truck,
} from 'lucide-react'
import { useApp } from '@/state/AppContext'
import { api } from '@/api/client'
import type { LotResponse } from '@/api/types'
import { qt, formatDate } from '@/lib/format'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Skeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { PredictorSimulator } from '@/components/simulator/PredictorSimulator'
import { useI18n } from '@/lib/i18n'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts'

const REVENUE_DATA = [
  { month: 'Jan', revenue: 120000 },
  { month: 'Feb', revenue: 150000 },
  { month: 'Mar', revenue: 180000 },
  { month: 'Apr', revenue: 140000 },
  { month: 'May', revenue: 220000 },
  { month: 'Jun', revenue: 280000 },
]

const RECENT_TRANSACTIONS = [
  { id: 'TRX-1092', lot: 'Onion Lot #3', buyer: 'Metro Cash & Carry', amount: 84500, status: 'Completed', date: '2026-09-02' },
  { id: 'TRX-1091', lot: 'Wheat Lot #1', buyer: 'ITC Agri', amount: 125000, status: 'In Transit', date: '2026-09-01' },
  { id: 'TRX-1090', lot: 'Tomato Lot #2', buyer: 'Local APMC', amount: 45000, status: 'Completed', date: '2026-08-28' },
]

/**
 * FPO Dashboard — landing screen after login.
 * Shows the FPO's summary stats and lists all active lots
 * so the director can navigate to any lot's Opportunity Radar.
 */
export function DashboardPage() {
  const { fpo, fpoLoading } = useApp()
  const { t } = useI18n()
  const [lots, setLots] = useState<LotResponse[]>([])
  const [lotsLoading, setLotsLoading] = useState(true)
  const [totalInventory, setTotalInventory] = useState(0)
  const [activeLots, setActiveLots] = useState(0)

  useEffect(() => {
    // Load FPO dashboard stats
    api.getDashboard()
      .then(res => {
        if (res.data) {
          setTotalInventory(res.data.total_inventory_q)
          setActiveLots(res.data.active_lots)
        }
      })
      .catch(console.error)

    // Load lots list
    api.getLots()
      .then(res => {
        if (res.data) setLots(res.data)
      })
      .catch(console.error)
      .finally(() => setLotsLoading(false))
  }, [])

  return (
    <div>
      {/* Header */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="mb-8"
      >
        <motion.div variants={fadeUp} className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="eyebrow text-pine-600">{t('fpo.title')}</p>
            {fpoLoading ? (
              <Skeleton className="mt-1 h-9 w-64" />
            ) : (
              <h1 className="mt-1 font-display text-3xl font-bold tracking-tight text-ink">
                {fpo?.name ?? t('fpo.welcomeBack')}
              </h1>
            )}
            <p className="mt-1 text-sm text-ink-3">
              {fpo?.district ? `${fpo.district} District` : t('fpo.fpoName')}
            </p>
          </div>
          <Link to="/app/delivery">
            <Button variant="outline" className="gap-2">
              <Truck size={16} /> {t('farmer.trackDeliveries')}
            </Button>
          </Link>
        </motion.div>

        {/* KPI Strip */}
        <motion.div variants={fadeUp} className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
          <StatCard
            icon={<Layers size={20} />}
            label={t('fpo.activeLots')}
            value={fpoLoading ? null : String(activeLots)}
            tone="pine"
          />
          <StatCard
            icon={<Package size={20} />}
            label={t('fpo.totalInventory')}
            value={fpoLoading ? null : qt(totalInventory)}
            tone="teal"
          />
          <StatCard
            icon={<BarChart3 size={20} />}
            label={t('fpo.intelligenceEngine')}
            value={t('fpo.online')}
            tone="indigo"
            className="col-span-2 sm:col-span-1"
          />
        </motion.div>
      </motion.div>

      {/* Simulator Section */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        className="mb-12"
      >
        <PredictorSimulator />
      </motion.div>

      {/* Lots Grid */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-ink">{t('fpo.activeLotsList')}</h2>
          <p className="text-xs text-ink-3">{t('fpo.clickToOpen')}</p>
        </div>

        {lotsLoading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map(i => (
              <Skeleton key={i} className="h-44 rounded-2xl" />
            ))}
          </div>
        ) : lots.length === 0 ? (
          <div className="rounded-2xl glass p-12 text-center">
            <Wheat size={32} className="mx-auto mb-3 text-ink-3" />
            <p className="font-semibold text-ink">{t('fpo.noLots')}</p>
            <p className="mt-1 text-sm text-ink-3">{t('fpo.seedDatabase')}</p>
          </div>
        ) : (
          <motion.div
            className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
            variants={staggerContainer}
            initial="hidden"
            animate="show"
          >
            {lots.map((lot, i) => (
              <LotCard key={lot.id} lot={lot} index={i} />
            ))}
          </motion.div>
        )}
      </div>

      {/* How to use hint */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="mt-10 rounded-2xl border border-pine-600/20 bg-gradient-to-r from-pine-600/10 to-surface p-5"
      >
        <div className="flex flex-wrap items-center gap-4">
          <TrendingUp size={20} className="shrink-0 text-pine-500" />
          <div className="flex-1">
            <p className="font-semibold text-ink">{t('fpo.radarHowWorks')}</p>
            <p className="mt-0.5 text-sm text-ink-2">
              {t('fpo.radarDesc')}
            </p>
          </div>
        </div>
      </motion.div>

      {/* Analytics & History */}
      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('fpo.revenueAnalytics')}</h2>
          <div className="rounded-2xl border border-line bg-surface p-6 shadow-sm h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={REVENUE_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" className="text-line opacity-50" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} tickFormatter={(val) => `₹${val / 1000}k`} />
                <Tooltip
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => [`₹${value.toLocaleString('en-IN')}`, t('fpo.revenue')]}
                />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('fpo.recentTransactions')}</h2>
          <div className="rounded-2xl border border-line bg-surface overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-sunk text-ink-3">
                  <tr>
                    <th className="px-4 py-3 font-medium">{t('fpo.trxID')}</th>
                    <th className="px-4 py-3 font-medium">{t('fpo.trxLotBuyer')}</th>
                    <th className="px-4 py-3 font-medium text-right">{t('fpo.trxAmount')}</th>
                    <th className="px-4 py-3 font-medium">{t('fpo.trxStatus')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {RECENT_TRANSACTIONS.map((trx) => (
                    <tr key={trx.id} className="transition-colors hover:bg-surface-sunk/50">
                      <td className="px-4 py-3 text-ink-3">{trx.id}</td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-ink">{trx.lot}</div>
                        <div className="text-ink-3 text-xs">{trx.buyer}</div>
                      </td>
                      <td className="px-4 py-3 text-right font-medium text-ink">₹{trx.amount.toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                          trx.status === 'Completed' ? 'bg-pine-600/10 text-pine-600' : 'bg-amber-600/10 text-amber-600'
                        }`}>
                          {t(`status.${trx.status.toLowerCase().replace(' ', '_')}`) || trx.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function LotCard({ lot, index }: { lot: LotResponse; index: number }) {
  const { t } = useI18n()
  const statusColor =
    lot.status === 'ready'
      ? 'bg-pine-600/10 text-pine-600 ring-pine-600/20'
      : lot.status === 'sold'
      ? 'bg-surface-sunk text-ink-3 ring-line'
      : 'bg-amber-600/10 text-amber-600 ring-amber-600/20'

  return (
    <motion.div
      variants={fadeUp}
      custom={index}
      transition={{ delay: index * 0.05 }}
    >
      <Link
        to={`/app/fpo/lots/${lot.id}`}
        className="group block rounded-2xl glass p-5 shadow-card transition-all hover:shadow-glow-pine focus-visible:outline-pine-500"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-pine-600/10 text-pine-600 ring-1 ring-inset ring-pine-600/20">
            <Wheat size={20} />
          </div>
          <span className={`mt-0.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${statusColor}`}>
            {t(`status.${lot.status}`) || lot.status}
          </span>
        </div>

        <h3 className="mt-3 font-display text-xl font-bold text-ink">{lot.crop_name}</h3>
        <p className="tnum mt-0.5 text-sm font-semibold text-pine-600">{qt(lot.total_quantity_q)}</p>

        <div className="mt-3 space-y-1 text-xs text-ink-3">
          {lot.harvest_date && (
            <p>{t('fpo.harvested')}{formatDate(lot.harvest_date)}</p>
          )}
          {lot.members.length > 0 && (
            <div className="flex flex-col gap-1">
              <p className="flex items-center gap-1.5">
                <CheckCircle2 size={12} className="text-pine-400" />
                {lot.members.length}{lot.members.length !== 1 ? t('fpo.members') : t('fpo.member')} · {lot.members[0]?.grade ?? t('fpo.gradeA')}
              </p>
              <p className="pl-4.5 text-[11px] text-ink-3 truncate" title={lot.members.map(m => m.member_name).join(', ')}>
                {t('fpo.farmers')}{lot.members.map(m => m.member_name).slice(0, 3).join(', ')}{lot.members.length > 3 ? ', ...' : ''}
              </p>
            </div>
          )}
        </div>

        <div className="mt-4 flex items-center gap-1.5 text-sm font-medium text-pine-600 opacity-0 transition-opacity group-hover:opacity-100">
          {t('fpo.openRadar')} <ArrowRight size={14} />
        </div>
      </Link>
    </motion.div>
  )
}

function StatCard({
  icon,
  label,
  value,
  tone,
  className,
}: {
  icon: React.ReactNode
  label: string
  value: string | null
  tone: 'pine' | 'teal' | 'indigo'
  className?: string
}) {
  const colors = {
    pine: 'bg-pine-600/10 text-pine-600 ring-pine-600/20',
    teal: 'bg-teal-600/10 text-teal-600 ring-teal-600/20',
    indigo: 'bg-indigo-600/10 text-indigo-600 ring-indigo-600/20',
  }
  return (
    <div className={`rounded-2xl glass p-5 shadow-card ${className ?? ''}`}>
      <span className={`grid h-10 w-10 place-items-center rounded-xl ring-1 ring-inset ${colors[tone]}`}>
        {icon}
      </span>
      <p className="mt-3 text-xs font-medium text-ink-3">{label}</p>
      {value === null ? (
        <Skeleton className="mt-1 h-7 w-24" />
      ) : (
        <p className="tnum mt-0.5 font-display text-2xl font-bold text-ink">{value}</p>
      )}
    </div>
  )
}
