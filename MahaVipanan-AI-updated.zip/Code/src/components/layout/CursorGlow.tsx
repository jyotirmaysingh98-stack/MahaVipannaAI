import { useEffect, useRef } from 'react'
import { useReducedMotion } from '@/lib/hooks'

/**
 * Ambient cursor-follow glow at the page level. Very low opacity — atmosphere,
 * not decoration. Disabled entirely under reduced-motion and on touch.
 */
export function CursorGlow() {
  const ref = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()

  useEffect(() => {
    if (reduce) return
    if (window.matchMedia('(pointer: coarse)').matches) return
    let raf = 0
    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        const el = ref.current
        if (el) {
          el.style.setProperty('--cx', `${e.clientX}px`)
          el.style.setProperty('--cy', `${e.clientY}px`)
        }
      })
    }
    window.addEventListener('mousemove', onMove)
    return () => {
      window.removeEventListener('mousemove', onMove)
      cancelAnimationFrame(raf)
    }
  }, [reduce])

  if (reduce) return null

  return (
    <div
      ref={ref}
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0"
      style={{
        background:
          'radial-gradient(340px circle at var(--cx, 50%) var(--cy, 20%), rgba(21,115,79,0.05), transparent 65%)',
      }}
    />
  )
}
