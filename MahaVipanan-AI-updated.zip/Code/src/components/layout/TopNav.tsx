import { LayoutDashboard, Layers, Menu, LogOut, X, Truck, Landmark, Moon, Sun, Handshake } from 'lucide-react'
import { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { cn } from '@/lib/cn'
import { useApp, type UserRole } from '@/state/AppContext'
import { useI18n } from '@/lib/i18n'
import { useTheme } from '@/state/ThemeProvider'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { LanguageSelector } from '@/components/ui/LanguageSelector'
import { useNegotiationUI } from '@/state/NegotiationContext'

const getRoleNav = (role: UserRole) => {
  switch (role) {
    case 'farmer':
      return [
        { to: '/app/farmer', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { action: 'negotiation', labelKey: 'nav.negotiation', icon: Handshake },
        { to: '/app/schemes', labelKey: 'nav.schemes', icon: Landmark, end: false },
      ]
    case 'buyer':
      return [
        { to: '/app/buyer', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { action: 'negotiation', labelKey: 'nav.negotiation', icon: Handshake },
      ]
    case 'delivery':
      return [
        { to: '/app/delivery', labelKey: 'nav.dashboard', icon: Truck, end: true },
      ]
    case 'government':
      return [
        { to: '/app/government', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/schemes', labelKey: 'nav.schemes', icon: Landmark, end: false },
      ]
    case 'admin':
      return [
        { to: '/app/admin', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
      ]
    case 'fpo':
    default:
      return [
        { to: '/app/fpo', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/fpo/lots', labelKey: 'nav.lots', icon: Layers, end: false },
        { action: 'negotiation', labelKey: 'nav.negotiation', icon: Handshake },
        { to: '/app/fpo/orders', labelKey: 'nav.deliveries', icon: Truck, end: false },
        { to: '/app/schemes', labelKey: 'nav.schemes', icon: Landmark, end: false },
      ]
  }
}

function NavItem({ to, labelKey, icon: Icon, end, action }: any) {
  const { t } = useI18n()
  const { openNegotiation } = useNegotiationUI()

  if (action === 'negotiation') {
    return (
      <button
        onClick={() => openNegotiation()}
        className="group relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-ink-2 transition-colors hover:text-ink"
      >
        <Icon size={16} strokeWidth={2} className="text-ink-3" />
        {t(labelKey as any)}
      </button>
    )
  }

  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'group relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
          isActive ? 'text-pine-700' : 'text-ink-2 hover:text-ink',
        )
      }
    >
      {({ isActive }) => (
        <>
          <Icon size={16} strokeWidth={2} className={isActive ? 'text-pine-500' : 'text-ink-3'} />
          {t(labelKey as any)}
          {isActive && <span className="absolute inset-x-2 -bottom-[13px] h-0.5 rounded-full bg-pine-500" />}
        </>
      )}
    </NavLink>
  )
}

export function TopNav() {
  const { fpo, role, logout } = useApp()
  const { t } = useI18n()
  const { theme, setTheme } = useTheme()
  const navigate = useNavigate()
  const { openNegotiation } = useNegotiationUI()
  const [open, setOpen] = useState(false)

  const navItems = getRoleNav(role)

  const onLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="sticky top-0 z-40 border-b border-line/80 bg-paper/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center gap-4 px-4 sm:px-6">
        <NavLink to={`/app/${role || 'fpo'}`} className="shrink-0" aria-label="MahaVipanan AI — Dashboard">
          <Logo size={38} />
        </NavLink>

        <nav className="ml-6 hidden items-center gap-1 md:flex">
          {navItems.map((item) => (
            <NavItem key={item.to} {...item} />
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <LanguageSelector className="hidden md:block" />

          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="hidden h-10 w-10 place-items-center rounded-xl text-ink-3 transition-colors hover:bg-black/5 hover:text-ink md:grid"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          <div className="hidden text-right lg:block">
            <p className="text-sm font-semibold leading-tight text-ink uppercase tracking-wider">{role || 'FPO'}</p>
            <p className="text-xs leading-tight text-ink-3">
              {role === 'fpo' && fpo ? fpo.name : 'MahaVipanan AI'}
            </p>
          </div>
          <button
            onClick={onLogout}
            className="hidden h-10 w-10 place-items-center rounded-xl text-ink-3 transition-colors hover:bg-black/5 hover:text-ink md:grid"
            aria-label="Sign out"
            title="Sign out"
          >
            <LogOut size={18} />
          </button>
          <button
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-xl text-ink-2 hover:bg-black/5 md:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-paper px-4 py-3 md:hidden">
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => item.action === 'negotiation' ? (
              <button
                key="negotiation"
                onClick={() => { setOpen(false); openNegotiation() }}
                className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium text-ink-2"
              >
                <item.icon size={17} />
                {t(item.labelKey as any)}
              </button>
            ) : (
              <NavLink
                key={item.to}
                to={item.to!}
                end={item.end}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium',
                    isActive ? 'bg-pine-50 text-pine-700' : 'text-ink-2',
                  )
                }
              >
                <item.icon size={17} />
                {t(item.labelKey as any)}
              </NavLink>
            ))}
            <div className="flex gap-2 mt-2">
              <Button variant="ghost" className="justify-start flex-1" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
                {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />} Theme
              </Button>
              <Button variant="ghost" className="justify-start flex-1" onClick={onLogout}>
                <LogOut size={17} /> {t('nav.logout')}
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
