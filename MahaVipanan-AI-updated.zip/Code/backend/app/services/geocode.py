"""Deterministic demo coordinates for order tracking. Real GPS integration
would replace this with an actual geocoding adapter; textual location names
are never treated as if they were coordinates (see Feature 4 requirement)."""
import hashlib

CITY_COORDS = {
    "Nashik": (19.9975, 73.7898),
    "Mumbai": (19.0760, 72.8777),
    "Pune": (18.5204, 73.8567),
    "Vashi": (19.0771, 73.0000),
    "Satara": (17.6805, 74.0183),
    "Lucknow": (26.8467, 80.9462),
    "Kanpur": (26.4499, 80.3319),
    "Nagpur": (21.1458, 79.0882),
}

ROUTE_PAIRS = [
    ("Nashik", "Mumbai"),
    ("Pune", "Satara"),
    ("Lucknow", "Kanpur"),
    ("Nashik", "Pune"),
]


def demo_route_for(order_id: str):
    """Deterministically picks a route + midpoint for a given order id, so
    the same order always renders the same demo path."""
    idx = int(hashlib.sha1(order_id.encode()).hexdigest(), 16) % len(ROUTE_PAIRS)
    origin_name, dest_name = ROUTE_PAIRS[idx]
    o_lat, o_lng = CITY_COORDS[origin_name]
    d_lat, d_lng = CITY_COORDS[dest_name]
    mid = ((o_lat + d_lat) / 2, (o_lng + d_lng) / 2)
    return [
        {"location": f"{origin_name} (pickup point)", "lat": o_lat, "lng": o_lng, "status": "pickup"},
        {"location": "En route", "lat": mid[0], "lng": mid[1], "status": "in_transit"},
        {"location": f"{dest_name} (destination)", "lat": d_lat, "lng": d_lng, "status": "delivered"},
    ]
