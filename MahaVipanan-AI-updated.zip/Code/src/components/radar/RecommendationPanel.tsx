import { motion } from 'framer-motion'
import { Check, Sparkles } from 'lucide-react'

import { inrCompact, perQt } from '@/lib/format'
import type { DecisionRecommendation, OpportunityResponse } from '@/api/types'
import { Button } from '@/components/ui/Button'
import { AnimatedNumber } from '@/components/ui/AnimatedNumber'
import { RecommendationPill } from '@/components/domain/badges'
import { AiExplainedTag, SystemCalculatedTag } from '@/components/brand/Provenance'

/**
 * The decision, and the honest seam that defines the product: the engine
 * CALCULATES the recommendation and the rationale bullets; the AI layer only
 * EXPLAINS them in words. The two are visibly different surfaces so no one
 * mistakes the narration for the decision-maker.
 */
export function RecommendationPanel({
  recommendation,
  bestOpportunity: best,
  onRecord,
  recordedBuyerName,
}: {
  recommendation: DecisionRecommendation
  bestOpportunity?: OpportunityResponse
  onRecord?: () => void
  recordedBuyerName?: string
}) {

  return (
    <motion.div
      layout
      className="relative overflow-hidden rounded-2xl border border-pine-200 bg-gradient-to-br from-pine-50/80 via-surface to-surface shadow-card-lg"
    >
      <div className="p-6">
        <div className="flex flex-wrap items-center gap-3">
          <RecommendationPill recommendation={recommendation.action.toUpperCase() as any} size="lg" />
          <SystemCalculatedTag className="ml-auto" />
        </div>

        <div className="mt-5 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm text-ink-2">Best net realization — {best?.buyer.name}</p>
            <div className="mt-1 flex items-baseline gap-1.5">
              <AnimatedNumber
                value={best?.nrp_per_qt || 0}
                format={perQt}
                className="font-display text-5xl font-bold tracking-tight text-pine-600"
              />
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-ink-2">Pool realizes</p>
            <p className="tnum font-display text-2xl font-bold text-ink">{inrCompact(best?.total_nrp || 0)}</p>
          </div>
        </div>

        {/* rationale — calculated */}
        <ul className="mt-5 space-y-2">
          {recommendation.justification_points.map((p, i) => (
            <li key={i} className="flex gap-2.5 text-sm text-ink-2">
              <Check size={16} className="mt-0.5 shrink-0 text-pine-500" strokeWidth={2.5} />
              <span>{p}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* explanation — a distinct surface, explicitly the AI layer */}
      <div className="border-t border-indigo-100 bg-indigo-50/40 p-6">
        <div className="mb-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-sm font-semibold text-indigo-700">
            <Sparkles size={15} /> In plain words
          </span>
          <AiExplainedTag />
        </div>
        <p className="text-sm leading-relaxed text-ink-2">{recommendation.ai_explanation}</p>
        <p className="mt-2 text-xs text-ink-3">
          The AI wrote this explanation. It did not choose the recommendation — the engine above did.
        </p>
      </div>

      {onRecord && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line bg-surface/80 p-4 px-6">
          {recordedBuyerName ? (
            <p className="inline-flex items-center gap-2 text-sm font-medium text-pine-700">
              <Check size={16} strokeWidth={2.5} /> Decision recorded — {recordedBuyerName}
            </p>
          ) : (
            <p className="text-sm text-ink-3">Recording keeps an audit trail of what the pool decided.</p>
          )}
          <Button onClick={onRecord} variant={recordedBuyerName ? 'secondary' : 'primary'}>
            {recordedBuyerName ? 'Update decision' : 'Record decision'}
          </Button>
        </div>
      )}
    </motion.div>
  )
}
