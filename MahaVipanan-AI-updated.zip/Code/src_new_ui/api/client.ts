import {
  ApiEnvelope,
  FpoDashboard,
  LotResponse,
  LotCreatePayload,
  OpportunitiesData,
  RecalculatePayload
} from './types'

// Use environment variable or fallback to localhost for development
const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000'

class ApiError extends Error {
  constructor(public message: string, public status?: number) {
    super(message)
    this.name = 'ApiError'
  }
}

async function request<T>(endpoint: string, options?: RequestInit): Promise<ApiEnvelope<T>> {
  const url = `${BASE_URL}${endpoint}`
  
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {})
      }
    })

    const data = await response.json()

    if (!response.ok || !data.success) {
      throw new ApiError(data.error || 'An error occurred', response.status)
    }

    return data as ApiEnvelope<T>
  } catch (error) {
    if (error instanceof ApiError) throw error
    throw new ApiError('Network error or backend unavailable')
  }
}

export const api = {
  getDashboard: () => request<FpoDashboard>('/api/fpo/dashboard'),
  
  getLots: () => request<LotResponse[]>('/api/lots/'),
  
  getLot: (id: string) => request<LotResponse>(`/api/lots/${id}`),
  
  createLot: (payload: LotCreatePayload) => 
    request<LotResponse>('/api/lots/', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
    
  getOpportunities: (lotId: string) => 
    request<OpportunitiesData>(`/api/opportunities/${lotId}`),
    
  recalculateFreight: (lotId: string, payload: RecalculatePayload) =>
    request<OpportunitiesData>(`/api/opportunities/${lotId}/recalculate`, {
      method: 'POST',
      body: JSON.stringify(payload)
    })
}
