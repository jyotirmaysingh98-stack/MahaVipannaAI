import { Radio } from 'lucide-react'

/**
 * Persistent honesty strip. The demo runs on synthetic data; say so plainly and
 * everywhere (FR-030/031). Kept slim so it never competes with the content.
 */
export function DemoModeBanner() {
  return (
    <div className="border-b border-amber-200/70 bg-amber-50/80 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1400px] items-center gap-2 px-4 py-1.5 text-[0.72rem] font-medium text-amber-700 sm:px-6">
        <Radio size={13} className="shrink-0" />
        <span>
          Offline demo — every price, buyer and score shown is <strong className="font-semibold">synthetic sample data</strong>,
          not live market data.
        </span>
      </div>
    </div>
  )
}
