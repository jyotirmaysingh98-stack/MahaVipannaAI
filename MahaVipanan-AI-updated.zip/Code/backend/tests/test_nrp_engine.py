from app.services.nrp_engine import calculate_nrp
from app.models.core import Buyer, ProduceLot, Crop, FPO

def test_calculate_nrp_basic():
    # Setup dummy objects
    lot = ProduceLot(total_quantity_q=50.0)
    buyer = Buyer(
        gross_price_per_qt=2000.0,
        transport_cost_per_qt=100.0,
        loading_cost_per_qt=10.0,
        commission_rate=0.05, # 5% = 100
        quality_deduction_per_qt=0.0,
        misc_cost_per_qt=0.0
    )
    
    # calculation: 2000 - 100 - 10 - 100(comm) - 0 - 0 = 1790
    nrp_per_q, total_nrp, breakdown, override = calculate_nrp(buyer, lot)
    
    assert nrp_per_q == 1790.0
    assert total_nrp == 1790.0 * 50.0
    assert not override
    assert breakdown.commission_amount == 100.0

def test_calculate_nrp_freight_override():
    lot = ProduceLot(total_quantity_q=50.0)
    buyer = Buyer(
        gross_price_per_qt=2000.0,
        transport_cost_per_qt=100.0,
        loading_cost_per_qt=10.0,
        commission_rate=0.05,
        quality_deduction_per_qt=0.0,
        misc_cost_per_qt=0.0
    )
    
    # 5000 total freight / 50q = 100 per q (so it shouldn't change NRP from above, just override flag)
    # let's use 2500 total freight -> 50 per q
    # calculation: 2000 - 50 - 10 - 100 - 0 - 0 = 1840
    nrp_per_q, total_nrp, breakdown, override = calculate_nrp(buyer, lot, freight_override_total=2500.0)
    
    assert override is True
    assert nrp_per_q == 1840.0
    assert total_nrp == 1840.0 * 50.0
    assert breakdown.transport_cost == 50.0
