import hashlib
import os
import json
import base64
import hmac
import time
from typing import Dict, Any

from .config import settings

def hash_password(password: str, salt: bytes = None) -> str:
    if salt is None:
        salt = os.urandom(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
    return base64.b64encode(salt + hashed).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        decoded = base64.b64decode(hashed_password)
        salt = decoded[:16]
        stored_hash = decoded[16:]
        check_hash = hashlib.pbkdf2_hmac('sha256', plain_password.encode('utf-8'), salt, 100000)
        return hmac.compare_digest(stored_hash, check_hash)
    except Exception:
        return False

def create_access_token(data: dict) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    payload = data.copy()
    payload["exp"] = int(time.time()) + (24 * 60 * 60) # 24 hours expiry
    
    encoded_header = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip("=")
    encoded_payload = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    
    signature = hmac.new(
        settings.SECRET_KEY.encode(),
        f"{encoded_header}.{encoded_payload}".encode(),
        hashlib.sha256
    ).digest()
    
    encoded_signature = base64.urlsafe_b64encode(signature).decode().rstrip("=")
    return f"{encoded_header}.{encoded_payload}.{encoded_signature}"

def verify_access_token(token: str) -> Dict[str, Any]:
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        
        signature = hmac.new(
            settings.SECRET_KEY.encode(),
            f"{parts[0]}.{parts[1]}".encode(),
            hashlib.sha256
        ).digest()
        
        expected_signature = base64.urlsafe_b64encode(signature).decode().rstrip("=")
        
        if not hmac.compare_digest(parts[2], expected_signature):
            return None
            
        payload = json.loads(base64.urlsafe_b64decode(parts[1] + "==").decode())
        if payload.get("exp", 0) < time.time():
            return None
            
        return payload
    except Exception:
        return None
