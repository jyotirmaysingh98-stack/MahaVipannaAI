import type { HTMLAttributes, ReactNode } from 'react'
import { cn } from '@/lib/cn'

type Tone = 'neutral' | 'pine' | 'amber' | 'clay' | 'teal' | 'indigo'

const tones: Record<Tone, string> = {
  neutral: 'bg-surface-sunk text-ink-2 ring-line-strong',
  pine: 'bg-pine-50 text-pine-700 ring-pine-200',
  amber: 'bg-amber-50 text-amber-700 ring-amber-200',
  clay: 'bg-clay-50 text-clay-600 ring-clay-100',
  teal: 'bg-teal-50 text-teal-700 ring-teal-100',
  indigo: 'bg-indigo-100 text-indigo-600 ring-indigo-100',
}

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: Tone
  icon?: ReactNode
}

export function Badge({ tone = 'neutral', icon, className, children, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset',
        tones[tone],
        className,
      )}
      {...props}
    >
      {icon}
      {children}
    </span>
  )
}
