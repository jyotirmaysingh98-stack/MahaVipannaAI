import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api } from '@/api/client'
import type { Fpo } from '@/api/types'
import { ToastProvider } from '@/components/ui/Toast'

export type UserRole = 'farmer' | 'fpo' | 'buyer' | 'government' | 'admin' | 'delivery' | null

interface AppState {
  fpo: Fpo | null
  fpoLoading: boolean
  isAuthenticated: boolean
  role: UserRole
  userId: string | null
  userName: string | null
  login: (selectedRole: UserRole, token?: string, userId?: string, userName?: string) => void
  logout: () => void
}

const AppContext = createContext<AppState | null>(null)

export function useApp(): AppState {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}

const AUTH_KEY = 'mv.session.v1'
const ROLE_KEY = 'mv.role.v1'
const USER_ID_KEY = 'mv.userId.v1'
const USER_NAME_KEY = 'mv.userName.v1'

export function AppProvider({ children }: { children: ReactNode }) {
  const [fpo, setFpo] = useState<Fpo | null>(null)
  const [fpoLoading, setFpoLoading] = useState(true)
  
  const [isAuthenticated, setAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(AUTH_KEY) === '1'
    } catch {
      return false
    }
  })

  const [role, setRole] = useState<UserRole>(() => {
    try {
      return (sessionStorage.getItem(ROLE_KEY) as UserRole) || null
    } catch {
      return null
    }
  })

  const [userId, setUserId] = useState<string | null>(() => {
    try { return sessionStorage.getItem(USER_ID_KEY) } catch { return null }
  })
  const [userName, setUserName] = useState<string | null>(() => {
    try { return sessionStorage.getItem(USER_NAME_KEY) } catch { return null }
  })

  useEffect(() => {
    let alive = true
    api
        .getDashboard()
        .then((res: any) => {
          if (alive) {
            setFpo(res.data.fpo)
          }
        })
        .catch(console.error)
        .finally(() => alive && setFpoLoading(false))
  }, [])

  const login = useCallback((selectedRole: UserRole, token?: string, uid?: string, uname?: string) => {
    setAuthenticated(true)
    setRole(selectedRole)
    if (uid) setUserId(uid)
    if (uname) setUserName(uname)
    try {
      sessionStorage.setItem(AUTH_KEY, '1')
      sessionStorage.setItem(ROLE_KEY, selectedRole || 'fpo')
      if (token) sessionStorage.setItem('mv.auth.token', token)
      if (uid) sessionStorage.setItem(USER_ID_KEY, uid)
      if (uname) sessionStorage.setItem(USER_NAME_KEY, uname)
    } catch {
      /* non-fatal */
    }
  }, [])

  const logout = useCallback(() => {
    setAuthenticated(false)
    setRole(null)
    setUserId(null)
    setUserName(null)
    try {
      sessionStorage.removeItem(AUTH_KEY)
      sessionStorage.removeItem(ROLE_KEY)
      sessionStorage.removeItem('mv.auth.token')
      sessionStorage.removeItem(USER_ID_KEY)
      sessionStorage.removeItem(USER_NAME_KEY)
    } catch {
      /* non-fatal */
    }
  }, [])

  const value = useMemo<AppState>(
    () => ({ fpo, fpoLoading, isAuthenticated, role, userId, userName, login, logout }),
    [fpo, fpoLoading, isAuthenticated, role, userId, userName, login, logout],
  )

  return (
    <AppContext.Provider value={value}>
      <ToastProvider>{children}</ToastProvider>
    </AppContext.Provider>
  )
}
