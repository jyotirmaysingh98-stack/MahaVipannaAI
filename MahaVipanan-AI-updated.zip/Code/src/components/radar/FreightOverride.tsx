import { motion } from 'framer-motion'
import { RotateCcw, Truck } from 'lucide-react'
import { useEffect, useState } from 'react'
import { cn } from '@/lib/cn'
import { inr, perQt, qt as fmtQt } from '@/lib/format'
import type { OpportunityResponse } from '@/api/types'
import { Field, Select } from '@/components/ui/Field'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { SystemCalculatedTag } from '@/components/brand/Provenance'

type Mode = 'perqt' | 'total'

/**
 * "Correct the freight" — the interaction the whole demo turns on. The model's
 * freight is only an estimate; the FPO knows the real transporter quote. Enter
 * it here and the engine re-ranks instantly. Entry is ₹/qt or whole-truck cost
 * ÷ lot quantity (SRS FR-018).
 */
export function FreightOverride({
  opportunities,
  lotQtyQt,
  overrides,
  setOverride,
  clearOverride,
}: {
  opportunities: OpportunityResponse[]
  lotQtyQt: number
  overrides: Record<string, number>
  setOverride: (buyerId: string, perQt: number) => void
  clearOverride: (buyerId: string) => void
}) {
  const eligible = opportunities
  const [buyerId, setBuyerId] = useState(eligible[0]?.buyer.id ?? '')
  const [mode, setMode] = useState<Mode>('perqt')

  const selected = opportunities.find((o) => o.buyer.id === buyerId) ?? eligible[0]
  const estimate = selected?.buyer.transport_cost_per_qt ?? 0
  const active = selected ? overrides[selected.buyer.id] : undefined
  const currentPerQt = active ?? estimate

  const [draft, setDraft] = useState<number>(currentPerQt)
  useEffect(() => setDraft(active ?? estimate), [buyerId, active, estimate])

  if (!selected) return null

  const max = Math.max(200, Math.ceil((estimate * 2.4) / 10) * 10)
  const isOverridden = active !== undefined && Math.round(active) !== Math.round(estimate)
  const delta = Math.round(currentPerQt - estimate)

  const commit = (perQtValue: number) => {
    const clamped = Math.max(0, Math.round(perQtValue))
    setDraft(clamped)
    setOverride(selected.buyer.id, clamped)
  }

  return (
    <div className="relative overflow-hidden rounded-2xl border border-teal-100 bg-gradient-to-b from-teal-50/70 to-surface p-5 shadow-card">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-teal-500 text-white shadow-glow-teal">
            <Truck size={17} />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-ink">Correct the freight</h3>
            <p className="text-xs text-ink-3">Real transporter cost overrides the estimate</p>
          </div>
        </div>
        <SystemCalculatedTag />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Select
          label="Buyer to correct"
          value={buyerId}
          onChange={(e) => setBuyerId(e.target.value)}
        >
          {eligible.map((o) => (
            <option key={o.buyer.id} value={o.buyer.id}>
              {o.buyer.name}
            </option>
          ))}
        </Select>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <label className="text-sm font-medium text-ink-2">Real freight</label>
            <SegmentedControl<Mode>
              size="sm"
              aria-label="Freight entry mode"
              value={mode}
              onChange={setMode}
              options={[
                { value: 'perqt', label: '₹/qt' },
                { value: 'total', label: '₹/truck' },
              ]}
            />
          </div>
          {mode === 'perqt' ? (
            <Field
              type="number"
              inputMode="numeric"
              prefix="₹"
              suffix="/qt"
              value={draft}
              min={0}
              onChange={(e) => commit(Number(e.target.value))}
              aria-label="Real freight per quintal"
            />
          ) : (
            <Field
              type="number"
              inputMode="numeric"
              prefix="₹"
              suffix="/truck"
              value={Math.round(draft * lotQtyQt)}
              min={0}
              onChange={(e) => commit(Number(e.target.value) / lotQtyQt)}
              hint={`÷ ${fmtQt(lotQtyQt)} = ${perQt(draft)}`}
              aria-label="Real freight per truck"
            />
          )}
        </div>
      </div>

      {/* slider for tactile control */}
      <div className="mt-4">
        <input
          type="range"
          min={0}
          max={max}
          step={5}
          value={Math.min(draft, max)}
          onChange={(e) => commit(Number(e.target.value))}
          className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-teal-100 accent-teal-500"
          aria-label="Adjust real freight per quintal"
        />
        <div className="mt-1.5 flex justify-between text-[0.68rem] text-ink-3">
          <span>₹0</span>
          <span>
            Estimate <span className="tnum font-medium text-ink-2">{perQt(estimate)}</span>
          </span>
          <span className="tnum">₹{max}</span>
        </div>
      </div>

      {isOverridden && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-surface p-3 ring-1 ring-inset ring-teal-100"
        >
          <div className="text-sm">
            <span className="text-ink-2">Freight for </span>
            <span className="font-semibold text-ink">{selected.buyer.name}</span>
            <span className="text-ink-2"> now </span>
            <span className="tnum font-semibold text-clay-600">{perQt(currentPerQt)}</span>
            <span className={cn('tnum ml-1.5 text-xs font-medium', delta > 0 ? 'text-clay-600' : 'text-pine-600')}>
              ({delta > 0 ? '+' : ''}
              {inr(delta)}/qt vs estimate)
            </span>
          </div>
          <button
            onClick={() => clearOverride(selected.buyer.id)}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-ink-2 transition-colors hover:bg-black/5 hover:text-ink"
          >
            <RotateCcw size={13} /> Reset
          </button>
        </motion.div>
      )}
    </div>
  )
}
