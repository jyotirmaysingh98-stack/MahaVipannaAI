import { motion } from 'framer-motion'
import { Landmark, PieChart, TrendingUp, Users } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'

export function GovtDashboard() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">Agricultural Intelligence</h1>
        <p className="mt-1 text-ink-2">State-level oversight, market stability insights, and schemes performance.</p>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-4"
      >
        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-indigo-50 text-indigo-600">
              <TrendingUp size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">Avg Realization</p>
              <p className="text-xl font-bold text-ink">₹1,950/qt</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-pine-50 text-pine-600">
              <Users size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">Active FPOs</p>
              <p className="text-xl font-bold text-ink">1,402</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-amber-50 text-amber-600">
              <PieChart size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">Total Traded</p>
              <p className="text-xl font-bold text-ink">450k qt</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-clay-50 text-clay-600">
              <Landmark size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">Scheme Uptake</p>
              <p className="text-xl font-bold text-ink">68%</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">District Performance Map</h2>
          <div className="rounded-2xl border border-line bg-surface p-6 h-80 flex flex-col items-center justify-center">
            <p className="text-ink-2">Geospatial Intelligence Map</p>
            <p className="text-xs text-ink-3">Awaiting mapbox integration</p>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">Scheme Management</h2>
          <div className="rounded-2xl border border-line bg-surface p-6">
            <div className="space-y-3">
              <div className="flex justify-between p-3 bg-surface-sunk rounded-xl">
                <div>
                  <p className="font-semibold text-sm">PMFBY Subsidy</p>
                  <p className="text-xs text-ink-3">Active</p>
                </div>
                <button className="text-xs text-pine-600 font-medium">Edit</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
