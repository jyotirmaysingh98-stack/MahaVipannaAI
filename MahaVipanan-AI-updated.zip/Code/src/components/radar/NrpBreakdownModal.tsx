import type { OpportunityResponse } from '@/api/types'
import { inr, inrCompact, perQt } from '@/lib/format'
import { Modal } from '@/components/ui/Modal'
import { NrpWaterfall } from '@/components/charts/NrpWaterfall'
import { SystemCalculatedTag } from '@/components/brand/Provenance'

/**
 * Full net-realizable-price breakdown for one buyer: the signature waterfall
 * over an itemised ledger. This is where "highest quote ≠ most money kept"
 * becomes concrete — the quoted price steps down, deduction by deduction, to
 * the net the FPO actually banks.
 */
export function NrpBreakdownModal({
  opportunity: o,
  open,
  onClose,
}: {
  opportunity: OpportunityResponse | null
  open: boolean
  onClose: () => void
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={o ? `How ${o.buyer.name}'s net is calculated` : 'Breakdown'}
      description="Quoted price minus every real cost of selling through this channel."
    >
      {o && (
        <div>
          <div className="mb-4 flex items-center justify-between">
            <span className="eyebrow text-ink-3">Per-quintal waterfall</span>
            <SystemCalculatedTag />
          </div>

          <NrpWaterfall opportunity={o} />

          <dl className="mt-5 space-y-2 rounded-xl border border-line bg-surface-sunk/50 p-4 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-ink-2">Quoted price</dt>
              <dd className="tnum font-semibold text-amber-700">{perQt(o.breakdown.gross_price)}</dd>
            </div>
            {[
              { key: 'transport', label: 'Transport', amountPerQt: o.breakdown.transport_cost, overridden: o.freight_override_applied },
              { key: 'loading', label: 'Loading', amountPerQt: o.breakdown.loading_cost },
              { key: 'commission', label: 'Commission', amountPerQt: o.breakdown.commission_amount },
              { key: 'quality', label: 'Quality', amountPerQt: o.breakdown.quality_deduction },
              { key: 'misc', label: 'Misc', amountPerQt: o.breakdown.misc_cost },
            ].filter(d => d.amountPerQt > 0).map((d) => (
              <div key={d.key} className="flex items-center justify-between">
                <dt className="flex items-center gap-2 text-ink-2">
                  {d.label}
                  {d.overridden && (
                    <span className="rounded bg-teal-50 px-1.5 py-0.5 text-[0.62rem] font-semibold uppercase tracking-wide text-teal-700 ring-1 ring-inset ring-teal-100">
                      Your freight
                    </span>
                  )}
                </dt>
                <dd className="tnum font-medium text-clay-600">−{inr(d.amountPerQt)} /qt</dd>
              </div>
            ))}
            <div className="flex items-center justify-between border-t border-line-strong pt-2">
              <dt className="font-semibold text-pine-700">Net realizable price</dt>
              <dd className="tnum text-lg font-bold text-pine-700">{perQt(o.nrp_per_qt)}</dd>
            </div>
          </dl>

          <div className="mt-4 flex items-center justify-between rounded-xl bg-pine-50 p-4 ring-1 ring-inset ring-pine-100">
            <div>
              <p className="text-sm text-pine-800">
                Total realization
              </p>
            </div>
            <p className="tnum font-display text-2xl font-bold text-pine-700">{inrCompact(o.total_nrp)}</p>
          </div>

          <p className="mt-3 text-xs text-ink-3">
            Total deductions of {inr(o.breakdown.gross_price - o.nrp_per_qt)}/qt —{' '}
            {Math.round(((o.breakdown.gross_price - o.nrp_per_qt) / o.breakdown.gross_price) * 100)}% of the quoted price — separate the price
            offered from the money kept.
          </p>
        </div>
      )}
    </Modal>
  )
}
