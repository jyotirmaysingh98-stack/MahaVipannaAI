import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Bot, X, Send, Mic, Sparkles, User, RefreshCcw, Volume2, VolumeX } from 'lucide-react'
import { cn } from '@/lib/cn'
import { api } from '@/api/client'
import { useI18n } from '@/lib/i18n'
import { isSpeechRecognitionSupported, speak, startSpeechRecognition } from '@/lib/speech'

interface Message {
  id: string
  type: 'user' | 'bot'
  text: string
  isVoice?: boolean
}

export function Chatbot() {
  const { lang, t } = useI18n()
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>(() => [
    { id: 'msg-1', type: 'bot', text: t('chatbot.welcome') }
  ])
  const [input, setInput] = useState('')
  const [isRecording, setIsRecording] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  
  const endOfMessagesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (endOfMessagesRef.current && isOpen) {
      endOfMessagesRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages, isOpen, isTyping])

  const handleSend = async (textInput?: string | React.MouseEvent | React.KeyboardEvent) => {
    const textToSend = typeof textInput === 'string' ? textInput : input;
    if (!textToSend.trim()) return

    const userMsg: Message = { id: Date.now().toString(), type: 'user', text: textToSend }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setIsTyping(true)

    try {
      const res = await api.sendMessage(textToSend, lang)
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        text: res.data?.reply || t('chatbot.error.noResponse')
      }
      setMessages(prev => [...prev, botMsg])
      speak(botMsg.text, lang, voiceEnabled)
    } catch (err) {
      console.error(err)
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        type: 'bot',
        text: t('chatbot.error.network')
      }])
    } finally {
      setIsTyping(false)
    }
  }

  const toggleVoice = () => {
    if (isRecording) {
      setIsRecording(false)
      // Note: Speech recognition stops automatically on end event
      return
    }

    if (!isSpeechRecognitionSupported()) {
      alert(t('chatbot.voice.unsupported'))
      return
    }

    setIsRecording(true)
    startSpeechRecognition({
      lang,
      onResult: (transcript) => {
        setInput(transcript)
        handleSend(transcript)
      },
      onError: (error) => {
        console.error('Speech recognition error', error)
        setIsRecording(false)
      },
      onEnd: () => setIsRecording(false),
    })
  }

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-pine-600 text-white shadow-glow-pine hover:bg-pine-700 hover:scale-105 transition-all preserve-3d"
          >
            <div className="absolute inset-0 bg-white/20 rounded-full blur-md opacity-0 hover:opacity-100 transition-opacity" />
            <Bot size={28} />
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 flex h-[600px] max-h-[80vh] w-[380px] flex-col overflow-hidden rounded-3xl border border-line glass shadow-2xl"
          >
              <div className="flex items-center justify-between border-b border-white/20 bg-pine-600/90 px-5 py-4 backdrop-blur-md">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20 shadow-inner">
                    <Bot size={22} className="text-white" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-white">MahaVipanan AI</h3>
                    <p className="text-xs font-medium text-pine-100">{t('chatbot.subtitle')}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setVoiceEnabled(!voiceEnabled)}
                    className="rounded-full p-2 text-pine-100 transition-colors hover:bg-white/20 hover:text-white"
                    title={voiceEnabled ? t('chatbot.voice.mute') : t('chatbot.voice.enable')}
                  >
                    {voiceEnabled ? <Volume2 size={20} /> : <VolumeX size={20} className="opacity-70" />}
                  </button>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="rounded-full p-2 text-pine-100 transition-colors hover:bg-white/20 hover:text-white"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-surface-sunk/30">
              {messages.map((msg) => (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={msg.id}
                  className={cn("flex w-full", msg.type === 'user' ? "justify-end" : "justify-start")}
                >
                  <div className={cn(
                    "flex max-w-[85%] gap-2", 
                    msg.type === 'user' ? "flex-row-reverse" : "flex-row"
                  )}>
                    <div className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full mt-auto",
                      msg.type === 'user' ? "bg-pine-100 text-pine-700 ring-1 ring-pine-200" : "bg-indigo-100 text-indigo-700 ring-1 ring-indigo-200"
                    )}>
                      {msg.type === 'user' ? <User size={14} /> : <Sparkles size={14} />}
                    </div>
                    <div className={cn(
                      "rounded-2xl p-3 text-sm shadow-sm",
                      msg.type === 'user' 
                        ? "bg-pine-600 text-white rounded-br-none" 
                        : "bg-surface text-ink border border-line rounded-bl-none"
                    )}>
                      {msg.isVoice && <Mic size={14} className="inline mr-1 opacity-70" />}
                      {msg.text}
                    </div>
                  </div>
                </motion.div>
              ))}
              
              {isTyping && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex w-full justify-start">
                  <div className="flex gap-2">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full mt-auto bg-indigo-100 text-indigo-700 ring-1 ring-indigo-200">
                      <Sparkles size={14} />
                    </div>
                    <div className="rounded-2xl bg-surface border border-line p-3 rounded-bl-none shadow-sm flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" />
                      <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }} />
                      <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }} />
                    </div>
                  </div>
                </motion.div>
              )}
              <div ref={endOfMessagesRef} />
            </div>

            {/* Input Area */}
            <div className="border-t border-line bg-surface p-4">
              <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface-sunk p-2 focus-within:border-pine-400 focus-within:ring-1 focus-within:ring-pine-400 transition-all">
                <button 
                  onClick={toggleVoice}
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-colors",
                    isRecording ? "bg-clay-100 text-clay-600 animate-pulse" : "hover:bg-line/50 text-ink-3 hover:text-ink"
                  )}
                >
                  <Mic size={20} />
                </button>
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder={t('chatbot.placeholder')}
                  className="flex-1 bg-transparent text-sm text-ink placeholder:text-ink-3 focus:outline-none"
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-pine-600 text-white shadow-sm transition-all hover:bg-pine-700 disabled:opacity-50 disabled:hover:bg-pine-600"
                >
                  <Send size={18} className="ml-1" />
                </button>
              </div>
              <div className="mt-3 flex justify-between items-center px-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-ink-3 flex items-center gap-1">
                  <RefreshCcw size={10} /> {t('chatbot.contextAware')}
                </span>
                <span className="text-[10px] text-ink-3">{t('chatbot.poweredBy')}</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
