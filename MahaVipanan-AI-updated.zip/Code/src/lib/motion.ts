import type { Transition, Variants } from 'framer-motion'

/** Shared spring — the signature feel across the app. */
export const spring: Transition = {
  type: 'spring',
  stiffness: 260,
  damping: 30,
  mass: 0.9,
}

export const softSpring: Transition = {
  type: 'spring',
  stiffness: 180,
  damping: 26,
}

/** Container that staggers its children in. */
export const staggerContainer: Variants = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.06, delayChildren: 0.04 },
  },
}

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 12 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
}

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { duration: 0.4 } },
}

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.96 },
  show: { opacity: 1, scale: 1, transition: spring },
}

/** Layout transition used for the re-ranking flip on the Radar. */
export const rankLayout: Transition = {
  type: 'spring',
  stiffness: 320,
  damping: 34,
}
