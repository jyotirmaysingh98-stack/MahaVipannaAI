import { Outlet } from 'react-router-dom'
import { CursorGlow } from './CursorGlow'
import { TopNav } from './TopNav'
import { Chatbot } from '../ui/Chatbot'
import { NegotiationDrawer } from '../negotiation/NegotiationDrawer'
import { SchemeNoticeBoard } from '../schemes/SchemeNoticeBoard'

export function AppShell() {
  return (
    <div className="relative min-h-screen">
      <CursorGlow />
      <div className="relative z-10">
        <TopNav />
        <main className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6 sm:py-8">
          <Outlet />
        </main>
        <footer className="mx-auto max-w-[1400px] px-4 pb-10 pt-6 sm:px-6">
          <div className="flex flex-col gap-2 border-t border-line pt-5 text-xs text-ink-3 sm:flex-row sm:items-center sm:justify-between">
            <p>
              MahaVipanan AI — Premium Agricultural Intelligence Platform
            </p>
            <p className="shrink-0">&copy; 2026</p>
          </div>
        </footer>
      </div>
      <Chatbot />
      <NegotiationDrawer />
      <SchemeNoticeBoard />
    </div>
  )
}
