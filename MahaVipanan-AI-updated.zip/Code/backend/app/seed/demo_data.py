from sqlalchemy.orm import Session
from datetime import date, timedelta
from ..models.core import (
    FPO, Crop, QualityGrade, Market, Buyer,
    BuyerType, MarketType, DataSource, GovernmentScheme
)

def create_demo_data(db: Session):
    # 1. Create FPO
    fpo = FPO(name="Nashik Onion Producers FPO", district="Nashik", direct_marketing_license_no="MH-DML-998877")
    db.add(fpo)
    
    # 2. Create Crop & Grades
    crop = Crop(name="Onion", perishability_window_days=30)
    db.add(crop)
    db.flush()
    
    grade_a = QualityGrade(crop_id=crop.id, grade_label="A", default_quality_deduction_per_q=0.0)
    grade_b = QualityGrade(crop_id=crop.id, grade_label="B", default_quality_deduction_per_q=50.0)
    db.add_all([grade_a, grade_b])

    # 3. Create Markets
    apmc_nashik = Market(name="Nashik APMC", type=MarketType.apmc, district="Nashik", distance_km_from_fpo=15.0)
    db.add(apmc_nashik)
    db.flush()

    # 4. Create Buyers
    buyer1 = Buyer(
        market_id=apmc_nashik.id,
        name="Local APMC Trader (Nashik)",
        type=BuyerType.trader,
        data_source=DataSource.demo,
        location="Nashik APMC",
        distance_km=15.0,
        gross_price_per_qt=1800.0,
        transport_cost_per_qt=50.0,
        loading_cost_per_qt=20.0,
        commission_rate=0.06, # 6%
        quality_deduction_per_qt=30.0,
        misc_cost_per_qt=10.0,
        payment_days=2,
        min_quantity_qt=10.0,
        max_quantity_qt=100.0,
        reliability_score=85.0
    )

    buyer2 = Buyer(
        name="Direct Processor (Mumbai)",
        type=BuyerType.processor,
        data_source=DataSource.demo,
        location="Vashi, Mumbai",
        distance_km=165.0,
        gross_price_per_qt=1850.0,
        transport_cost_per_qt=180.0,
        loading_cost_per_qt=25.0,
        commission_rate=0.01, # 1% or direct flat
        quality_deduction_per_qt=10.0,
        misc_cost_per_qt=0.0,
        payment_days=7,
        min_quantity_qt=30.0,
        max_quantity_qt=500.0,
        reliability_score=95.0
    )

    buyer3 = Buyer(
        name="Institutional Buyer (Pune)",
        type=BuyerType.institutional,
        data_source=DataSource.demo,
        location="Pune",
        distance_km=210.0,
        gross_price_per_qt=1750.0,
        transport_cost_per_qt=200.0,
        loading_cost_per_qt=20.0,
        commission_rate=0.0, # 0% commission
        quality_deduction_per_qt=50.0, # strict quality
        misc_cost_per_qt=0.0,
        payment_days=15,
        min_quantity_qt=50.0,
        max_quantity_qt=1000.0,
        reliability_score=98.0
    )

    db.add_all([buyer1, buyer2, buyer3])

    # 5. Government schemes — real, verified official sources only.
    schemes = [
        GovernmentScheme(
            title="Pradhan Mantri Fasal Bima Yojana (PMFBY)",
            description="Crop insurance scheme covering yield losses due to natural calamities, pests and diseases.",
            benefits="Low-premium crop insurance; claim payout on notified yield loss.",
            eligibility="All farmers growing notified crops in notified areas, including sharecroppers and tenant farmers.",
            official_url="https://pmfby.gov.in/",
            state=None, district=None, crops="onion,wheat,tomato",
            target_role="farmer", status="published",
            source_key="pmfby", source_type="synced",
        ),
        GovernmentScheme(
            title="Soil Health Card Scheme",
            description="Provides farmers with soil nutrient status and crop-wise fertiliser recommendations.",
            benefits="Free soil testing and a personalised soil health card every 2 years.",
            eligibility="All landholding farmers.",
            official_url="https://soilhealth.dac.gov.in/",
            state=None, district=None, crops=None,
            target_role="farmer", status="published",
            source_key="soil_health", source_type="synced",
        ),
        GovernmentScheme(
            title="e-NAM — National Agriculture Market",
            description="Pan-India electronic trading platform connecting existing APMC mandis for better price discovery.",
            benefits="Access to a wider buyer base and transparent, real-time price discovery.",
            eligibility="FPOs and registered traders/buyers.",
            official_url="https://enam.gov.in/",
            state=None, district=None, crops=None,
            target_role="fpo", status="published",
            source_key="enam", source_type="synced",
        ),
        GovernmentScheme(
            title="UP e-Mandi",
            description="Uttar Pradesh's electronic mandi platform for produce trading and price transparency.",
            benefits="Digital mandi access, price transparency, reduced intermediation.",
            eligibility="Farmers and FPOs trading produce within Uttar Pradesh.",
            official_url="https://emandi.up.gov.in/",
            state="Uttar Pradesh", district=None, crops=None,
            target_role="all", status="published",
            source_key="up_emandi", source_type="synced",
        ),
        GovernmentScheme(
            title="MyScheme — Central & State Scheme Directory",
            description="Government of India's unified portal to discover schemes you may be eligible for.",
            benefits="Single directory to search and apply across central and state government schemes.",
            eligibility="Varies by individual scheme listed on the portal.",
            official_url="https://www.myscheme.gov.in/",
            state=None, district=None, crops=None,
            target_role="all", status="published",
            source_key="myscheme", source_type="synced",
        ),
    ]
    db.add_all(schemes)
    db.commit()

    print("Demo data seeded successfully.")
