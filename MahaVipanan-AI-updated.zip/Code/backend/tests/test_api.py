from fastapi.testclient import TestClient

def test_health_check(client: TestClient):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_fpo_dashboard(client: TestClient):
    response = client.get("/api/fpo/dashboard")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["data"]["fpo"]["name"] == "Nashik Onion Producers FPO"

def test_create_and_get_lot(client: TestClient):
    payload = {
        "crop_name": "Onion",
        "harvest_date": "2026-08-30",
        "members": [
            {"member_name": "Ramesh", "quantity_kg": 5000, "grade": "A"}
        ]
    }
    
    # Create Lot
    res = client.post("/api/lots/", json=payload)
    assert res.status_code == 200
    lot_data = res.json()["data"]
    assert lot_data["total_quantity_kg"] == 5000.0
    assert lot_data["total_quantity_q"] == 50.0
    lot_id = lot_data["id"]
    
    # Get Lot
    res2 = client.get(f"/api/lots/{lot_id}")
    assert res2.status_code == 200
    assert res2.json()["data"]["id"] == lot_id

def test_opportunities_and_freight_override(client: TestClient):
    # Setup lot first
    payload = {
        "crop_name": "Onion",
        "members": [{"member_name": "Ramesh", "quantity_kg": 5000, "grade": "A"}]
    }
    lot_id = client.post("/api/lots/", json=payload).json()["data"]["id"]
    
    # Fetch Opportunities
    res = client.get(f"/api/opportunities/{lot_id}")
    assert res.status_code == 200
    data = res.json()["data"]
    
    assert "opportunities" in data
    assert "recommendation" in data
    
    ops = data["opportunities"]
    assert len(ops) > 0
    
    # Verify rank sorting (first item should have rank 1 and highest NRP)
    assert ops[0]["rank"] == 1
    if len(ops) > 1:
        assert ops[0]["nrp_per_qt"] >= ops[1]["nrp_per_qt"]
        
    initial_nrp = ops[0]["nrp_per_qt"]
    
    # Perform freight override: set total freight to 0 (which means NRP should increase)
    override_payload = {"freight_cost": 0.0}
    res_override = client.post(f"/api/opportunities/{lot_id}/recalculate", json=override_payload)
    
    assert res_override.status_code == 200
    data_override = res_override.json()["data"]
    ops_override = data_override["opportunities"]
    
    new_nrp = ops_override[0]["nrp_per_qt"]
    # If transport cost was > 0, the new NRP should be higher since transport cost is 0
    if ops[0]["breakdown"]["transport_cost"] > 0:
        assert new_nrp > initial_nrp

def test_invalid_input_validation(client: TestClient):
    # Missing required field 'crop_name'
    payload = {
        "harvest_date": "2026-08-30",
        "members": [{"member_name": "Ramesh", "quantity_kg": 5000}]
    }
    res = client.post("/api/lots/", json=payload)
    assert res.status_code == 422
    data = res.json()
    assert data["success"] is False
    assert "error" in data
    assert "Invalid input data provided" in data["error"]

def test_negative_freight_rejection(client: TestClient):
    payload = {
        "crop_name": "Onion",
        "members": [{"member_name": "Ramesh", "quantity_kg": 5000, "grade": "A"}]
    }
    lot_id = client.post("/api/lots/", json=payload).json()["data"]["id"]
    
    # Negative freight
    override_payload = {"freight_cost": -100.0}
    res = client.post(f"/api/opportunities/{lot_id}/recalculate", json=override_payload)
    assert res.status_code == 422

def test_not_found(client: TestClient):
    res = client.get("/api/lots/nonexistent_id")
    # Our API returns 404 for not found but we didn't add an exception handler for HTTPException 
    # to format it, but FastAPI does by default. Let's test it.
    assert res.status_code == 404
