import { createContext, useContext, useState, ReactNode } from 'react'

type Language = 'en' | 'hi' | 'mr' | 'te'

const translations: Record<Language, Record<string, string>> = {
  en: {
    'nav.dashboard': 'Dashboard',
    'nav.lots': 'Lots',
    'nav.deliveries': 'Deliveries',
    'nav.schemes': 'Schemes',
    'nav.admin': 'Admin',
    'hero.title': 'Find the highest realistic return —',
    'hero.subtitle': 'not just the highest quote.',
    'common.signIn': 'Sign In',
    'common.getStarted': 'Get Started',
  },
  hi: {
    'nav.dashboard': 'डैशबोर्ड',
    'nav.lots': 'लॉट',
    'nav.deliveries': 'वितरण',
    'nav.schemes': 'योजनाएं',
    'nav.admin': 'व्यवस्थापक',
    'hero.title': 'उच्चतम यथार्थवादी रिटर्न खोजें —',
    'hero.subtitle': 'न केवल उच्चतम उद्धरण।',
    'common.signIn': 'साइन इन करें',
    'common.getStarted': 'शुरू करें',
  },
  mr: {
    'nav.dashboard': 'डॅशबोर्ड',
    'nav.lots': 'लॉट',
    'nav.deliveries': 'वितरण',
    'nav.schemes': 'योजना',
    'nav.admin': 'प्रशासक',
    'hero.title': 'सर्वोच्च वास्तववादी परतावा शोधा —',
    'hero.subtitle': 'केवळ सर्वोच्च कोट नाही.',
    'common.signIn': 'साइन इन करा',
    'common.getStarted': 'सुरू करा',
  },
  te: {
    'nav.dashboard': 'డాష్‌బోర్డ్',
    'nav.lots': 'లాట్లు',
    'nav.deliveries': 'డెలివరీలు',
    'nav.schemes': 'పథకాలు',
    'nav.admin': 'అడ్మిన్',
    'hero.title': 'అత్యధిక వాస్తవిక రాబడిని కనుగొనండి —',
    'hero.subtitle': 'అత్యధిక కోట్ మాత్రమే కాదు.',
    'common.signIn': 'సైన్ ఇన్ చేయండి',
    'common.getStarted': 'ప్రారంభించండి',
  }
}

interface I18nContextType {
  lang: Language
  setLang: (lang: Language) => void
  t: (key: string) => string
}

const I18nContext = createContext<I18nContextType | undefined>(undefined)

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>('en')

  const t = (key: string) => {
    return translations[lang][key] || translations['en'][key] || key
  }

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  )
}

export function useI18n() {
  const context = useContext(I18nContext)
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider')
  }
  return context
}
