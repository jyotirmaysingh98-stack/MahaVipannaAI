from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Date, ForeignKey, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime as _dt
import enum
import uuid

from ..database import Base

def generate_uuid():
    return str(uuid.uuid4())

class UserRole(str, enum.Enum):
    fpo = "fpo"
    farmer = "farmer"
    buyer = "buyer"
    admin = "admin"
    government = "government"
    delivery = "delivery"

class CropUnit(str, enum.Enum):
    quintal = "quintal"

class LotStatus(str, enum.Enum):
    draft = "draft"
    ready = "ready"
    sold = "sold"
    held = "held"

class MarketType(str, enum.Enum):
    apmc = "apmc"
    direct = "direct"
    processor_gate = "processor_gate"

class BuyerType(str, enum.Enum):
    trader = "trader"
    processor = "processor"
    institutional = "institutional"

class DataSource(str, enum.Enum):
    real = "real"
    demo = "demo"
    imported = "imported"

class TrustBand(str, enum.Enum):
    trusted = "trusted"
    moderate = "moderate"
    caution = "caution"

class DecisionAction(str, enum.Enum):
    sell = "sell"
    hold = "hold"
    redirect = "redirect"

class OrderStatus(str, enum.Enum):
    offer = "offer"
    negotiation = "negotiation"
    accepted = "accepted"
    transport = "transport"
    pickup = "pickup"
    in_transit = "in_transit"
    delivered = "delivered"
    payment = "payment"

class WarehouseStatus(str, enum.Enum):
    stored = "stored"
    ongoing = "ongoing"
    sold = "sold"

class NegotiationStatus(str, enum.Enum):
    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"

class FPO(Base):
    __tablename__ = "fpo"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)
    district = Column(String)
    direct_marketing_license_no = Column(String, nullable=True)
    created_at = Column(DateTime, default=func.now())

class User(Base):
    __tablename__ = "user"
    id = Column(String, primary_key=True, default=generate_uuid)
    fpo_id = Column(String, ForeignKey("fpo.id"), nullable=True)
    name = Column(String, nullable=True)
    email = Column(String, unique=True, nullable=True)
    phone = Column(String, unique=True, nullable=True)
    password_hash = Column(String, nullable=False)
    role = Column(Enum(UserRole), default=UserRole.fpo)
    created_at = Column(DateTime, default=func.now())

class FPOMember(Base):
    __tablename__ = "fpo_member"
    id = Column(String, primary_key=True, default=generate_uuid)
    fpo_id = Column(String, ForeignKey("fpo.id"))
    name = Column(String, nullable=False)
    village = Column(String)
    created_at = Column(DateTime, default=func.now())

class Crop(Base):
    __tablename__ = "crop"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)
    unit = Column(Enum(CropUnit), default=CropUnit.quintal)
    perishability_window_days = Column(Integer)

class QualityGrade(Base):
    __tablename__ = "quality_grade"
    id = Column(String, primary_key=True, default=generate_uuid)
    crop_id = Column(String, ForeignKey("crop.id"))
    grade_label = Column(String, nullable=False)
    default_quality_deduction_per_q = Column(Float, default=0.0)

class ProduceLot(Base):
    __tablename__ = "produce_lot"
    id = Column(String, primary_key=True, default=generate_uuid)
    fpo_id = Column(String, ForeignKey("fpo.id"))
    crop_id = Column(String, ForeignKey("crop.id"))
    total_quantity_q = Column(Float, nullable=False, default=0.0)
    total_quantity_kg = Column(Float, nullable=False, default=0.0)
    grade_summary = Column(String)
    status = Column(Enum(LotStatus), default=LotStatus.draft)
    harvest_date = Column(Date, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships for convenience
    members = relationship("LotMember", back_populates="lot", cascade="all, delete-orphan")

class LotMember(Base):
    __tablename__ = "lot_member"
    id = Column(String, primary_key=True, default=generate_uuid)
    lot_id = Column(String, ForeignKey("produce_lot.id"))
    member_id = Column(String, ForeignKey("fpo_member.id"))
    grade_id = Column(String, ForeignKey("quality_grade.id"))
    quantity_kg = Column(Float, nullable=False)
    member_name = Column(String, nullable=False)
    grade = Column(String, nullable=True)
    contribution_date = Column(Date, nullable=True)
    
    lot = relationship("ProduceLot", back_populates="members")

class Market(Base):
    __tablename__ = "market"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)
    type = Column(Enum(MarketType))
    district = Column(String)
    distance_km_from_fpo = Column(Float)
    commission_rate = Column(Float, default=0.0)
    default_handling_per_q = Column(Float, default=0.0)
    default_other_per_q = Column(Float, default=0.0)

class Buyer(Base):
    __tablename__ = "buyer"
    id = Column(String, primary_key=True, default=generate_uuid)
    market_id = Column(String, ForeignKey("market.id"), nullable=True)
    name = Column(String, nullable=False)
    type = Column(Enum(BuyerType))
    data_source = Column(Enum(DataSource), default=DataSource.demo)
    
    # Fields from SYSTEM_ARCHITECTURE.md 
    location = Column(String, nullable=True)
    distance_km = Column(Float, default=0.0)
    gross_price_per_qt = Column(Float, default=0.0)
    transport_cost_per_qt = Column(Float, default=0.0)
    loading_cost_per_qt = Column(Float, default=0.0)
    commission_rate = Column(Float, default=0.0)
    quality_deduction_per_qt = Column(Float, default=0.0)
    misc_cost_per_qt = Column(Float, default=0.0)
    payment_terms = Column(String, nullable=True)
    payment_days = Column(Integer, default=0)
    min_quantity_qt = Column(Float, default=0.0)
    max_quantity_qt = Column(Float, default=10000.0)
    reliability_score = Column(Float, default=50.0)
    demand_signal = Column(String, nullable=True)

class BuyerRequirement(Base):
    __tablename__ = "buyer_requirement"
    id = Column(String, primary_key=True, default=generate_uuid)
    buyer_id = Column(String, ForeignKey("buyer.id"))
    crop_id = Column(String, ForeignKey("crop.id"))
    min_quantity_q = Column(Float)
    min_grade = Column(String)

class BuyerOffer(Base):
    __tablename__ = "buyer_offer"
    id = Column(String, primary_key=True, default=generate_uuid)
    buyer_id = Column(String, ForeignKey("buyer.id"))
    crop_id = Column(String, ForeignKey("crop.id"))
    gross_price_per_q = Column(Float)
    valid_on = Column(Date)
    data_source = Column(Enum(DataSource), default=DataSource.demo)

class NRPCalculation(Base):
    __tablename__ = "nrp_calculation"
    id = Column(String, primary_key=True, default=generate_uuid)
    lot_id = Column(String, ForeignKey("produce_lot.id"))
    buyer_id = Column(String, ForeignKey("buyer.id"))
    buyer_offer_id = Column(String, ForeignKey("buyer_offer.id"), nullable=True)
    market_id = Column(String, ForeignKey("market.id"), nullable=True)
    
    gross_per_q = Column(Float)
    transport_per_q = Column(Float)
    freight_override = Column(Float, nullable=True)
    loading_unloading_per_q = Column(Float)
    commission_amount = Column(Float)
    handling_per_q = Column(Float, default=0.0)
    quality_deduction_per_q = Column(Float)
    other_per_q = Column(Float, default=0.0)
    misc_cost = Column(Float, default=0.0)
    nrp_per_q = Column(Float, nullable=False)
    net_lot_value = Column(Float)
    calculated_at = Column(DateTime, default=func.now())

class LogisticsEstimate(Base):
    __tablename__ = "logistics_estimate"
    id = Column(String, primary_key=True, default=generate_uuid)
    nrp_calculation_id = Column(String, ForeignKey("nrp_calculation.id"))
    estimated_freight_per_q = Column(Float)
    override_freight_per_q = Column(Float, nullable=True)
    is_overridden = Column(Boolean, default=False)
    effective_freight_per_q = Column(Float)

class OpportunityScore(Base):
    __tablename__ = "opportunity_score"
    id = Column(String, primary_key=True, default=generate_uuid)
    nrp_calculation_id = Column(String, ForeignKey("nrp_calculation.id"))
    buyer_id = Column(String, ForeignKey("buyer.id"))
    rank = Column(Integer)
    trust_score = Column(Integer)
    trust_band = Column(Enum(TrustBand))
    delta_vs_best_gross_per_q = Column(Float)

class Recommendation(Base):
    __tablename__ = "recommendation"
    id = Column(String, primary_key=True, default=generate_uuid)
    lot_id = Column(String, ForeignKey("produce_lot.id"))
    selected_opportunity_id = Column(String, ForeignKey("opportunity_score.id"), nullable=True)
    recommended_buyer_id = Column(String, ForeignKey("buyer.id"), nullable=True)
    decision = Column(Enum(DecisionAction))
    action = Column(String)
    scorecard_json = Column(String, nullable=True) # JSON string
    justification = Column(String, nullable=True)
    ai_explanation = Column(String, nullable=True)
    freight_override_applied = Column(Float, nullable=True)
    created_at = Column(DateTime, default=func.now())

class Transaction(Base):
    __tablename__ = "transaction"
    id = Column(String, primary_key=True, default=generate_uuid)
    recommendation_id = Column(String, ForeignKey("recommendation.id"))
    buyer_id = Column(String, ForeignKey("buyer.id"))
    final_gross_per_q = Column(Float)
    final_nrp_per_q = Column(Float)
    quantity_q = Column(Float)
    followed_recommendation = Column(Boolean)
    recorded_at = Column(DateTime, default=func.now())

class PriceRecord(Base):
    __tablename__ = "price_record"
    id = Column(String, primary_key=True, default=generate_uuid)
    crop_id = Column(String, ForeignKey("crop.id"))
    market_id = Column(String, ForeignKey("market.id"))
    price_per_q = Column(Float)
    observed_on = Column(Date)
    data_source = Column(Enum(DataSource), default=DataSource.demo)

class Order(Base):
    __tablename__ = "order"
    id = Column(String, primary_key=True, default=generate_uuid)
    lot_id = Column(String, ForeignKey("produce_lot.id"), nullable=True)
    buyer_id = Column(String, ForeignKey("buyer.id"), nullable=True)
    fpo_id = Column(String, ForeignKey("fpo.id"), nullable=True)
    status = Column(Enum(OrderStatus), default=OrderStatus.offer)
    agreed_price_per_q = Column(Float)
    quantity_q = Column(Float)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    # Negotiation-system additions: the real logged-in accounts party to this
    # order/negotiation. At most two of the three are set, matching one of the
    # three valid relationships (Farmer<->Buyer, Farmer<->FPO, FPO<->Buyer).
    crop_name = Column(String, nullable=True)
    farmer_user_id = Column(String, ForeignKey("user.id"), nullable=True)
    buyer_user_id = Column(String, ForeignKey("user.id"), nullable=True)
    fpo_user_id = Column(String, ForeignKey("user.id"), nullable=True)
    initiated_by_user_id = Column(String, ForeignKey("user.id"), nullable=True)

class OrderTracking(Base):
    __tablename__ = "order_tracking"
    id = Column(String, primary_key=True, default=generate_uuid)
    order_id = Column(String, ForeignKey("order.id"))
    status = Column(Enum(OrderStatus))
    location = Column(String, nullable=True) # simulated GPS or fixed strings
    timestamp = Column(DateTime, default=_dt.utcnow)
    notes = Column(String, nullable=True)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    is_demo = Column(Boolean, default=True)

class Negotiation(Base):
    __tablename__ = "negotiation"
    id = Column(String, primary_key=True, default=generate_uuid)
    order_id = Column(String, ForeignKey("order.id"))
    offered_price_per_q = Column(Float)
    counter_price_per_q = Column(Float, nullable=True)
    status = Column(Enum(NegotiationStatus), default=NegotiationStatus.pending)
    created_at = Column(DateTime, default=_dt.utcnow)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    # Who proposed this round, so the UI can show "who made each offer".
    created_by_user_id = Column(String, ForeignKey("user.id"), nullable=True)
    created_by_role = Column(String, nullable=True)
    message = Column(String, nullable=True)

class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(String, primary_key=True, default=generate_uuid)
    from_user_id = Column(String, ForeignKey("user.id"))
    to_user_id = Column(String, ForeignKey("user.id"), nullable=True)
    to_buyer_id = Column(String, ForeignKey("buyer.id"), nullable=True)
    order_id = Column(String, ForeignKey("order.id"), nullable=True)
    rating = Column(Integer)
    comments = Column(String, nullable=True)
    created_at = Column(DateTime, default=func.now())

class GovernmentScheme(Base):
    __tablename__ = "government_scheme"
    id = Column(String, primary_key=True, default=generate_uuid)
    title = Column(String, nullable=False)
    description = Column(String, nullable=False)
    benefits = Column(String)
    eligibility = Column(String)
    deadline = Column(Date, nullable=True)
    official_url = Column(String, nullable=True)
    created_at = Column(DateTime, default=func.now())
    # Matching + source-sync additions
    state = Column(String, nullable=True)
    district = Column(String, nullable=True)
    crops = Column(String, nullable=True)  # comma-separated tags
    target_role = Column(String, nullable=True)  # farmer / fpo / buyer / all
    status = Column(String, default="published")  # draft / published
    source_key = Column(String, nullable=True)  # key into the official source registry
    source_type = Column(String, default="manual")  # manual / synced
    source_last_checked = Column(DateTime, nullable=True)
    created_by_user_id = Column(String, ForeignKey("user.id"), nullable=True)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

class Warehouse(Base):
    __tablename__ = "warehouse"
    id = Column(String, primary_key=True, default=generate_uuid)
    fpo_id = Column(String, ForeignKey("fpo.id"))
    name = Column(String, nullable=False)
    location = Column(String)
    capacity_q = Column(Float)
    storage_type = Column(String) # Cold, Dry, etc.
    created_at = Column(DateTime, default=func.now())

class WarehouseInventory(Base):
    __tablename__ = "warehouse_inventory"
    id = Column(String, primary_key=True, default=generate_uuid)
    warehouse_id = Column(String, ForeignKey("warehouse.id"))
    lot_id = Column(String, ForeignKey("produce_lot.id"))
    farmer_id = Column(String, ForeignKey("fpo_member.id"), nullable=True)
    quantity_q = Column(Float)
    status = Column(Enum(WarehouseStatus), default=WarehouseStatus.stored)
    stored_at = Column(DateTime, default=func.now())

