import { motion } from 'framer-motion'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Landmark, CheckCircle2, IndianRupee, HandCoins } from 'lucide-react'
import { Button } from '@/components/ui/Button'

export function SchemesPage() {
  const schemes = [
    {
      id: 1,
      name: 'PM-KISAN Samman Nidhi',
      desc: 'Direct income support of ₹6,000 per year to all landholding farmer families.',
      amount: '₹6,000 / year',
      status: 'active',
      match: '98% Match'
    },
    {
      id: 2,
      name: 'Agriculture Infrastructure Fund (AIF)',
      desc: 'Financing facility for post-harvest management infrastructure and community farming assets.',
      amount: 'Up to ₹2 Crore',
      status: 'eligible',
      match: '85% Match'
    },
    {
      id: 3,
      name: 'PM Fasal Bima Yojana (PMFBY)',
      desc: 'Crop insurance scheme covering yield losses due to non-preventable risks.',
      amount: 'Variable Premium',
      status: 'pending',
      match: 'Applied'
    }
  ]

  return (
    <div className="pb-24">
      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={fadeUp} className="mb-6 flex justify-between items-end">
          <div>
            <h1 className="font-display text-4xl font-bold tracking-tight text-ink">Government Schemes</h1>
            <p className="mt-2 text-ink-3">Discover, match, and apply for central and state agriculture schemes.</p>
          </div>
          <Button className="bg-pine-600 hover:bg-pine-700 text-white shadow-glow-pine">Explore New Schemes</Button>
        </motion.div>

        <motion.div variants={fadeUp} className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="glass rounded-3xl p-6 border-pine-200 bg-pine-50/50">
            <HandCoins size={28} className="text-pine-600 mb-4" />
            <p className="text-sm font-semibold text-pine-800 uppercase tracking-wider">Total Subsidies Availed</p>
            <p className="font-display text-3xl font-bold text-pine-700 mt-2">₹12,50,000</p>
          </div>
          <div className="glass rounded-3xl p-6 border-teal-200 bg-teal-50/50">
            <Landmark size={28} className="text-teal-600 mb-4" />
            <p className="text-sm font-semibold text-teal-800 uppercase tracking-wider">Active Applications</p>
            <p className="font-display text-3xl font-bold text-teal-700 mt-2">3 Schemes</p>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="space-y-4">
          <h2 className="font-display text-2xl font-semibold text-ink mb-4">Recommended for your FPO</h2>
          {schemes.map((scheme) => (
            <div key={scheme.id} className="glass rounded-3xl p-6 border border-line hover:border-pine-300 transition-colors shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-display text-xl font-bold text-ink">{scheme.name}</h3>
                    <span className="px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-pine-100 text-pine-700 ring-1 ring-pine-200">{scheme.match}</span>
                  </div>
                  <p className="text-sm text-ink-2 max-w-2xl">{scheme.desc}</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-xs font-semibold text-ink-3 uppercase tracking-wider">Benefit</p>
                    <p className="font-bold text-ink flex items-center gap-1 mt-1"><IndianRupee size={14}/> {scheme.amount}</p>
                  </div>
                  {scheme.status === 'eligible' ? (
                    <Button className="bg-pine-600 text-white shadow-glow-pine">Apply Now</Button>
                  ) : scheme.status === 'pending' ? (
                    <Button variant="secondary" disabled>Reviewing...</Button>
                  ) : (
                    <Button variant="ghost" className="text-pine-600 bg-pine-50 hover:bg-pine-100"><CheckCircle2 size={16} className="mr-1.5"/> Active</Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  )
}
