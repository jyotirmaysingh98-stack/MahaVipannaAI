import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'

interface NegotiationUIState {
  isOpen: boolean
  openNegotiation: (orderId?: string) => void
  closeNegotiation: () => void
  activeOrderId: string | null
}

const NegotiationUIContext = createContext<NegotiationUIState | null>(null)

export function useNegotiationUI(): NegotiationUIState {
  const ctx = useContext(NegotiationUIContext)
  if (!ctx) throw new Error('useNegotiationUI must be used within NegotiationUIProvider')
  return ctx
}

export function NegotiationUIProvider({ children }: { children: ReactNode }) {
  const [isOpen, setOpen] = useState(false)
  const [activeOrderId, setActiveOrderId] = useState<string | null>(null)

  const openNegotiation = useCallback((orderId?: string) => {
    setActiveOrderId(orderId ?? null)
    setOpen(true)
  }, [])
  const closeNegotiation = useCallback(() => setOpen(false), [])

  const value = useMemo(() => ({ isOpen, openNegotiation, closeNegotiation, activeOrderId }), [isOpen, openNegotiation, closeNegotiation, activeOrderId])

  return <NegotiationUIContext.Provider value={value}>{children}</NegotiationUIContext.Provider>
}
