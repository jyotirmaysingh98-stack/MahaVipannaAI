import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Tractor, Sprout, HandCoins, TrendingUp, Trash2, Truck } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { NegotiationMeter } from '@/components/radar/NegotiationMeter'
import { Field } from '@/components/ui/Field'
import { Button } from '@/components/ui/Button'
import { api } from '@/api/client'
import type { LotResponse } from '@/api/types'
import { useI18n } from '@/lib/i18n'

export function FarmerDashboard() {
  const { t } = useI18n()
  const [msp, setMsp] = useState(1800)
  const [isp, setIsp] = useState(1950)
  const currentOffer = 1750
  
  const [lots, setLots] = useState<LotResponse[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchLots()
  }, [])

  const fetchLots = async () => {
    try {
      const res = await api.getLots()
      if (res.success) setLots(res.data || [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm(t('farmer.deleteConfirm'))) return
    try {
      await api.deleteLot(id)
      setLots(lots.filter(l => l.id !== id))
    } catch (err) {
      console.error('Failed to delete lot', err)
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">{t('farmer.title')}</h1>
          <p className="mt-1 text-ink-2">{t('farmer.subtitle')}</p>
        </div>
        <Link to="/app/delivery">
          <Button variant="outline" className="gap-2">
            <Truck size={16} /> {t('farmer.trackDeliveries')}
          </Button>
        </Link>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-600/10 text-pine-600">
              <Sprout size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('farmer.activeLots')}</p>
              <p className="text-2xl font-bold text-ink">3 {t('farmer.lots')}</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-indigo-600/10 text-indigo-600">
              <HandCoins size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('farmer.ongoingNegotiations')}</p>
              <p className="text-2xl font-bold text-ink">1 {t('farmer.activeCount')}</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-600/10 text-amber-600">
              <Tractor size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('farmer.subsidies')}</p>
              <p className="text-2xl font-bold text-ink">2 {t('farmer.schemesCount')}</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('farmer.activeNegotiation')}</h2>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field 
              label={t('farmer.msp')}
              type="number" 
              value={msp} 
              onChange={(e) => setMsp(Number(e.target.value) || 0)} 
            />
            <Field 
              label={t('farmer.isp')}
              type="number"
              value={isp} 
              onChange={(e) => setIsp(Number(e.target.value) || 0)} 
            />
          </div>
          <NegotiationMeter currentOffer={currentOffer} minimumSellingPrice={msp} idealSellingPrice={isp} />
          {currentOffer < msp && (
            <div className="mt-2 text-sm font-medium text-red-600 bg-red-600/10 p-3 rounded-xl ring-1 ring-red-600/20">
              {t('farmer.warningOffer')}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('farmer.alerts')}</h2>
          <div className="rounded-2xl border border-pine-600/20 bg-pine-600/10 p-6 flex gap-4">
            <TrendingUp className="text-pine-600 shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-pine-600">{t('farmer.alertTitle')}</h3>
              <p className="text-sm text-ink-2 mt-1">{t('farmer.alertDesc')}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="font-display text-xl font-semibold text-ink mb-4">{t('farmer.myLots')}</h2>
        {loading ? (
          <p className="text-ink-3">{t('common.loading')}</p>
        ) : lots.length === 0 ? (
          <p className="text-ink-3">{t('common.noData')}</p>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {lots.map(lot => (
              <div key={lot.id} className="rounded-2xl border border-line bg-surface p-5 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-ink text-lg">{lot.crop_name}</h3>
                    <span className="rounded-full bg-surface-sunk px-2.5 py-0.5 text-xs font-medium text-ink-2 uppercase">
                      {t(`status.${lot.status}`) || lot.status}
                    </span>
                  </div>
                  <p className="text-sm text-ink-2 mb-1">
                    {t('common.qty')}: <span className="font-medium text-ink">{lot.total_quantity_q} qt</span>
                  </p>
                  <p className="text-sm text-ink-2 mb-4">
                    {t('common.grade')}: <span className="font-medium text-ink">{lot.members[0]?.grade ?? 'FAQ'}</span>
                  </p>
                </div>
                <Button 
                  variant="secondary" 
                  size="sm" 
                  onClick={() => handleDelete(lot.id)}
                  className="w-full mt-auto text-red-600 hover:text-red-700 hover:border-red-200"
                >
                  <Trash2 size={16} className="mr-2" /> {t('farmer.deleteLot')}
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
