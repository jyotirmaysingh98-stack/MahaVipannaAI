from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models.core import Order, Negotiation, OrderTracking, User, UserRole, OrderStatus, NegotiationStatus, generate_uuid
from ..schemas.core import (
    NegotiationCreateRequest, NegotiationCounterRequest, NegotiationAiAssistRequest,
    NegotiationOrderResponse, CounterpartyResponse,
)
from ..services.negotiation_advice import build_negotiation_suggestion
from ..services.geocode import demo_route_for

negotiations_router = APIRouter(prefix="/api/negotiations", tags=["negotiations"])

# The three valid negotiation relationships. Each entry maps a role to the
# roles it is allowed to negotiate with.
VALID_COUNTERPARTS = {
    "farmer": {"buyer", "fpo"},
    "fpo": {"farmer", "buyer"},
    "buyer": {"farmer", "fpo"},
}

ROLE_FIELD = {"farmer": "farmer_user_id", "buyer": "buyer_user_id", "fpo": "fpo_user_id"}


def _party_field_for(user: User) -> str:
    field = ROLE_FIELD.get(user.role.value)
    if not field:
        raise HTTPException(status_code=403, detail="This role cannot take part in negotiations")
    return field


def _assert_is_party(order: Order, user: User):
    if user.id not in (order.farmer_user_id, order.buyer_user_id, order.fpo_user_id):
        raise HTTPException(status_code=403, detail="You are not a party to this negotiation")


def _serialize(order: Order, db: Session) -> dict:
    rounds = db.query(Negotiation).filter(Negotiation.order_id == order.id).order_by(Negotiation.created_at.asc()).all()
    data = NegotiationOrderResponse.model_validate(order).model_dump()
    data["rounds"] = [
        {
            "id": r.id, "offered_price_per_q": r.offered_price_per_q, "status": r.status,
            "created_by_user_id": r.created_by_user_id, "created_by_role": r.created_by_role,
            "message": r.message, "created_at": r.created_at,
        }
        for r in rounds
    ]
    return data


@negotiations_router.get("/counterparties")
def list_counterparties(role: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    allowed = VALID_COUNTERPARTS.get(user.role.value, set())
    if role not in allowed:
        raise HTTPException(status_code=400, detail=f"{user.role.value} accounts cannot negotiate with {role}")
    users = db.query(User).filter(User.role == UserRole(role)).all()
    return {"success": True, "data": [CounterpartyResponse(id=u.id, name=u.name, role=u.role.value) for u in users]}


@negotiations_router.get("")
def list_negotiations(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    field = _party_field_for(user)
    orders = db.query(Order).filter(getattr(Order, field) == user.id).order_by(Order.updated_at.desc()).all()
    return {"success": True, "data": [_serialize(o, db) for o in orders]}


@negotiations_router.post("")
def create_negotiation(payload: NegotiationCreateRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    my_field = _party_field_for(user)
    counterparty = db.query(User).filter(User.id == payload.counterparty_user_id).first()
    if not counterparty:
        raise HTTPException(status_code=404, detail="Counterparty account not found")

    allowed = VALID_COUNTERPARTS.get(user.role.value, set())
    if counterparty.role.value not in allowed:
        raise HTTPException(status_code=400, detail=f"{user.role.value} accounts cannot negotiate with {counterparty.role.value}")
    other_field = ROLE_FIELD[counterparty.role.value]

    order = Order(
        id=generate_uuid(),
        lot_id=payload.lot_id,
        status=OrderStatus.negotiation,
        agreed_price_per_q=None,
        quantity_q=payload.quantity_q,
        crop_name=payload.crop_name,
        initiated_by_user_id=user.id,
    )
    setattr(order, my_field, user.id)
    setattr(order, other_field, counterparty.id)
    db.add(order)
    db.flush()

    first_round = Negotiation(
        id=generate_uuid(), order_id=order.id, offered_price_per_q=payload.offer_price_per_q,
        status=NegotiationStatus.pending, created_by_user_id=user.id, created_by_role=user.role.value,
    )
    db.add(first_round)
    db.commit()
    db.refresh(order)
    return {"success": True, "data": _serialize(order, db)}


@negotiations_router.get("/{order_id}")
def get_negotiation(order_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Negotiation not found")
    _assert_is_party(order, user)
    return {"success": True, "data": _serialize(order, db)}


def _latest_round(db: Session, order_id: str) -> Negotiation:
    r = db.query(Negotiation).filter(Negotiation.order_id == order_id).order_by(Negotiation.created_at.desc()).first()
    if not r:
        raise HTTPException(status_code=404, detail="No offers on this negotiation yet")
    return r


@negotiations_router.post("/{order_id}/counter")
def counter_negotiation(order_id: str, payload: NegotiationCounterRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Negotiation not found")
    _assert_is_party(order, user)
    if order.status == OrderStatus.accepted:
        raise HTTPException(status_code=400, detail="This negotiation was already accepted")

    latest = _latest_round(db, order_id)
    if latest.created_by_user_id == user.id and latest.status == NegotiationStatus.pending:
        raise HTTPException(status_code=400, detail="Waiting for the other party to respond to your last offer")

    new_round = Negotiation(
        id=generate_uuid(), order_id=order.id, offered_price_per_q=payload.price_per_q,
        status=NegotiationStatus.pending, created_by_user_id=user.id, created_by_role=user.role.value,
        message=payload.message,
    )
    db.add(new_round)
    order.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(order)
    return {"success": True, "data": _serialize(order, db)}


@negotiations_router.post("/{order_id}/accept")
def accept_negotiation(order_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Negotiation not found")
    _assert_is_party(order, user)
    latest = _latest_round(db, order_id)
    if latest.created_by_user_id == user.id:
        raise HTTPException(status_code=400, detail="You cannot accept your own offer")
    if latest.status != NegotiationStatus.pending:
        raise HTTPException(status_code=400, detail="This offer is no longer pending")

    latest.status = NegotiationStatus.accepted
    order.status = OrderStatus.accepted
    order.agreed_price_per_q = latest.offered_price_per_q
    order.updated_at = datetime.utcnow()

    # Kick off demo tracking (a real deployment would wait for a delivery
    # partner to check in; deterministic coordinates are clearly demo data).
    route = demo_route_for(order.id)
    pickup = route[0]
    db.add(OrderTracking(
        id=generate_uuid(), order_id=order.id, status=OrderStatus.pickup,
        location=pickup["location"], latitude=pickup["lat"], longitude=pickup["lng"], is_demo=True,
        notes="Demo / simulated tracking",
    ))
    db.commit()
    db.refresh(order)
    return {"success": True, "data": _serialize(order, db)}


@negotiations_router.post("/{order_id}/reject")
def reject_negotiation(order_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Negotiation not found")
    _assert_is_party(order, user)
    latest = _latest_round(db, order_id)
    if latest.created_by_user_id == user.id:
        raise HTTPException(status_code=400, detail="You cannot reject your own offer")
    if latest.status != NegotiationStatus.pending:
        raise HTTPException(status_code=400, detail="This offer is no longer pending")

    latest.status = NegotiationStatus.rejected
    order.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(order)
    return {"success": True, "data": _serialize(order, db)}


@negotiations_router.post("/{order_id}/ai-assist")
async def ai_assist(order_id: str, payload: NegotiationAiAssistRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Negotiation not found")
    _assert_is_party(order, user)
    latest = _latest_round(db, order_id)

    rounds = db.query(Negotiation).filter(Negotiation.order_id == order_id).order_by(Negotiation.created_at.asc()).all()
    history_summary = "; ".join(f"{r.created_by_role or '?'} offered Rs.{r.offered_price_per_q}" for r in rounds[-5:])

    suggestion = await build_negotiation_suggestion(
        crop=order.crop_name or "produce", quantity_q=order.quantity_q, current_offer=latest.offered_price_per_q,
        msp=payload.minimum_selling_price, isp=payload.ideal_selling_price,
        history_summary=history_summary, user_role=user.role.value, lang=payload.lang or "en",
    )
    return {"success": True, "data": suggestion}
