import type { LucideIcon } from 'lucide-react'
import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'
import { Card } from '@/components/ui/Card'

type Accent = 'pine' | 'amber' | 'teal' | 'indigo' | 'clay'

const ACCENT: Record<Accent, string> = {
  pine: 'bg-pine-50 text-pine-600 ring-pine-100',
  amber: 'bg-amber-50 text-amber-700 ring-amber-200',
  teal: 'bg-teal-50 text-teal-600 ring-teal-100',
  indigo: 'bg-indigo-100 text-indigo-600 ring-indigo-100',
  clay: 'bg-clay-50 text-clay-600 ring-clay-100',
}

/** Compact metric tile for the dashboard and analytics headers. */
export function KpiCard({
  label,
  value,
  hint,
  icon: Icon,
  accent = 'pine',
  className,
}: {
  label: string
  value: ReactNode
  hint?: ReactNode
  icon?: LucideIcon
  accent?: Accent
  className?: string
}) {
  return (
    <Card interactive className={cn('p-5', className)}>
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm font-medium text-ink-2">{label}</p>
        {Icon && (
          <span className={cn('grid h-8 w-8 place-items-center rounded-lg ring-1 ring-inset', ACCENT[accent])}>
            <Icon size={16} strokeWidth={2} />
          </span>
        )}
      </div>
      <div className="mt-3 font-display text-3xl font-bold tracking-tight text-ink">{value}</div>
      {hint && <p className="mt-1 text-xs text-ink-3">{hint}</p>}
    </Card>
  )
}
