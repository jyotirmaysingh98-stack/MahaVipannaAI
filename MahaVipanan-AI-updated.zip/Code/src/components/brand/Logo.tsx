import { cn } from '@/lib/cn'

/**
 * MahaVipanan mark — "The Ledger & The Field": a leaf (the field) whose stem
 * steps down to a baseline (the ledger / gross→net waterfall). The signature
 * glyph, echoing the product's one idea: what you keep, not what you're quoted.
 */
export function LogoMark({ size = 36, className }: { size?: number; className?: string }) {
  return (
    <span
      className={cn('inline-grid place-items-center rounded-xl bg-pine-600 shadow-glow-pine', className)}
      style={{ width: size, height: size }}
      aria-hidden
    >
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24" fill="none">
        {/* leaf */}
        <path
          d="M12 3C7.5 4 5 7.2 5 11c2.6 0.2 5-0.6 6.4-2.6C12.6 6.6 12.4 4.6 12 3Z"
          fill="#EAF4EC"
        />
        <path d="M6 11c3-1.2 5-3 6-6" stroke="#15734F" strokeWidth="1.1" strokeLinecap="round" />
        {/* stepped waterfall to baseline (gross -> net) */}
        <path
          d="M8 10.5v4h3v3h3v3h6"
          stroke="#E0A32E"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  )
}

export function Logo({
  size = 36,
  showWord = true,
  className,
}: {
  size?: number
  showWord?: boolean
  className?: string
}) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <LogoMark size={size} />
      {showWord && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[1.05rem] font-semibold tracking-tight text-ink">
            MahaVipanan<span className="text-pine-500"> AI</span>
          </span>
          <span className="mt-0.5 text-[0.62rem] font-medium uppercase tracking-[0.14em] text-ink-3">
            Sell on what you keep
          </span>
        </span>
      )}
    </span>
  )
}
