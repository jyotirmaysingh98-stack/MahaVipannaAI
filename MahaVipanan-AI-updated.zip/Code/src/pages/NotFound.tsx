
import { Compass } from 'lucide-react'
import { useNavigate, useRouteError } from 'react-router-dom'
import { Button } from '@/components/ui/Button'

export function NotFoundPage() {
  const navigate = useNavigate()
  const error: any = useRouteError()
  
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-left min-h-[50vh] max-w-2xl mx-auto">
        <h2 className="mb-2 font-display text-xl font-bold text-red-600">Application Error</h2>
        <pre className="mb-8 w-full overflow-x-auto text-xs bg-red-50 p-4 rounded text-red-900 border border-red-200 whitespace-pre-wrap">
          {error.message || String(error)}
          {'\n\n'}
          {error.stack}
        </pre>
        <Button onClick={() => navigate('/app')} className="bg-pine-600 hover:bg-pine-700">
          Try again
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[50vh]">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-surface shadow-sm ring-1 ring-inset ring-line-strong">
        <Compass className="h-8 w-8 text-pine-600" />
      </div>
      <h2 className="mb-2 font-display text-xl font-bold text-ink">This page isn't on the map</h2>
      <p className="mb-8 max-w-sm text-sm text-ink-3">
        The link may be out of date. Head back to your command center.
      </p>
      <Button onClick={() => navigate('/app')} className="bg-pine-600 hover:bg-pine-700">
        Back to dashboard
      </Button>
    </div>
  )
}
