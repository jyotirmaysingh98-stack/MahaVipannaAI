from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models.core import ProduceLot, LotMember, FPO, Crop, QualityGrade, LotStatus
from ..schemas.core import ProduceLotCreate, ProduceLotResponse

router = APIRouter(prefix="/api/lots", tags=["Lots"])

@router.post("/", response_model=dict)
def create_lot(lot_data: ProduceLotCreate, db: Session = Depends(get_db)):
    fpo = db.query(FPO).first()
    if not fpo:
        raise HTTPException(status_code=404, detail="No demo FPO found.")
        
    crop = db.query(Crop).filter(Crop.name == lot_data.crop_name).first()
    if not crop:
        raise HTTPException(status_code=404, detail=f"Crop {lot_data.crop_name} not found.")

    total_kg = sum(m.quantity_kg for m in lot_data.members)
    
    # Very simple grade summary logic
    grades = [m.grade for m in lot_data.members if m.grade]
    dominant_grade = max(set(grades), key=grades.count) if grades else "FAQ"
    
    new_lot = ProduceLot(
        fpo_id=fpo.id,
        crop_id=crop.id,
        total_quantity_kg=total_kg,
        total_quantity_q=total_kg / 100.0,
        harvest_date=lot_data.harvest_date,
        grade_summary=dominant_grade,
        status=LotStatus.ready
    )
    db.add(new_lot)
    db.commit()
    db.refresh(new_lot)
    
    for m in lot_data.members:
        # Assuming grade exists in DB for this demo
        q_grade = db.query(QualityGrade).filter(
            QualityGrade.crop_id == crop.id, 
            QualityGrade.grade_label == m.grade
        ).first()
        
        lm = LotMember(
            lot_id=new_lot.id,
            member_name=m.member_name,
            quantity_kg=m.quantity_kg,
            grade=m.grade,
            grade_id=q_grade.id if q_grade else None
        )
        db.add(lm)
    
    db.commit()
    db.refresh(new_lot)
    
    return {
        "success": True,
        "data": ProduceLotResponse.model_validate(new_lot),
        "data_label": "DEMO_DATA"
    }

@router.get("/", response_model=dict)
def get_lots(db: Session = Depends(get_db)):
    fpo = db.query(FPO).first()
    if not fpo:
        return {"success": True, "data": [], "data_label": "DEMO_DATA"}
        
    lots = db.query(ProduceLot).filter(ProduceLot.fpo_id == fpo.id).all()
    
    return {
        "success": True,
        "data": [ProduceLotResponse.model_validate(l) for l in lots],
        "data_label": "DEMO_DATA"
    }

@router.get("/{lot_id}", response_model=dict)
def get_lot(lot_id: str, db: Session = Depends(get_db)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    return {
        "success": True,
        "data": ProduceLotResponse.model_validate(lot),
        "data_label": "DEMO_DATA"
    }

@router.delete("/{lot_id}", response_model=dict)
def delete_lot(lot_id: str, db: Session = Depends(get_db)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    db.delete(lot)
    db.commit()
    return {"success": True, "message": "Lot deleted successfully"}
