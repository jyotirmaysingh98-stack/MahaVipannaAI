from fastapi import FastAPI, Depends, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import text
import logging

from .config import settings
from .database import get_db, run_sqlite_migrations

run_sqlite_migrations()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(
    title="MahaVipanan AI Backend",
    description="FPO-first agricultural market-intelligence & decision-support platform (SIH26132).",
    version="0.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    logger.warning(f"Validation error: {exc.errors()}")
    return JSONResponse(
        status_code=422,
        content={"success": False, "error": "Invalid input data provided", "details": exc.errors(), "data_label": "DEMO_DATA"}
    )

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(
        status_code=500,
        content={"success": False, "error": "An internal server error occurred.", "data_label": "DEMO_DATA"}
    )

@app.get("/health")
def health_check(db: Session = Depends(get_db)):
    db_status = "ok"
    try:
        db.execute(text("SELECT 1"))
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        db_status = "failed"
        
    return {
        "status": "ok" if db_status == "ok" else "degraded", 
        "database": db_status,
        "message": "MahaVipanan AI Backend is running."
    }

from .routers import fpo_router, lots_router, opportunities_router
from .routers.auth import auth_router
from .routers.orders import orders_router
from .routers.admin import admin_router
from .routers.chat import chat_router
from .routers.schemes import schemes_router
from .routers.feedback import feedback_router
from .routers.simulator import router as simulator_router
from .routers.negotiations import negotiations_router

app.include_router(fpo_router)
app.include_router(lots_router)
app.include_router(opportunities_router)
app.include_router(auth_router)
app.include_router(orders_router)
app.include_router(admin_router)
app.include_router(chat_router)
app.include_router(schemes_router)
app.include_router(feedback_router)
app.include_router(simulator_router)
app.include_router(negotiations_router)

