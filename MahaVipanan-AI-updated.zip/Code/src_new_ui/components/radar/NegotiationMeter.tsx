import { motion } from 'framer-motion'
import { AlertCircle, TrendingDown, Scale } from 'lucide-react'
import { inr } from '@/lib/format'
import { useState } from 'react'
import { cn } from '@/lib/cn'

interface NegotiationMeterProps {
  currentOffer: number
  minimumSellingPrice: number
  idealSellingPrice: number
}

export function NegotiationMeter({ currentOffer, minimumSellingPrice, idealSellingPrice }: NegotiationMeterProps) {
  const [offer, setOffer] = useState(currentOffer)
  
  const diff = offer - minimumSellingPrice
  const isBelowMSP = diff < 0
  const isOptimal = offer >= idealSellingPrice

  // Calculate percentage for meter needle (0% = MSP - 200, 100% = ISP + 200)
  const minRange = minimumSellingPrice - (minimumSellingPrice * 0.1)
  const maxRange = idealSellingPrice + (idealSellingPrice * 0.1)
  const range = maxRange - minRange
  const percentage = Math.max(0, Math.min(100, ((offer - minRange) / range) * 100))

  return (
    <div className="rounded-3xl border border-line bg-surface p-6 shadow-card">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="font-display text-xl font-bold text-ink flex items-center gap-2">
            <Scale size={20} className="text-pine-600" /> Live Negotiation
          </h3>
          <p className="text-sm text-ink-3 mt-1">Simulate counter-offers and evaluate viability.</p>
        </div>
        <div className="text-right">
          <p className="text-xs font-bold uppercase tracking-wider text-ink-3">Current Offer</p>
          <p className={cn("tnum font-display text-2xl font-black mt-1", isBelowMSP ? "text-clay-600" : isOptimal ? "text-pine-600" : "text-amber-600")}>
            {inr(offer)}/qt
          </p>
        </div>
      </div>

      <div className="relative h-12 rounded-full overflow-hidden bg-surface-sunk ring-1 ring-inset ring-line/50 flex">
        <div className="w-1/3 bg-gradient-to-r from-clay-500/20 to-amber-500/20" />
        <div className="w-1/3 bg-gradient-to-r from-amber-500/20 to-pine-500/20" />
        <div className="w-1/3 bg-pine-500/20" />
        
        {/* MSP Line */}
        <div 
          className="absolute top-0 bottom-0 w-0.5 bg-clay-500 z-10" 
          style={{ left: `${Math.max(0, Math.min(100, ((minimumSellingPrice - minRange) / range) * 100))}%` }}
        />
        
        {/* ISP Line */}
        <div 
          className="absolute top-0 bottom-0 w-0.5 bg-pine-500 z-10" 
          style={{ left: `${Math.max(0, Math.min(100, ((idealSellingPrice - minRange) / range) * 100))}%` }}
        />

        {/* Current Offer Needle */}
        <motion.div 
          className="absolute top-0 bottom-0 w-1.5 bg-ink rounded-full shadow-md z-20 -ml-1 transition-all" 
          animate={{ left: `${percentage}%` }}
          transition={{ type: "spring", stiffness: 100 }}
        />
      </div>

      <div className="flex justify-between mt-2 text-xs font-bold text-ink-3 uppercase tracking-wider">
        <span className="text-clay-600">MSP: {inr(minimumSellingPrice)}</span>
        <span className="text-pine-600">ISP: {inr(idealSellingPrice)}</span>
      </div>

      {isBelowMSP && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 flex items-start gap-3 rounded-2xl bg-clay-50 p-4 ring-1 ring-clay-200"
        >
          <AlertCircle className="text-clay-600 shrink-0 mt-0.5" size={20} />
          <div>
            <p className="font-bold text-clay-800">Critical Warning: Below Minimum Selling Price</p>
            <p className="text-sm text-clay-700 mt-1">
              Accepting this offer will result in a net loss of <strong className="font-black">{inr(Math.abs(diff))} per quintal</strong> for the farmers. It is highly recommended to HOLD the inventory or seek alternate buyers.
            </p>
          </div>
        </motion.div>
      )}

      {isOptimal && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 flex items-start gap-3 rounded-2xl bg-pine-50 p-4 ring-1 ring-pine-200"
        >
          <TrendingDown className="text-pine-600 shrink-0 mt-0.5 rotate-180" size={20} />
          <div>
            <p className="font-bold text-pine-800">Excellent Deal</p>
            <p className="text-sm text-pine-700 mt-1">
              This offer is above your Ideal Selling Price (ISP). It is recommended to lock this deal before market corrections.
            </p>
          </div>
        </motion.div>
      )}

      <div className="mt-6 pt-6 border-t border-line/50">
        <label className="text-sm font-bold uppercase tracking-wider text-ink-3 mb-2 block">
          Counter-Offer Simulator
        </label>
        <div className="flex gap-4">
          <input 
            type="number" 
            value={offer}
            onChange={(e) => setOffer(Number(e.target.value))}
            className="w-full rounded-2xl border-2 border-line bg-surface px-4 py-3 text-lg font-black text-ink focus:border-pine-400 focus:outline-none focus:ring-4 focus:ring-pine-400/20"
          />
          <button className="px-6 py-3 bg-ink text-white rounded-2xl font-bold shadow-md hover:bg-ink/90 whitespace-nowrap">
            Send Counter
          </button>
        </div>
      </div>
    </div>
  )
}
