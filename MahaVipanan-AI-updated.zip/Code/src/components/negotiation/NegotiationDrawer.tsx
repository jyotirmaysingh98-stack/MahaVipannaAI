import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Handshake, Plus, Check, XCircle, Sparkles, Mic, Volume2, Loader2, ArrowLeft } from 'lucide-react'
import { cn } from '@/lib/cn'
import { inr } from '@/lib/format'
import { useI18n } from '@/lib/i18n'
import { useApp } from '@/state/AppContext'
import { useNegotiationUI } from '@/state/NegotiationContext'
import { api } from '@/api/client'
import type { Counterparty, NegotiationOrder, NegotiationAiSuggestion, NegotiationRole } from '@/api/types'
import { NegotiationMeter } from '@/components/radar/NegotiationMeter'
import { useToast } from '@/components/ui/Toast'
import { isSpeechRecognitionSupported, speak, startSpeechRecognition } from '@/lib/speech'

const COUNTERPART_ROLES: Record<string, NegotiationRole[]> = {
  farmer: ['buyer', 'fpo'],
  fpo: ['farmer', 'buyer'],
  buyer: ['farmer', 'fpo'],
}

export function NegotiationDrawer() {
  const { t, lang } = useI18n()
  const { role, userId } = useApp()
  const { isOpen, closeNegotiation, activeOrderId, openNegotiation } = useNegotiationUI()
  const toast = useToast()

  const [orders, setOrders] = useState<NegotiationOrder[]>([])
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState<NegotiationOrder | null>(null)
  const [showNewForm, setShowNewForm] = useState(false)

  const allowedRoles = role ? COUNTERPART_ROLES[role] || [] : []

  const refreshList = async () => {
    setLoading(true)
    try {
      const res = await api.listNegotiations()
      const data = res.data || []
      setOrders(data)
      if (activeOrderId) {
        const found = data.find(o => o.id === activeOrderId)
        if (found) setSelected(found)
      }
    } catch (e: any) {
      toast.toast({ title: e.message || t('negotiation.error.load'), tone: 'info' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (isOpen && allowedRoles.length > 0) refreshList()
    if (isOpen && !activeOrderId) setSelected(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen])

  if (!allowedRoles.length) return null

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 40 }}
          className="fixed right-0 top-0 z-50 flex h-full w-full max-w-[440px] flex-col overflow-hidden border-l border-line bg-surface shadow-2xl"
        >
          <div className="flex items-center justify-between border-b border-line bg-pine-600 px-5 py-4">
            <div className="flex items-center gap-2 text-white">
              {(selected || showNewForm) && (
                <button onClick={() => { setSelected(null); setShowNewForm(false) }} className="rounded-full p-1 hover:bg-white/20">
                  <ArrowLeft size={18} />
                </button>
              )}
              <Handshake size={20} />
              <h3 className="font-display font-bold">{t('negotiation.title')}</h3>
            </div>
            <button onClick={closeNegotiation} className="rounded-full p-2 text-pine-100 hover:bg-white/20 hover:text-white">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {loading && <div className="flex justify-center py-10"><Loader2 className="animate-spin text-pine-600" /></div>}

            {!loading && !selected && !showNewForm && (
              <NegotiationList
                orders={orders}
                myUserId={userId}
                onSelect={(o) => { setSelected(o); openNegotiation(o.id) }}
                onStartNew={() => setShowNewForm(true)}
              />
            )}

            {!loading && showNewForm && (
              <NewNegotiationForm
                allowedRoles={allowedRoles}
                onCreated={(o) => { setShowNewForm(false); setSelected(o); refreshList() }}
              />
            )}

            {!loading && selected && (
              <NegotiationDetail
                order={selected}
                myUserId={userId}
                myRole={role as NegotiationRole}
                lang={lang}
                onChanged={(o) => { setSelected(o); setOrders(prev => prev.map(p => p.id === o.id ? o : p)) }}
              />
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

function NegotiationList({ orders, myUserId, onSelect, onStartNew }: {
  orders: NegotiationOrder[]; myUserId: string | null
  onSelect: (o: NegotiationOrder) => void; onStartNew: () => void
}) {
  const { t } = useI18n()
  return (
    <div className="space-y-3">
      <button
        onClick={onStartNew}
        className="flex w-full items-center justify-center gap-2 rounded-2xl bg-ink py-3 font-bold text-white shadow-sm hover:bg-ink/90"
      >
        <Plus size={18} /> {t('negotiation.startNew')}
      </button>

      {orders.length === 0 && (
        <p className="text-center text-sm text-ink-3 py-10">{t('negotiation.empty')}</p>
      )}

      {orders.map(o => {
        const last = o.rounds[o.rounds.length - 1]
        return (
          <button
            key={o.id}
            onClick={() => onSelect(o)}
            className="w-full rounded-2xl border border-line bg-surface p-4 text-left shadow-sm hover:border-pine-300 hover:shadow-card transition-all"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-ink">{o.crop_name || t('negotiation.produce')}</span>
              <StatusPill status={o.status} />
            </div>
            <p className="mt-1 text-sm text-ink-3">{o.quantity_q} qt</p>
            {last && (
              <p className="mt-2 tnum font-display text-lg font-black text-pine-700">
                {inr(last.offered_price_per_q)}/qt
                <span className="ml-2 text-xs font-medium text-ink-3">
                  {last.created_by_user_id === myUserId ? t('negotiation.you') : t('negotiation.them')}
                </span>
              </p>
            )}
          </button>
        )
      })}
    </div>
  )
}

function StatusPill({ status }: { status: string }) {
  const { t } = useI18n()
  const map: Record<string, string> = {
    negotiation: 'bg-amber-50 text-amber-700 ring-amber-200',
    accepted: 'bg-pine-50 text-pine-700 ring-pine-200',
  }
  return (
    <span className={cn('rounded-full px-2.5 py-0.5 text-[11px] font-bold ring-1', map[status] || 'bg-surface-sunk text-ink-3 ring-line')}>
      {t(`negotiation.status.${status}`)}
    </span>
  )
}

function NewNegotiationForm({ allowedRoles, onCreated }: { allowedRoles: NegotiationRole[]; onCreated: (o: NegotiationOrder) => void }) {
  const { t } = useI18n()
  const toast = useToast()
  const [targetRole, setTargetRole] = useState<NegotiationRole>(allowedRoles[0])
  const [counterparties, setCounterparties] = useState<Counterparty[]>([])
  const [counterpartyId, setCounterpartyId] = useState('')
  const [crop, setCrop] = useState('')
  const [quantity, setQuantity] = useState(10)
  const [price, setPrice] = useState(2000)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    api.listCounterparties(targetRole).then(res => {
      const data = res.data || []
      setCounterparties(data)
      setCounterpartyId(data[0]?.id || '')
    }).catch(() => setCounterparties([]))
  }, [targetRole])

  const submit = async () => {
    if (!counterpartyId || !crop.trim()) {
      toast.toast({ title: t('negotiation.form.incomplete'), tone: 'info' })
      return
    }
    setSubmitting(true)
    try {
      const res = await api.createNegotiation({ counterparty_user_id: counterpartyId, crop_name: crop, quantity_q: quantity, offer_price_per_q: price })
      if (!res.data) throw new Error(res.error || t('negotiation.error.create'))
      toast.toast({ title: t('negotiation.created'), tone: 'success' })
      onCreated(res.data)
    } catch (e: any) {
      toast.toast({ title: e.message || t('negotiation.error.create'), tone: 'info' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-bold uppercase tracking-wider text-ink-3">{t('negotiation.form.counterpartRole')}</label>
        <div className="mt-1.5 flex gap-2">
          {allowedRoles.map(r => (
            <button
              key={r}
              onClick={() => setTargetRole(r)}
              className={cn('flex-1 rounded-xl border py-2 text-sm font-bold capitalize', targetRole === r ? 'border-pine-500 bg-pine-50 text-pine-700' : 'border-line text-ink-3')}
            >
              {t(`role.${r}`)}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-xs font-bold uppercase tracking-wider text-ink-3">{t('negotiation.form.counterparty')}</label>
        <select value={counterpartyId} onChange={e => setCounterpartyId(e.target.value)} className="mt-1.5 w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm">
          {counterparties.length === 0 && <option value="">{t('negotiation.form.noCounterparties')}</option>}
          {counterparties.map(c => <option key={c.id} value={c.id}>{c.name || c.id.slice(0, 8)}</option>)}
        </select>
      </div>

      <div>
        <label className="text-xs font-bold uppercase tracking-wider text-ink-3">{t('negotiation.form.crop')}</label>
        <input value={crop} onChange={e => setCrop(e.target.value)} placeholder={t('negotiation.form.cropPlaceholder')}
          className="mt-1.5 w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-ink-3">{t('negotiation.form.quantity')}</label>
          <input type="number" value={quantity} onChange={e => setQuantity(Number(e.target.value))} className="mt-1.5 w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm" />
        </div>
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-ink-3">{t('negotiation.form.price')}</label>
          <input type="number" value={price} onChange={e => setPrice(Number(e.target.value))} className="mt-1.5 w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm" />
        </div>
      </div>

      <button onClick={submit} disabled={submitting} className="w-full rounded-2xl bg-pine-600 py-3 font-bold text-white shadow-sm hover:bg-pine-700 disabled:opacity-60">
        {submitting ? <Loader2 className="mx-auto animate-spin" size={18} /> : t('negotiation.form.submit')}
      </button>
    </div>
  )
}

function NegotiationDetail({ order, myUserId, lang, onChanged }: {
  order: NegotiationOrder; myUserId: string | null; myRole: NegotiationRole; lang: string
  onChanged: (o: NegotiationOrder) => void
}) {
  const { t } = useI18n()
  const toast = useToast()
  const [counterPrice, setCounterPrice] = useState<number>(0)
  const [message, setMessage] = useState('')
  const [msp, setMsp] = useState<string>('')
  const [isp, setIsp] = useState<string>('')
  const [suggestion, setSuggestion] = useState<NegotiationAiSuggestion | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [isRecording, setIsRecording] = useState(false)

  const rounds = order.rounds
  const last = rounds[rounds.length - 1]
  const isMyTurn = !!last && last.created_by_user_id !== myUserId && last.status === 'pending'
  const waitingOnThem = !!last && last.created_by_user_id === myUserId && last.status === 'pending'

  useEffect(() => { if (last) setCounterPrice(Math.round(last.offered_price_per_q)) }, [last?.id])

  const run = async (action: string, fn: () => Promise<any>) => {
    setBusy(action)
    try {
      const res = await fn()
      if (!res.data) throw new Error(res.error || t('negotiation.error.action'))
      onChanged(res.data)
      toast.toast({ title: t(`negotiation.actionDone.${action}`), tone: 'success' })
    } catch (e: any) {
      toast.toast({ title: e.message || t('negotiation.error.action'), tone: 'info' })
    } finally {
      setBusy(null)
    }
  }

  const askAi = async () => {
    setBusy('ai')
    try {
      const res = await api.aiAssistNegotiation(order.id, {
        minimum_selling_price: msp ? Number(msp) : undefined,
        ideal_selling_price: isp ? Number(isp) : undefined,
        lang,
      })
      setSuggestion(res.data || null)
    } catch (e: any) {
      toast.toast({ title: e.message || t('negotiation.error.ai'), tone: 'info' })
    } finally {
      setBusy(null)
    }
  }

  const dictate = () => {
    if (!isSpeechRecognitionSupported()) {
      toast.toast({ title: t('chatbot.voice.unsupported'), tone: 'info' })
      return
    }
    setIsRecording(true)
    startSpeechRecognition({
      lang,
      onResult: (transcript) => setMessage(transcript),
      onEnd: () => setIsRecording(false),
      onError: () => setIsRecording(false),
    })
  }

  return (
    <div className="space-y-5">
      <div>
        <h4 className="font-display text-lg font-bold text-ink">{order.crop_name}</h4>
        <p className="text-sm text-ink-3 flex items-center gap-2">{order.quantity_q} qt <StatusPill status={order.status} /></p>
      </div>

      {order.status === 'accepted' && (
        <div className="rounded-2xl bg-pine-50 p-4 ring-1 ring-pine-200 text-sm text-pine-800 font-bold flex items-center gap-2">
          <Check size={16} /> {t('negotiation.dealAgreed')}: {inr(order.agreed_price_per_q || 0)}/qt
        </div>
      )}

      {last && (
        <NegotiationMeter
          currentOffer={last.offered_price_per_q}
          minimumSellingPrice={msp ? Number(msp) : last.offered_price_per_q * 0.9}
          idealSellingPrice={isp ? Number(isp) : last.offered_price_per_q * 1.1}
          interactive={false}
        />
      )}

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wider text-ink-3">{t('meter.msp')} ({t('negotiation.optional')})</label>
          <input type="number" value={msp} onChange={e => setMsp(e.target.value)} className="mt-1 w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wider text-ink-3">{t('meter.isp')} ({t('negotiation.optional')})</label>
          <input type="number" value={isp} onChange={e => setIsp(e.target.value)} className="mt-1 w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm" />
        </div>
      </div>

      {/* AI negotiation assistant */}
      <div className="rounded-2xl border border-indigo-200 bg-indigo-50/60 p-4">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-sm font-bold text-indigo-800"><Sparkles size={15} /> {t('negotiation.ai.title')}</span>
          <button onClick={askAi} disabled={busy === 'ai'} className="rounded-full bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-60">
            {busy === 'ai' ? <Loader2 className="animate-spin" size={14} /> : t('negotiation.ai.ask')}
          </button>
        </div>
        {suggestion && (
          <div className="mt-3 space-y-2">
            <p className="text-xs font-bold uppercase text-indigo-600">{t('negotiation.ai.suggestedRange')}: {inr(suggestion.suggested_counter_low)}–{inr(suggestion.suggested_counter_high)}</p>
            <p className="text-sm text-indigo-900 flex items-start gap-2">
              {suggestion.ai_text}
              <button onClick={() => speak(suggestion.ai_text, lang)} className="shrink-0 text-indigo-500 hover:text-indigo-700"><Volume2 size={15} /></button>
            </p>
            <p className="text-[10px] uppercase font-bold text-indigo-400">{t('negotiation.ai.disclaimer')} · {suggestion.ai_source}</p>
            <button
              onClick={() => setCounterPrice(Math.round(suggestion.suggested_counter_low))}
              className="text-xs font-bold text-indigo-700 underline"
            >
              {t('negotiation.ai.useSuggestion')}
            </button>
          </div>
        )}
      </div>

      {/* History */}
      <div>
        <p className="mb-2 text-xs font-bold uppercase tracking-wider text-ink-3">{t('negotiation.history')}</p>
        <div className="space-y-1.5 max-h-40 overflow-y-auto">
          {rounds.map(r => (
            <div key={r.id} className="flex items-center justify-between rounded-xl bg-surface-sunk px-3 py-2 text-sm">
              <span className="font-bold text-ink">{t(`role.${r.created_by_role}`)}</span>
              <span className="tnum font-black text-ink">{inr(r.offered_price_per_q)}/qt</span>
              <span className="text-[11px] text-ink-3">{new Date(r.created_at).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      </div>

      {order.status !== 'accepted' && (
        <div className="space-y-2 border-t border-line/50 pt-4">
          {waitingOnThem && <p className="text-sm text-ink-3">{t('negotiation.waiting')}</p>}
          {isMyTurn && (
            <div className="flex gap-2">
              <button onClick={() => run('accept', () => api.acceptNegotiation(order.id))} disabled={!!busy}
                className="flex-1 flex items-center justify-center gap-1 rounded-xl bg-pine-600 py-2.5 text-sm font-bold text-white hover:bg-pine-700 disabled:opacity-60">
                <Check size={15} /> {t('negotiation.accept')}
              </button>
              <button onClick={() => run('reject', () => api.rejectNegotiation(order.id))} disabled={!!busy}
                className="flex-1 flex items-center justify-center gap-1 rounded-xl bg-clay-100 py-2.5 text-sm font-bold text-clay-700 hover:bg-clay-200 disabled:opacity-60">
                <XCircle size={15} /> {t('negotiation.reject')}
              </button>
            </div>
          )}
          <div className="flex gap-2 items-center rounded-2xl border border-line p-2">
            <input type="number" value={counterPrice} onChange={e => setCounterPrice(Number(e.target.value))}
              className="w-28 bg-transparent px-2 text-sm font-bold focus:outline-none" />
            <input value={message} onChange={e => setMessage(e.target.value)} placeholder={t('negotiation.messagePlaceholder')}
              className="flex-1 bg-transparent text-sm focus:outline-none" />
            <button onClick={dictate} className={cn('rounded-lg p-2', isRecording ? 'bg-clay-100 text-clay-600 animate-pulse' : 'text-ink-3 hover:bg-line/50')}>
              <Mic size={16} />
            </button>
            <button
              onClick={() => run('counter', () => api.counterNegotiation(order.id, { price_per_q: counterPrice, message }))}
              disabled={!!busy || (!!last && last.created_by_user_id === myUserId && last.status === 'pending')}
              className="rounded-xl bg-ink px-3 py-2 text-xs font-bold text-white hover:bg-ink/90 disabled:opacity-50"
            >
              {t('negotiation.counter')}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
