import { Outlet } from 'react-router-dom'
import { CursorGlow } from './CursorGlow'
import { DemoModeBanner } from './DemoModeBanner'
import { TopNav } from './TopNav'
import { Chatbot } from '../ui/Chatbot'

export function AppShell() {
  return (
    <div className="relative min-h-screen">
      <CursorGlow />
      <div className="relative z-10">
        <DemoModeBanner />
        <TopNav />
        <main className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6 sm:py-8">
          <Outlet />
        </main>
        <footer className="mx-auto max-w-[1400px] px-4 pb-10 pt-6 sm:px-6">
          <div className="flex flex-col gap-2 border-t border-line pt-5 text-xs text-ink-3 sm:flex-row sm:items-center sm:justify-between">
            <p>
              MahaVipanan AI — decision support for Farmer Producer Organisations. Ranks by net realizable
              price, not the quoted price.
            </p>
            <p className="shrink-0">Prototype for SIH 2026 · SIH26132 · synthetic demo data</p>
          </div>
        </footer>
        <Chatbot />
      </div>
    </div>
  )
}
