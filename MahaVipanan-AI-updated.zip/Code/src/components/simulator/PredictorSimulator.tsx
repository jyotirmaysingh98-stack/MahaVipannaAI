import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Activity, Calendar, Droplets, AlertTriangle, CheckCircle, Clock } from 'lucide-react'
import { simulatorApi, CropOption, SimulatorResponse } from '@/api/simulator'
import { inr } from '@/lib/format'
import { cn } from '@/lib/cn'

export function PredictorSimulator() {
  const [crops, setCrops] = useState<CropOption[]>([])
  const [selectedCrop, setSelectedCrop] = useState<string>('')
  const [harvestDate, setHarvestDate] = useState<string>('')
  const [prediction, setPrediction] = useState<SimulatorResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    // Set default harvest date to today
    const today = new Date().toISOString().split('T')[0]
    setHarvestDate(today)

    // Load crops
    simulatorApi.getCrops()
      .then(res => {
        setCrops(res)
        if (res.length > 0) {
          setSelectedCrop(res[0].id)
        }
      })
      .catch(err => {
        console.error("Failed to load crops:", err)
      })
  }, [])

  const handlePredict = async () => {
    if (!selectedCrop) {
      setError('Please select a crop')
      return
    }
    
    setLoading(true)
    setError('')
    try {
      const res = await simulatorApi.predict({
        crop_id: selectedCrop,
        harvest_date: harvestDate
      })
      setPrediction(res)
    } catch (err: any) {
      setError(err.message || 'Failed to predict price')
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-pine-600 bg-pine-50 border-pine-200'
      case 'warning': return 'text-amber-600 bg-amber-50 border-amber-200'
      case 'expired': return 'text-clay-600 bg-clay-50 border-clay-200'
      default: return 'text-ink-3 bg-surface-sunk border-line'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good': return <CheckCircle size={24} className="text-pine-600" />
      case 'warning': return <Clock size={24} className="text-amber-600" />
      case 'expired': return <AlertTriangle size={24} className="text-clay-600" />
      default: return null
    }
  }

  return (
    <div className="rounded-3xl border border-line bg-surface p-6 shadow-card">
      <div className="flex items-center gap-3 mb-6">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-pine-100 text-pine-600">
          <Activity size={24} />
        </div>
        <div>
          <h2 className="text-xl font-display font-bold text-ink">Price & Shelf Life Predictor</h2>
          <p className="text-sm text-ink-3">Simulate optimal selling time and predicted market value</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-bold text-ink-3 uppercase tracking-wider mb-2">Crop</label>
          <select 
            value={selectedCrop} 
            onChange={(e) => setSelectedCrop(e.target.value)}
            className="w-full rounded-2xl border-2 border-line bg-surface px-4 py-3 text-ink focus:border-pine-400 focus:outline-none focus:ring-4 focus:ring-pine-400/20"
          >
            <option value="" disabled>Select Crop</option>
            {crops.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-bold text-ink-3 uppercase tracking-wider mb-2">Harvest Date</label>
          <div className="relative">
            <input 
              type="date" 
              value={harvestDate}
              onChange={(e) => setHarvestDate(e.target.value)}
              className="w-full rounded-2xl border-2 border-line bg-surface px-4 py-3 pl-12 text-ink focus:border-pine-400 focus:outline-none focus:ring-4 focus:ring-pine-400/20"
            />
            <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-3" size={20} />
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-4 text-sm font-bold text-clay-600 bg-clay-50 p-3 rounded-xl border border-clay-200">
          {error}
        </div>
      )}

      <button 
        onClick={handlePredict}
        disabled={loading}
        className="w-full py-3 rounded-2xl bg-ink text-white font-bold tracking-wide transition-all hover:bg-ink-1 hover:shadow-md disabled:opacity-50"
      >
        {loading ? 'Predicting...' : 'Run Simulation'}
      </button>

      {prediction && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 pt-8 border-t border-line"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className={cn("p-5 rounded-2xl border-2 flex flex-col items-center justify-center text-center", getStatusColor(prediction.status))}>
              <div className="mb-2">
                {getStatusIcon(prediction.status)}
              </div>
              <p className="text-xs font-bold uppercase tracking-widest opacity-80 mb-1">Predicted Price</p>
              <p className="text-3xl font-display font-black">{inr(prediction.predicted_price_per_q)}/q</p>
            </div>
            
            <div className={cn("p-5 rounded-2xl border-2 flex flex-col items-center justify-center text-center", getStatusColor(prediction.status))}>
              <div className="mb-2">
                <Droplets size={24} className="opacity-80" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest opacity-80 mb-1">Remaining Shelf Life</p>
              <div className="flex items-baseline gap-1">
                <p className="text-3xl font-display font-black">{prediction.remaining_shelf_life_days}</p>
                <p className="text-sm font-bold opacity-80">/ {prediction.total_shelf_life_days} days</p>
              </div>
            </div>
          </div>

          <div className="mt-4 p-4 bg-surface-sunk rounded-2xl">
            <p className="text-sm text-ink-2 leading-relaxed">
              <strong>Analysis:</strong> {prediction.message}
            </p>
          </div>
        </motion.div>
      )}
    </div>
  )
}
