import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { useI18n } from '@/lib/i18n'

// Fix default marker icons under Vite bundling (leaflet's default asset paths break otherwise).
const icon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41],
})

const TILE_URL = import.meta.env.VITE_MAP_TILE_URL || 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
const ATTRIBUTION = import.meta.env.VITE_MAP_ATTRIBUTION || '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'

export interface TrackingPointLite {
  id: string
  location: string | null
  latitude: number | null
  longitude: number | null
  status: string
  is_demo: boolean
}

export function TrackingMap({ points, height = 320 }: { points: TrackingPointLite[]; height?: number }) {
  const { t } = useI18n()
  const withCoords = points.filter(p => p.latitude != null && p.longitude != null)

  if (withCoords.length === 0) {
    return (
      <div className="flex items-center justify-center rounded-2xl border border-dashed border-line bg-surface-sunk text-sm text-ink-3" style={{ height }}>
        {t('tracking.noLocation')}
      </div>
    )
  }

  const center: [number, number] = [withCoords[withCoords.length - 1].latitude!, withCoords[withCoords.length - 1].longitude!]
  const path: [number, number][] = withCoords.map(p => [p.latitude!, p.longitude!])
  const isDemo = withCoords.some(p => p.is_demo)

  return (
    <div className="relative overflow-hidden rounded-2xl border border-line" style={{ height }}>
      {isDemo && (
        <span className="absolute right-2 top-2 z-[1000] rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold text-white shadow">
          {t('tracking.demoLabel')}
        </span>
      )}
      <MapContainer center={center} zoom={7} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
        <TileLayer url={TILE_URL} attribution={ATTRIBUTION} />
        {path.length > 1 && <Polyline positions={path} pathOptions={{ color: '#166534', weight: 3, dashArray: '6 6' }} />}
        {withCoords.map(p => (
          <Marker key={p.id} position={[p.latitude!, p.longitude!]} icon={icon}>
            <Popup>
              <strong>{t(`order.status.${p.status}`)}</strong><br />
              {p.location}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}
