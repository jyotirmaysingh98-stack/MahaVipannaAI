/**
 * MahaVipanan AI Frontend Types
 * Strictly aligned with the FastAPI backend contract (FRONTEND_API_CONTRACT.md).
 */

export interface ApiEnvelope<T> {
  success: boolean
  data?: T
  error?: string
  details?: any
  data_label: string
}

// FPO Types
export interface Fpo {
  id: string
  name: string
  district: string
  created_at: string
}

export interface FpoDashboard {
  fpo: Fpo
  active_lots: number
  total_inventory_q: number
}

// Lot Types
export interface LotMember {
  member_name: string
  quantity_kg: number
  grade?: string
}

export interface LotCreatePayload {
  crop_name: string
  harvest_date?: string
  members: LotMember[]
}

export interface LotResponse {
  id: string
  crop_name: string
  total_quantity_q: number
  status: string
  harvest_date?: string
  members: any[]
}

// Opportunity Types
export interface Buyer {
  id: string
  name: string
  type: string
  distance_km: number
  gross_price_per_qt: number
  transport_cost_per_qt: number
  loading_cost_per_qt: number
  commission_rate: number
  quality_deduction_per_qt: number
  misc_cost_per_qt: number
  min_quantity_qt: number
  max_quantity_qt: number
  location?: string
  payment_terms_days?: number
  reliability_score: number
  demand_signal?: string
  data_label: string
}

export interface ItemizedBreakdown {
  gross_price: number
  transport_cost: number
  loading_cost: number
  commission_amount: number
  quality_deduction: number
  misc_cost: number
}

export interface OpportunityMatchScore {
  total_score: number
  quantity_fit_score: number
  quality_fit_score: number
  nrp_score: number
  payment_terms_score: number
  reliability_score: number
  label: string
}

export interface OpportunityResponse {
  buyer: Buyer
  rank: number
  nrp_per_qt: number
  total_nrp: number
  breakdown: ItemizedBreakdown
  match_score: OpportunityMatchScore
  freight_override_applied: boolean
}

export interface DecisionRecommendation {
  action: 'sell' | 'hold' | 'redirect'
  recommended_buyer_name: string | null
  recommended_buyer_id: string | null
  justification_points: string[]
  ai_explanation: string | null
  freight_override_applied: boolean
  data_label: string
}

export interface OpportunitiesData {
  opportunities: OpportunityResponse[]
  recommendation: DecisionRecommendation
}

export interface RecalculatePayload {
  freight_cost: number
}
