from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_roles
from ..models.core import Order, OrderTracking, User, OrderStatus, generate_uuid
from ..schemas.core import OrderTrackingPointResponse, OrderTrackingCreate
from ..services.geocode import demo_route_for

orders_router = APIRouter(prefix="/api/orders", tags=["orders"])

ROLE_FIELD = {"farmer": "farmer_user_id", "buyer": "buyer_user_id", "fpo": "fpo_user_id"}


@orders_router.get("/")
def get_orders(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.role.value in ("delivery", "admin"):
        # Delivery partners aren't a negotiation party — they see all orders
        # that have moved past acceptance and need physical fulfilment.
        orders = db.query(Order).filter(Order.status != OrderStatus.negotiation).order_by(Order.updated_at.desc()).all()
    else:
        field = ROLE_FIELD.get(user.role.value)
        if not field:
            return {"success": True, "data": []}
        orders = db.query(Order).filter(getattr(Order, field) == user.id).order_by(Order.updated_at.desc()).all()
    return {
        "success": True,
        "data": [
            {
                "id": o.id, "crop_name": o.crop_name, "status": o.status,
                "agreed_price_per_q": o.agreed_price_per_q, "quantity_q": o.quantity_q,
                "created_at": o.created_at, "updated_at": o.updated_at,
            }
            for o in orders
        ],
    }


def _assert_can_view_order(order: Order, user: User):
    if user.role.value == "delivery" or user.role.value == "admin":
        return
    if user.id not in (order.farmer_user_id, order.buyer_user_id, order.fpo_user_id):
        raise HTTPException(status_code=403, detail="You cannot view this order")


@orders_router.get("/{order_id}/tracking")
def get_order_tracking(order_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    _assert_can_view_order(order, user)
    points = db.query(OrderTracking).filter(OrderTracking.order_id == order_id).order_by(OrderTracking.timestamp.asc()).all()
    return {"success": True, "data": [OrderTrackingPointResponse.model_validate(p) for p in points]}


@orders_router.post("/{order_id}/tracking")
def add_tracking_point(order_id: str, payload: OrderTrackingCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("delivery", "admin"))):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    point = OrderTracking(
        id=generate_uuid(), order_id=order_id, status=payload.status, location=payload.location,
        latitude=payload.latitude, longitude=payload.longitude, notes=payload.notes, is_demo=payload.is_demo,
    )
    db.add(point)
    order.status = payload.status
    db.commit()
    return {"success": True, "data": OrderTrackingPointResponse.model_validate(point)}


STATUS_SEQUENCE = ["pickup", "in_transit", "delivered"]


@orders_router.post("/{order_id}/tracking/advance-demo")
def advance_demo_tracking(order_id: str, db: Session = Depends(get_db), user: User = Depends(require_roles("delivery", "admin"))):
    """Moves a demo order to the next point on its deterministic simulated
    route — lets the Delivery dashboard demo end-to-end tracking without
    manual coordinate entry, while staying clearly labeled as demo data."""
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    existing = db.query(OrderTracking).filter(OrderTracking.order_id == order_id).order_by(OrderTracking.timestamp.asc()).all()
    next_index = min(len(existing), len(STATUS_SEQUENCE) - 1)
    route = demo_route_for(order_id)
    step = route[next_index]

    point = OrderTracking(
        id=generate_uuid(), order_id=order_id, status=OrderStatus(step["status"]),
        location=step["location"], latitude=step["lat"], longitude=step["lng"],
        is_demo=True, notes="Demo / simulated tracking",
    )
    db.add(point)
    order.status = OrderStatus(step["status"])
    db.commit()
    return {"success": True, "data": OrderTrackingPointResponse.model_validate(point)}
