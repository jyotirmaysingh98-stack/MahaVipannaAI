import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowRight,
  BarChart3,
  Layers,
  Package,
  TrendingUp,
  Wheat,
  MapPin,
  Warehouse,
  Users,
  Activity
} from 'lucide-react'
import { useApp } from '@/state/AppContext'
import { api } from '@/api/client'
import type { LotResponse } from '@/api/types'
import { qt, formatDate } from '@/lib/format'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Skeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'

type TabType = 'overview' | 'lots' | 'warehouse' | 'analytics'

export function DashboardPage() {
  const { fpo, fpoLoading } = useApp()
  const [lots, setLots] = useState<LotResponse[]>([])
  const [lotsLoading, setLotsLoading] = useState(true)
  const [totalInventory, setTotalInventory] = useState(0)
  const [activeLots, setActiveLots] = useState(0)
  const [activeTab, setActiveTab] = useState<TabType>('overview')

  useEffect(() => {
    // Load FPO dashboard stats
    api.getDashboard()
      .then(res => {
        if (res.data) {
          setTotalInventory(res.data.total_inventory_q)
          setActiveLots(res.data.active_lots)
        }
      })
      .catch(console.error)

    // Load lots list
    api.getLots()
      .then(res => {
        if (res.data) setLots(res.data)
      })
      .catch(console.error)
      .finally(() => setLotsLoading(false))
  }, [])

  return (
    <div className="pb-24">
      {/* Header */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="mb-8"
      >
        <motion.div variants={fadeUp} className="flex flex-wrap items-start justify-between gap-4 glass p-6 rounded-3xl mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-pine-500/10 rounded-full blur-3xl -z-10 translate-x-1/2 -translate-y-1/2" />
          <div>
            <p className="eyebrow text-pine-600">FPO Command Centre</p>
            {fpoLoading ? (
              <Skeleton className="mt-2 h-10 w-72 rounded-xl" />
            ) : (
              <h1 className="mt-1 font-display text-4xl font-bold tracking-tight text-ink">
                {fpo?.name ?? 'Welcome back'}
              </h1>
            )}
            <p className="mt-2 flex items-center text-sm text-ink-3">
              <MapPin size={14} className="mr-1" />
              {fpo?.district ? `${fpo.district} District` : 'Farmer Producer Organisation'}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" className="bg-white shadow-sm border-line/50">
              Download Report
            </Button>
            <Button className="bg-pine-600 hover:bg-pine-700 shadow-glow-pine">
              New Lot
            </Button>
          </div>
        </motion.div>

        {/* Custom Tabs */}
        <div className="flex gap-2 p-1.5 bg-surface-sunk rounded-2xl w-fit mb-8 border border-line">
          <TabButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} icon={<Activity size={16}/>}>Overview</TabButton>
          <TabButton active={activeTab === 'lots'} onClick={() => setActiveTab('lots')} icon={<Layers size={16}/>}>My Lots</TabButton>
          <TabButton active={activeTab === 'warehouse'} onClick={() => setActiveTab('warehouse')} icon={<Warehouse size={16}/>}>Warehouse</TabButton>
          <TabButton active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} icon={<BarChart3 size={16}/>}>Analytics</TabButton>
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div 
              key="overview"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {/* KPI Strip */}
              <div className="grid grid-cols-2 gap-5 sm:grid-cols-4 mb-8">
                <StatCard icon={<Layers size={22} />} label="Active lots" value={fpoLoading ? null : String(activeLots)} tone="pine" />
                <StatCard icon={<Package size={22} />} label="Total inventory" value={fpoLoading ? null : qt(totalInventory)} tone="teal" />
                <StatCard icon={<Users size={22} />} label="Total Farmers" value="142" tone="amber" />
                <StatCard icon={<BarChart3 size={22} />} label="Avg Realization" value="₹1,850/q" tone="indigo" />
              </div>

              {/* Intelligence Section */}
              <div className="glass rounded-3xl p-6 border-pine-200 shadow-sm relative overflow-hidden">
                <div className="absolute right-0 top-0 h-full w-1/3 bg-gradient-to-l from-pine-50/50 to-transparent pointer-events-none" />
                <div className="flex flex-wrap items-center gap-4 relative z-10">
                  <div className="h-14 w-14 rounded-2xl bg-pine-100 flex items-center justify-center text-pine-600 ring-1 ring-pine-200 shrink-0">
                    <TrendingUp size={28} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-display text-xl font-bold text-ink">Action Required: Onion Lot #4</h3>
                    <p className="mt-1 text-ink-2 max-w-2xl">
                      Nashik Exports Ltd is offering the highest net realization of <strong className="text-pine-700">₹1,920/qt</strong> after all deductions. 
                      Recommend selling immediately to avoid quality degradation.
                    </p>
                  </div>
                  <Button className="bg-pine-600 shadow-glow-pine">View Decision</Button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'lots' && (
            <motion.div 
              key="lots"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="mb-6 flex items-center justify-between">
                <h2 className="font-display text-2xl font-semibold text-ink">Active Lots (Farmer Grouped)</h2>
                <div className="flex gap-2">
                  <select className="text-sm rounded-xl border border-line bg-surface px-3 py-1.5 focus:outline-pine-500">
                    <option>All Crops</option>
                    <option>Onion</option>
                    <option>Soybean</option>
                  </select>
                </div>
              </div>

              {lotsLoading ? (
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {[0, 1, 2].map(i => <Skeleton key={i} className="h-56 rounded-3xl" />)}
                </div>
              ) : lots.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-line bg-surface p-16 text-center">
                  <Wheat size={40} className="mx-auto mb-4 text-ink-3 opacity-50" />
                  <p className="font-semibold text-lg text-ink">No lots yet</p>
                  <p className="mt-2 text-ink-3">Seed the database or create a lot to get started.</p>
                </div>
              ) : (
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 preserve-3d">
                  {lots.map((lot, i) => (
                    <LotCard key={lot.id} lot={lot} index={i} />
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'warehouse' && (
            <motion.div 
              key="warehouse"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="glass p-8 rounded-3xl text-center"
            >
              <Warehouse size={48} className="mx-auto mb-4 text-ink-3 opacity-50" />
              <h2 className="font-display text-2xl font-semibold text-ink">Warehouse Management</h2>
              <p className="text-ink-2 mt-2 max-w-md mx-auto">
                Track exact farmer inventory, storage types (cold/dry), and aging of produce inside the warehouse.
              </p>
              <Button className="mt-6">View Inventory Details</Button>
            </motion.div>
          )}

          {activeTab === 'analytics' && (
            <motion.div 
              key="analytics"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="glass p-8 rounded-3xl text-center"
            >
              <BarChart3 size={48} className="mx-auto mb-4 text-ink-3 opacity-50" />
              <h2 className="font-display text-2xl font-semibold text-ink">FPO Analytics & History</h2>
              <p className="text-ink-2 mt-2 max-w-md mx-auto">
                Historical decisions, average NRP trends, buyer reliability metrics, and gross vs. net comparisons.
              </p>
              <Button className="mt-6">Generate Report</Button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}

function TabButton({ active, onClick, children, icon }: any) {
  return (
    <button
      onClick={onClick}
      className={`relative flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors z-10 ${
        active ? 'text-ink shadow-sm bg-white border border-line/50' : 'text-ink-3 hover:text-ink hover:bg-white/50'
      }`}
    >
      {icon} {children}
    </button>
  )
}

function LotCard({ lot, index }: { lot: LotResponse; index: number }) {
  const statusColor =
    lot.status === 'ready'
      ? 'bg-pine-100 text-pine-800 ring-pine-300'
      : lot.status === 'sold'
      ? 'bg-surface-sunk text-ink-3 ring-line'
      : 'bg-amber-100 text-amber-800 ring-amber-300'

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, rotateX: 5 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
    >
      <Link
        to={`/app/lots/${lot.id}`}
        className="group block rounded-3xl border border-line bg-surface p-6 shadow-card transition-all hover:border-pine-300 hover:shadow-lg focus-visible:outline-pine-500 preserve-3d"
      >
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-pine-50 text-pine-600 ring-1 ring-inset ring-pine-100 group-hover:scale-105 transition-transform">
            <Wheat size={24} />
          </div>
          <span className={`mt-0.5 rounded-full px-3 py-1 text-xs font-bold uppercase ring-1 ring-inset ${statusColor}`}>
            {lot.status}
          </span>
        </div>

        <h3 className="font-display text-2xl font-bold text-ink">{lot.crop_name}</h3>
        <p className="tnum mt-1 text-lg font-semibold text-pine-600">{qt(lot.total_quantity_q)}</p>

        <div className="mt-4 pt-4 border-t border-line/50 space-y-2 text-sm text-ink-2">
          {lot.harvest_date && (
            <p className="flex justify-between"><span>Harvested:</span> <strong className="text-ink">{formatDate(lot.harvest_date)}</strong></p>
          )}
          {lot.members.length > 0 && (
            <div className="bg-surface-sunk rounded-xl p-3 mt-2">
              <p className="flex justify-between items-center text-xs font-semibold uppercase tracking-wider text-ink-3 mb-2">Farmers Included</p>
              <div className="space-y-1.5">
                {lot.members.slice(0, 3).map(m => (
                  <div key={m.member_name} className="flex justify-between text-xs">
                    <span className="truncate pr-2">{m.member_name}</span>
                    <strong className="text-ink tnum shrink-0">{m.quantity_kg} kg</strong>
                  </div>
                ))}
                {lot.members.length > 3 && (
                  <div className="text-xs text-pine-600 font-medium">
                    +{lot.members.length - 3} more farmers
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="mt-5 flex items-center justify-between text-sm font-bold text-pine-600 opacity-0 transition-all group-hover:opacity-100 translate-y-2 group-hover:translate-y-0">
          <span>Opportunity Radar</span>
          <ArrowRight size={16} />
        </div>
      </Link>
    </motion.div>
  )
}

function StatCard({ icon, label, value, tone }: any) {
  const tones = {
    pine: 'bg-pine-50 text-pine-600 ring-pine-200 border-pine-100',
    teal: 'bg-teal-50 text-teal-600 ring-teal-200 border-teal-100',
    indigo: 'bg-indigo-50 text-indigo-600 ring-indigo-200 border-indigo-100',
    amber: 'bg-amber-50 text-amber-600 ring-amber-200 border-amber-100',
  }
  return (
    <div className={`rounded-3xl border bg-surface p-5 shadow-card transition-shadow hover:shadow-lg ${tones[tone as keyof typeof tones]}`}>
      <span className={`grid h-12 w-12 place-items-center rounded-2xl ring-1 ring-inset bg-white/50 backdrop-blur-sm ${tones[tone as keyof typeof tones]}`}>
        {icon}
      </span>
      <p className="mt-4 text-sm font-medium text-ink-3">{label}</p>
      {value === null ? (
        <Skeleton className="mt-1 h-8 w-24 rounded-lg" />
      ) : (
        <p className="tnum mt-1 font-display text-3xl font-bold text-ink">{value}</p>
      )}
    </div>
  )
}
