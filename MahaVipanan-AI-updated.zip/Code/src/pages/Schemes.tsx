import { useEffect, useState } from 'react'
import { ExternalLink, Landmark, Loader2, Plus } from 'lucide-react'
import { useI18n } from '@/lib/i18n'
import { useApp } from '@/state/AppContext'
import { api } from '@/api/client'
import type { GovernmentScheme } from '@/api/types'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/lib/cn'

const EMPTY_FORM = {
  title: '', description: '', benefits: '', eligibility: '', official_url: '',
  state: '', district: '', crops: '', target_role: 'all', deadline: '',
}

export default function SchemesPage() {
  const { t } = useI18n()
  const { role } = useApp()
  const toast = useToast()
  const [schemes, setSchemes] = useState<GovernmentScheme[]>([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState(EMPTY_FORM)
  const [submitting, setSubmitting] = useState(false)
  const isGovt = role === 'government' || role === 'admin'

  const load = () => {
    setLoading(true)
    api.listSchemes().then(res => setSchemes(res.data || [])).catch(() => {}).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const submit = async () => {
    if (!form.title.trim() || !form.description.trim()) {
      toast.toast({ title: t('negotiation.form.incomplete'), tone: 'info' })
      return
    }
    setSubmitting(true)
    try {
      await api.createScheme({ ...form, deadline: form.deadline || null } as any)
      toast.toast({ title: t('schemes.published'), tone: 'success' })
      setForm(EMPTY_FORM)
      load()
    } catch (e: any) {
      toast.toast({ title: e.message || t('schemes.error.publish'), tone: 'info' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 space-y-8">
      <div className="flex items-center gap-3">
        <Landmark className="text-pine-600" size={28} />
        <div>
          <h1 className="font-display text-2xl font-black text-ink">{t('schemes.title')}</h1>
          <p className="text-sm text-ink-3">{t('schemes.pageSubtitle')}</p>
        </div>
      </div>

      {isGovt && (
        <div className="rounded-3xl border border-line bg-surface p-6 shadow-card space-y-3">
          <h2 className="font-display text-lg font-bold text-ink flex items-center gap-2"><Plus size={18} /> {t('schemes.publishNew')}</h2>
          <input placeholder={t('schemes.form.title')} value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
            className="w-full rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
          <textarea placeholder={t('schemes.form.description')} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            className="w-full rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" rows={2} />
          <div className="grid grid-cols-2 gap-3">
            <input placeholder={t('schemes.form.benefits')} value={form.benefits} onChange={e => setForm(f => ({ ...f, benefits: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
            <input placeholder={t('schemes.form.eligibility')} value={form.eligibility} onChange={e => setForm(f => ({ ...f, eligibility: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <input placeholder={t('schemes.form.state')} value={form.state} onChange={e => setForm(f => ({ ...f, state: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
            <input placeholder={t('schemes.form.crops')} value={form.crops} onChange={e => setForm(f => ({ ...f, crops: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
            <select value={form.target_role} onChange={e => setForm(f => ({ ...f, target_role: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm">
              <option value="all">{t('schemes.form.allRoles')}</option>
              <option value="farmer">{t('role.farmer')}</option>
              <option value="fpo">{t('role.fpo')}</option>
              <option value="buyer">{t('role.buyer')}</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input placeholder={t('schemes.form.officialUrl')} value={form.official_url} onChange={e => setForm(f => ({ ...f, official_url: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
            <input type="date" value={form.deadline} onChange={e => setForm(f => ({ ...f, deadline: e.target.value }))}
              className="rounded-xl border border-line bg-surface-sunk px-3 py-2.5 text-sm" />
          </div>
          <button onClick={submit} disabled={submitting} className="rounded-xl bg-pine-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-pine-700 disabled:opacity-60">
            {submitting ? <Loader2 className="animate-spin" size={16} /> : t('schemes.publishNew')}
          </button>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="animate-spin text-pine-600" /></div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {schemes.map(s => (
            <div key={s.id} className="rounded-3xl border border-line bg-surface p-5 shadow-card space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-ink">{s.title}</h3>
                <span className={cn('rounded-full px-2 py-0.5 text-[10px] font-bold',
                  s.relevance_label === 'Relevant to you' ? 'bg-pine-50 text-pine-700' : s.relevance_label === 'Potentially relevant' ? 'bg-amber-50 text-amber-700' : 'bg-surface-sunk text-ink-3')}>
                  {t(`schemes.relevance.${s.relevance_label === 'Relevant to you' ? 'relevant' : s.relevance_label === 'Potentially relevant' ? 'potential' : 'general'}`)}
                </span>
              </div>
              <p className="text-sm text-ink-3">{s.description}</p>
              <p className="text-xs text-ink-3"><span className="font-bold text-ink">{t('schemes.benefits')}:</span> {s.benefits}</p>
              {s.official_url && (
                <a href={s.official_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs font-bold text-pine-700 hover:underline">
                  {t('schemes.visitOfficial')} <ExternalLink size={12} />
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
