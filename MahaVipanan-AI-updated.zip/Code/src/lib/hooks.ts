import { useCallback, useEffect, useRef, useState } from 'react'

/** Tracks a CSS media query. */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia(query).matches : false,
  )
  useEffect(() => {
    const mql = window.matchMedia(query)
    const onChange = () => setMatches(mql.matches)
    onChange()
    mql.addEventListener('change', onChange)
    return () => mql.removeEventListener('change', onChange)
  }, [query])
  return matches
}

/** True when the reader has asked for reduced motion. */
export function useReducedMotion(): boolean {
  return useMediaQuery('(prefers-reduced-motion: reduce)')
}

/**
 * Count-up hook for hero numbers. Eases toward `value`; snaps instantly when
 * reduced motion is requested. Re-animates whenever `value` changes.
 */
export function useCountUp(value: number, opts: { duration?: number; enabled?: boolean } = {}): number {
  const { duration = 900, enabled = true } = opts
  const reduce = useReducedMotion()
  const [display, setDisplay] = useState(value)
  const fromRef = useRef(value)
  const rafRef = useRef<number>()

  useEffect(() => {
    if (!enabled || reduce) {
      setDisplay(value)
      fromRef.current = value
      return
    }
    const from = fromRef.current
    const delta = value - from
    if (delta === 0) return
    let start: number | null = null

    const tick = (t: number) => {
      if (start === null) start = t
      const p = Math.min(1, (t - start) / duration)
      // easeOutCubic
      const eased = 1 - Math.pow(1 - p, 3)
      setDisplay(from + delta * eased)
      if (p < 1) {
        rafRef.current = requestAnimationFrame(tick)
      } else {
        fromRef.current = value
      }
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      fromRef.current = value
    }
  }, [value, duration, enabled, reduce])

  return display
}

/**
 * Cursor-reactive spotlight. Attach the returned ref + onMouseMove to a
 * `.spotlight` element; it writes --spotlight-x/y CSS vars so the radial
 * highlight follows the pointer. No-ops under reduced motion.
 */
export function useSpotlight<T extends HTMLElement>() {
  const ref = useRef<T>(null)
  const reduce = useReducedMotion()

  const onMouseMove = useCallback(
    (e: React.MouseEvent<T>) => {
      if (reduce) return
      const el = ref.current
      if (!el) return
      const rect = el.getBoundingClientRect()
      el.style.setProperty('--spotlight-x', `${e.clientX - rect.left}px`)
      el.style.setProperty('--spotlight-y', `${e.clientY - rect.top}px`)
    },
    [reduce],
  )

  return { ref, onMouseMove }
}

/** Runs a one-shot effect after mount (client only), for entrance triggers. */
export function useMounted(): boolean {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  return mounted
}
