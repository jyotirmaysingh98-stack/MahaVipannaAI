import { useState } from 'react'
import { motion } from 'framer-motion'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { ShieldAlert, FileWarning, Search, Ban, CheckCircle2, AlertTriangle, Warehouse } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { formatDate } from '@/lib/format'

type TabType = 'users' | 'complaints' | 'fraud' | 'warehouse'

export function AdminPage() {
  const [activeTab, setActiveTab] = useState<TabType>('users')

  return (
    <div className="pb-24">
      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={fadeUp} className="mb-6 flex justify-between items-end">
          <div>
            <h1 className="font-display text-4xl font-bold tracking-tight text-ink">Admin Command Center</h1>
            <p className="mt-2 text-ink-3">Platform moderation, fraud detection, and capacity management.</p>
          </div>
          <div className="flex bg-surface-sunk p-1.5 rounded-xl border border-line overflow-x-auto max-w-full">
            <button onClick={() => setActiveTab('users')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'users' ? 'bg-white shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>Users & Bans</button>
            <button onClick={() => setActiveTab('complaints')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'complaints' ? 'bg-white shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>Complaints</button>
            <button onClick={() => setActiveTab('fraud')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'fraud' ? 'bg-white shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>Fraud Engine</button>
            <button onClick={() => setActiveTab('warehouse')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'warehouse' ? 'bg-white shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>Warehouses</button>
          </div>
        </motion.div>

        {activeTab === 'users' && (
          <motion.div variants={fadeUp} className="space-y-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-3" />
                <input type="text" placeholder="Search FPOs, buyers, farmers..." className="w-full bg-surface border border-line rounded-2xl pl-12 pr-4 py-3 text-sm focus:outline-pine-500" />
              </div>
              <Button variant="secondary" className="bg-white">Filter Active</Button>
            </div>
            
            <div className="glass rounded-3xl overflow-hidden border border-line">
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-sunk/80 border-b border-line text-ink-3">
                  <tr>
                    <th className="p-4 font-semibold">User / Entity</th>
                    <th className="p-4 font-semibold">Type</th>
                    <th className="p-4 font-semibold">Joined</th>
                    <th className="p-4 font-semibold">Status</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/50">
                  <tr className="bg-white/40 hover:bg-white/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Nashik Exports Ltd</td>
                    <td className="p-4 text-ink-2">Buyer</td>
                    <td className="p-4 text-ink-2">{formatDate('2026-01-15')}</td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-pine-100 text-pine-700 text-xs font-bold ring-1 ring-pine-200">Active</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-clay-600 hover:bg-clay-50"><Ban size={14} className="mr-1.5" /> Suspend</Button>
                    </td>
                  </tr>
                  <tr className="bg-white/40 hover:bg-white/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Ramesh Patel (FPO)</td>
                    <td className="p-4 text-ink-2">FPO Admin</td>
                    <td className="p-4 text-ink-2">{formatDate('2026-03-22')}</td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-clay-100 text-clay-700 text-xs font-bold ring-1 ring-clay-200">Suspended</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-pine-600 hover:bg-pine-50"><CheckCircle2 size={14} className="mr-1.5" /> Reactivate</Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {activeTab === 'complaints' && (
          <motion.div variants={fadeUp} className="grid lg:grid-cols-2 gap-6">
            <div className="glass rounded-3xl p-6 border-line">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display font-semibold text-lg flex items-center gap-2"><FileWarning size={18} className="text-amber-500" /> Pending Disputes</h3>
                <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs font-bold">2 Action Required</span>
              </div>
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-white border border-line shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold text-ink-3">Ticket #9201</span>
                    <span className="text-xs text-ink-3">{formatDate('2026-09-02')}</span>
                  </div>
                  <p className="font-semibold text-ink">Quality mismatch on arrival</p>
                  <p className="text-sm text-ink-2 mt-1">Buyer claims Grade B delivered instead of Grade A.</p>
                  <div className="mt-4 flex gap-2">
                    <Button size="sm" className="bg-amber-600 text-white w-full">Investigate</Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'fraud' && (
          <motion.div variants={fadeUp} className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="glass rounded-3xl p-6 border-clay-200">
                <ShieldAlert size={32} className="text-clay-500 mb-4" />
                <h3 className="font-display font-bold text-xl text-ink">Price Manipulation</h3>
                <p className="text-sm text-ink-2 mt-2">Engine detected abnormally low bids from an IP cluster in Pune.</p>
                <Button size="sm" className="mt-4 w-full bg-clay-600 text-white">Review Flagged Bids</Button>
              </div>
              <div className="glass rounded-3xl p-6 border-amber-200">
                <AlertTriangle size={32} className="text-amber-500 mb-4" />
                <h3 className="font-display font-bold text-xl text-ink">Ghost Profiles</h3>
                <p className="text-sm text-ink-2 mt-2">12 buyer profiles created today without GSTIN verification.</p>
                <Button size="sm" className="mt-4 w-full bg-amber-600 text-white">Require KYC</Button>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'warehouse' && (
          <motion.div variants={fadeUp} className="space-y-6">
            <div className="glass rounded-3xl p-6 border-line overflow-hidden">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display font-semibold text-lg flex items-center gap-2"><Warehouse size={18} className="text-pine-600" /> Storage Capacity Network</h3>
                <Button size="sm">Add Facility</Button>
              </div>
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-sunk/80 border-b border-line text-ink-3">
                  <tr>
                    <th className="p-4 font-semibold">Facility Name</th>
                    <th className="p-4 font-semibold">Location</th>
                    <th className="p-4 font-semibold">Capacity Utilization</th>
                    <th className="p-4 font-semibold">Condition</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/50">
                  <tr className="bg-white/40 hover:bg-white/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Central Govt Silo A</td>
                    <td className="p-4 text-ink-2">Nashik, MH</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-full bg-line rounded-full overflow-hidden max-w-[100px]">
                          <div className="h-full bg-amber-500 w-[85%]"></div>
                        </div>
                        <span className="text-xs font-semibold text-ink-2">85%</span>
                      </div>
                    </td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-pine-100 text-pine-700 text-xs font-bold ring-1 ring-pine-200">Optimal</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-ink-2">Manage</Button>
                    </td>
                  </tr>
                  <tr className="bg-white/40 hover:bg-white/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Private Cold Storage 2</td>
                    <td className="p-4 text-ink-2">Pune, MH</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-full bg-line rounded-full overflow-hidden max-w-[100px]">
                          <div className="h-full bg-clay-500 w-[98%]"></div>
                        </div>
                        <span className="text-xs font-semibold text-clay-600">98%</span>
                      </div>
                    </td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-clay-100 text-clay-700 text-xs font-bold ring-1 ring-clay-200">Full</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-ink-2">Manage</Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}
