import { motion } from 'framer-motion'
import { Truck, Clock, Route } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'

export function DeliveryDashboard() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">Logistics Tracking</h1>
        <p className="mt-1 text-ink-2">Manage your assigned routes, pickups, and deliveries.</p>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-50 text-pine-600">
              <Truck size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Assigned Orders</p>
              <p className="text-2xl font-bold text-ink">4 Active</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-50 text-amber-600">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Pending Pickups</p>
              <p className="text-2xl font-bold text-ink">2 Locations</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">Current Route</h2>
          <div className="rounded-2xl border border-line bg-surface p-6 text-center h-64 flex flex-col justify-center items-center">
            <Route className="text-ink-3 mb-4" size={32} />
            <p className="text-ink-2 font-medium">GPS Tracking View</p>
            <p className="text-xs text-ink-3 mt-2">Simulated map view for active route</p>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">Task List</h2>
          <div className="rounded-2xl border border-line bg-surface p-6">
             <div className="space-y-4">
               <div className="flex justify-between items-center pb-4 border-b border-line">
                 <div>
                   <p className="font-semibold text-ink">Pickup: Nashik FPO Hub</p>
                   <p className="text-xs text-ink-3">500 qt Onion</p>
                 </div>
                 <button className="px-3 py-1 bg-pine-100 text-pine-700 font-semibold text-xs rounded-full">Mark Picked Up</button>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  )
}
