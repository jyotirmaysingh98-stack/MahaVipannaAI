"""Deterministic negotiation-zone logic. This is the source of truth for
price safety — AI text only explains/wraps these numbers, never overrides
them (see AI_RESPONSE_SAFETY requirement)."""
from typing import Optional

from . import ai_provider


def price_zone(offer: float, msp: Optional[float], isp: Optional[float]) -> str:
    """Returns 'below_min' | 'negotiable' | 'strong' | 'unknown'."""
    if msp is None or isp is None:
        return "unknown"
    if offer < msp:
        return "below_min"
    if offer >= isp:
        return "strong"
    return "negotiable"


def deterministic_counter_range(offer: float, msp: Optional[float], isp: Optional[float]) -> dict:
    """A conservative suggested counter-offer band the seller side could ask
    for, purely from the numbers already on record — no AI involved."""
    if msp is None or isp is None:
        # No reference prices available; suggest a modest 3-6% bump as a safe default.
        return {"low": round(offer * 1.03, 2), "high": round(offer * 1.06, 2)}
    zone = price_zone(offer, msp, isp)
    if zone == "below_min":
        return {"low": msp, "high": round((msp + isp) / 2, 2)}
    if zone == "negotiable":
        return {"low": round((offer + isp) / 2, 2), "high": isp}
    return {"low": offer, "high": round(offer * 1.02, 2)}


async def build_negotiation_suggestion(*, crop: str, quantity_q: float, current_offer: float,
                                        msp: Optional[float], isp: Optional[float],
                                        history_summary: str, user_role: str, lang: str = "en") -> dict:
    zone = price_zone(current_offer, msp, isp)
    counter_range = deterministic_counter_range(current_offer, msp, isp)

    fallback_by_zone = {
        "below_min": f"This offer of ₹{current_offer}/qt is below the safe floor. Consider countering around ₹{counter_range['low']}–₹{counter_range['high']}/qt and explaining the quality and reliability of the lot.",
        "negotiable": f"This offer is workable but has room to improve. A fair counter would be ₹{counter_range['low']}–₹{counter_range['high']}/qt, citing recent market rates.",
        "strong": f"This is already a strong offer close to or above the ideal price. Consider accepting, or asking for a small improvement to ₹{counter_range['high']}/qt at most.",
        "unknown": f"No minimum/ideal price is on record for this negotiation. A modest counter around ₹{counter_range['low']}–₹{counter_range['high']}/qt is a reasonable starting point.",
    }
    fallback_text = fallback_by_zone[zone]

    prompt = (
        f"Crop: {crop}. Quantity: {quantity_q} quintals. Current offer: Rs.{current_offer}/qt. "
        f"Minimum safe price: {msp if msp is not None else 'not set'}. Ideal price: {isp if isp is not None else 'not set'}. "
        f"Price zone (already computed, do not recompute): {zone}. "
        f"Suggested counter-offer range (already computed, do not recompute): Rs.{counter_range['low']}-Rs.{counter_range['high']}/qt. "
        f"Recent negotiation history: {history_summary or 'none yet'}. "
        f"You are advising the {user_role} side. Write a short, practical negotiation suggestion and one polite "
        f"sample message they could send, using ONLY the numbers given above. Do not state this as guaranteed market truth."
    )
    system = (
        "You are an AI negotiation assistant for an Indian agricultural marketplace app. "
        "Be conservative, factual, and clearly label suggestions as AI-assisted, not guaranteed. "
        + ai_provider.lang_instruction(lang)
    )

    result = await ai_provider.get_ai_text(prompt, system=system, fallback=fallback_text)
    return {
        "zone": zone,
        "suggested_counter_low": counter_range["low"],
        "suggested_counter_high": counter_range["high"],
        "ai_text": result["text"],
        "ai_source": result["source"],
    }
