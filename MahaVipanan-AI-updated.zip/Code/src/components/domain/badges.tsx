import { CheckCircle2, PauseCircle, Route, type LucideIcon } from 'lucide-react'
import { cn } from '@/lib/cn'
export type Recommendation = 'SELL' | 'HOLD' | 'REDIRECT'
export type MatchBand = 'Excellent' | 'Good' | 'Fair' | 'Poor' | string
export type BuyerType = 'APMC' | 'DIRECT_BUYER' | 'PROCESSOR' | 'EXPORTER' | string
export type DemandLevel = 'HIGH' | 'MEDIUM' | 'LOW' | string
import { Badge } from '@/components/ui/Badge'

// ── Recommendation ────────────────────────────────────────────────────────────
const REC: Record<Recommendation, { label: string; icon: LucideIcon; cls: string }> = {
  SELL: { label: 'Sell now', icon: CheckCircle2, cls: 'bg-pine-500 text-white shadow-glow-pine' },
  HOLD: { label: 'Hold', icon: PauseCircle, cls: 'bg-amber-400 text-amber-900 shadow-glow-amber' },
  REDIRECT: { label: 'Redirect', icon: Route, cls: 'bg-teal-500 text-white shadow-glow-teal' },
}

export function RecommendationPill({
  recommendation,
  size = 'md',
  className,
}: {
  recommendation: Recommendation
  size?: 'sm' | 'md' | 'lg'
  className?: string
}) {
  const r = REC[recommendation]
  const Icon = r.icon
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 rounded-full font-semibold tracking-tight',
        size === 'sm' && 'px-2.5 py-1 text-xs',
        size === 'md' && 'px-3.5 py-1.5 text-sm',
        size === 'lg' && 'px-4 py-2 text-base',
        r.cls,
        className,
      )}
    >
      <Icon size={size === 'lg' ? 18 : size === 'md' ? 15 : 13} strokeWidth={2.5} />
      {r.label}
    </span>
  )
}

// ── Match band ────────────────────────────────────────────────────────────────
const BAND_TONE: Record<string, 'pine' | 'teal' | 'amber' | 'clay'> = {
  Excellent: 'pine',
  Good: 'teal',
  Fair: 'amber',
  Poor: 'clay',
}

export function MatchBandBadge({ band, score, className }: { band: MatchBand; score?: number; className?: string }) {
  return (
    <Badge tone={BAND_TONE[band] || 'clay'} className={className}>
      {band}
      {typeof score === 'number' && <span className="tnum opacity-70">· {score}</span>}
    </Badge>
  )
}

// ── Buyer type ──────────────────────────────────────────────────────────────
const BUYER_TYPE_LABEL: Record<string, string> = {
  APMC: 'Mandi (APMC)',
  DIRECT_BUYER: 'Direct buyer',
  PROCESSOR: 'Processor',
  EXPORTER: 'Exporter',
}

export function buyerTypeLabel(type: BuyerType): string {
  return BUYER_TYPE_LABEL[type]
}

export function BuyerTypeChip({ type, className }: { type: BuyerType; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md bg-surface-sunk px-2 py-0.5 text-[0.7rem] font-medium text-ink-2 ring-1 ring-inset ring-line',
        className,
      )}
    >
      {BUYER_TYPE_LABEL[type] || type}
    </span>
  )
}

// ── Demand level ──────────────────────────────────────────────────────────────
const DEMAND: Record<string, { label: string; dot: string }> = {
  HIGH: { label: 'High demand', dot: 'bg-pine-500' },
  MEDIUM: { label: 'Medium demand', dot: 'bg-amber-400' },
  LOW: { label: 'Low demand', dot: 'bg-clay-500' },
}

export function DemandIndicator({ level, className }: { level: DemandLevel; className?: string }) {
  const d = DEMAND[level]
  return (
    <span className={cn('inline-flex items-center gap-1.5 text-xs text-ink-2', className)}>
      <span className={cn('h-1.5 w-1.5 rounded-full', d?.dot || 'bg-clay-500')} />
      {d?.label || level}
    </span>
  )
}
