import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Truck, CheckCircle2, Clock, Package, Route, Navigation } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { qt, formatDate } from '@/lib/format'
import { Skeleton } from '@/components/ui/Skeleton'

type OrderStatus = 'pending' | 'in_transit' | 'delivered'

interface Order {
  id: string
  buyerName: string
  cropName: string
  quantityQt: number
  status: OrderStatus
  date: string
  truckId: string
  driverName: string
  eta: string
}

const DUMMY_ORDERS: Order[] = [
  {
    id: 'ORD-8291',
    buyerName: 'Nashik Exports Ltd',
    cropName: 'Onion (Grade A)',
    quantityQt: 250,
    status: 'in_transit',
    date: '2026-09-03',
    truckId: 'MH-15-AB-1234',
    driverName: 'Ramesh Patil',
    eta: '45 mins'
  },
  {
    id: 'ORD-8290',
    buyerName: 'FreshMart Retail',
    cropName: 'Soybean (Grade B)',
    quantityQt: 120,
    status: 'delivered',
    date: '2026-09-01',
    truckId: 'MH-12-CD-5678',
    driverName: 'Suresh Kumar',
    eta: 'Delivered'
  }
]

export function OrdersPage() {
  const [loading, setLoading] = useState(true)
  const [orders, setOrders] = useState<Order[]>([])
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  useEffect(() => {
    // Simulate API fetch
    const timer = setTimeout(() => {
      setOrders(DUMMY_ORDERS)
      setSelectedOrder(DUMMY_ORDERS[0])
      setLoading(false)
    }, 800)
    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48 rounded-xl" />
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <Skeleton className="h-32 rounded-3xl" />
            <Skeleton className="h-32 rounded-3xl" />
          </div>
          <div className="lg:col-span-2">
            <Skeleton className="h-[500px] rounded-3xl" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="pb-24">
      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={fadeUp} className="mb-6">
          <h1 className="font-display text-4xl font-bold tracking-tight text-ink">Active Deliveries</h1>
          <p className="mt-2 text-ink-3">Track live shipments and delivery partners</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Order List */}
          <motion.div variants={fadeUp} className="lg:col-span-1 space-y-4">
            {orders.map(order => (
              <button
                key={order.id}
                onClick={() => setSelectedOrder(order)}
                className={`w-full text-left p-5 rounded-3xl border transition-all ${
                  selectedOrder?.id === order.id 
                    ? 'border-pine-300 shadow-card-lg bg-pine-50 ring-1 ring-pine-500/10' 
                    : 'border-line bg-surface hover:border-pine-200'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-pine-600">{order.id}</span>
                  <StatusBadge status={order.status} />
                </div>
                <h3 className="font-display text-lg font-bold text-ink">{order.buyerName}</h3>
                <p className="text-sm font-medium text-ink-2 mt-1">{order.cropName} • {qt(order.quantityQt)}</p>
                
                <div className="mt-4 pt-3 border-t border-line/50 flex items-center justify-between text-xs text-ink-3">
                  <span className="flex items-center gap-1.5"><Clock size={14}/> {formatDate(order.date)}</span>
                  <span className="flex items-center gap-1.5"><Truck size={14}/> {order.truckId}</span>
                </div>
              </button>
            ))}
          </motion.div>

          {/* Map / Tracking View */}
          <motion.div variants={fadeUp} className="lg:col-span-2 relative">
            <AnimatePresence mode="wait">
              {selectedOrder && (
                <motion.div
                  key={selectedOrder.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="glass rounded-3xl overflow-hidden shadow-card border border-line h-[600px] flex flex-col relative"
                >
                  {/* Map Mockup Background */}
                  <div className="absolute inset-0 bg-surface-sunk opacity-50 z-0">
                    <div className="absolute inset-0 bg-[url('https://maps.googleapis.com/maps/api/staticmap?center=Nashik,India&zoom=11&size=800x600&maptype=roadmap&style=feature:all|element:labels.text.fill|color:0x333333&style=feature:landscape|element:all|color:0xf5f5f5&key=DUMMY')] bg-cover bg-center mix-blend-luminosity opacity-40"></div>
                  </div>

                  {/* Top Overlay Info */}
                  <div className="relative z-10 bg-white/80 backdrop-blur-md border-b border-line p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h2 className="font-display text-2xl font-bold text-ink">{selectedOrder.buyerName}</h2>
                        <p className="text-sm font-medium text-ink-3 mt-1">Delivery ETA: <strong className="text-pine-600">{selectedOrder.eta}</strong></p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-ink">Driver: {selectedOrder.driverName}</p>
                        <p className="text-xs text-ink-3">{selectedOrder.truckId}</p>
                      </div>
                    </div>
                  </div>

                  {/* Route Timeline */}
                  <div className="relative z-10 mt-auto bg-white/90 backdrop-blur-xl border-t border-line p-6">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-ink-3 mb-6">Delivery Progress</h3>
                    
                    <div className="relative flex justify-between">
                      {/* Progress Line */}
                      <div className="absolute top-4 left-0 w-full h-1 bg-line rounded-full">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: selectedOrder.status === 'delivered' ? '100%' : selectedOrder.status === 'in_transit' ? '50%' : '0%' }}
                          className="absolute top-0 left-0 h-full bg-pine-500 rounded-full"
                          transition={{ duration: 1, ease: 'easeOut' }}
                        />
                      </div>

                      <Step icon={Package} label="Dispatched" active={true} />
                      <Step icon={Route} label="In Transit" active={selectedOrder.status === 'in_transit' || selectedOrder.status === 'delivered'} current={selectedOrder.status === 'in_transit'} />
                      <Step icon={CheckCircle2} label="Delivered" active={selectedOrder.status === 'delivered'} current={selectedOrder.status === 'delivered'} />
                    </div>
                  </div>

                  {/* Dummy Marker */}
                  {selectedOrder.status === 'in_transit' && (
                    <motion.div 
                      className="absolute z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-pine-500 text-white p-3 rounded-full shadow-glow-pine flex items-center gap-2"
                      animate={{ y: [0, -10, 0] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                    >
                      <Navigation size={20} className="fill-current" />
                      <span className="font-bold text-sm">Live</span>
                    </motion.div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </motion.div>
    </div>
  )
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const config = {
    pending: { color: 'bg-amber-100 text-amber-800 ring-amber-300', label: 'Pending' },
    in_transit: { color: 'bg-indigo-100 text-indigo-800 ring-indigo-300', label: 'In Transit' },
    delivered: { color: 'bg-pine-100 text-pine-800 ring-pine-300', label: 'Delivered' }
  }
  const c = config[status]
  
  return (
    <span className={`px-2 py-1 rounded-md text-[0.65rem] font-bold uppercase tracking-wider ring-1 ring-inset ${c.color}`}>
      {c.label}
    </span>
  )
}

function Step({ icon: Icon, label, active, current }: any) {
  return (
    <div className="relative flex flex-col items-center z-10 w-1/3">
      <div className={`h-8 w-8 rounded-full flex items-center justify-center transition-colors duration-500 ring-4 ring-white ${
        current ? 'bg-pine-600 text-white shadow-glow-pine scale-110' :
        active ? 'bg-pine-500 text-white' : 'bg-surface-sunk text-ink-3 ring-1 ring-line'
      }`}>
        <Icon size={16} />
      </div>
      <p className={`mt-3 text-xs font-bold transition-colors ${
        current ? 'text-pine-700' : active ? 'text-ink' : 'text-ink-3'
      }`}>
        {label}
      </p>
    </div>
  )
}
