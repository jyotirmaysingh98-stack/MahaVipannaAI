/** Formatting helpers — Indian numbering, rupees, quantities, dates. */

const inr0 = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

const inr2 = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

const num0 = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 })
const num1 = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 1 })

/** ₹1,23,456 — whole rupees, Indian grouping. */
export function inr(value: number): string {
  return inr0.format(Math.round(value))
}

/** ₹2,570.50 — two decimals, for per-quintal precision when needed. */
export function inrPrecise(value: number): string {
  return inr2.format(value)
}

/** ₹2,590 /qt */
export function perQt(value: number): string {
  return `${inr0.format(Math.round(value))} /qt`
}

/** Compact rupees for KPIs: ₹6.2L, ₹1.4Cr. Falls back to full for small values. */
export function inrCompact(value: number): string {
  const abs = Math.abs(value)
  if (abs >= 1_00_00_000) return `₹${num1.format(value / 1_00_00_000)}Cr`
  if (abs >= 1_00_000) return `₹${num1.format(value / 1_00_000)}L`
  if (abs >= 1_000) return `₹${num0.format(Math.round(value))}`
  return inr(value)
}

/** 24 qt / 24.5 qt */
export function qt(value: number): string {
  return `${num1.format(value)} qt`
}

export function num(value: number): string {
  return num0.format(value)
}

/** 0.019 -> "1.9%" */
export function pct(fraction: number, digits = 1): string {
  return `${(fraction * 100).toFixed(digits)}%`
}

/** Signed delta for rankings: +₹20 / −₹50. Uses a true minus glyph. */
export function signedInr(value: number): string {
  const rounded = Math.round(value)
  if (rounded === 0) return '₹0'
  const sign = rounded > 0 ? '+' : '−'
  return `${sign}${inr0.format(Math.abs(rounded))}`
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}

export function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
}

/** "3 days", "1 day", "same day" for payment terms. */
export function days(value: number): string {
  if (value <= 0) return 'same day'
  return `${value} ${value === 1 ? 'day' : 'days'}`
}

/** "28 km" */
export function km(value: number): string {
  return `${num0.format(value)} km`
}
