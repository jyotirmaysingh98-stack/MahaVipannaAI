import { useCallback, useEffect, useRef, useState } from 'react'

export interface AsyncState<T> {
  data: T | null
  loading: boolean
  error: string | null
  reload: () => void
}

/**
 * Minimal async-data hook: runs `fn` on mount (and on `deps` change), tracks
 * loading/error, and ignores results from stale calls. No data library needed.
 */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []): AsyncState<T> {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const reqId = useRef(0)

  const run = useCallback(() => {
    const id = ++reqId.current
    setLoading(true)
    setError(null)
    fn()
      .then((result) => {
        if (id === reqId.current) {
          setData(result)
          setLoading(false)
        }
      })
      .catch((err: unknown) => {
        if (id === reqId.current) {
          setError(err instanceof Error ? err.message : 'Something went wrong')
          setLoading(false)
        }
      })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  useEffect(run, [run])

  return { data, loading, error, reload: run }
}
