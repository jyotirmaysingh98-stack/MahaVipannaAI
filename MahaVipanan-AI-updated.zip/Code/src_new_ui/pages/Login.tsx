import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { ArrowRight, ShieldCheck, TrendingUp, Tractor, Building2, Landmark, Truck, Briefcase } from 'lucide-react'
import { useApp, type UserRole } from '@/state/AppContext'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { DemoDataBadge } from '@/components/brand/Provenance'

const ROLES = [
  { id: 'fpo', label: 'FPO Director', icon: Building2, desc: 'Command Center & Analytics' },
  { id: 'farmer', label: 'Farmer', icon: Tractor, desc: 'Manage lots & negotiations' },
  { id: 'buyer', label: 'Buyer', icon: Briefcase, desc: 'Procure & track orders' },
  { id: 'delivery', label: 'Delivery', icon: Truck, desc: 'Logistics tracking' },
  { id: 'government', label: 'Government', icon: Landmark, desc: 'Schemes & Intelligence' },
  { id: 'admin', label: 'Admin', icon: ShieldCheck, desc: 'System moderation' },
] as const

export function LoginPage() {
  const { login } = useApp()
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as { from?: string })?.from ?? '/app'
  const [phone, setPhone] = useState('98220 14567')
  const [selectedRole, setSelectedRole] = useState<UserRole>('fpo')

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    login(selectedRole)
    navigate(from, { replace: true })
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* thesis panel */}
      <div className="relative hidden overflow-hidden bg-ink lg:block">
        <div className="absolute inset-0 bg-field-mesh opacity-40" />
        <div className="absolute -right-24 top-1/3 h-96 w-96 rounded-full bg-pine-500/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo size={44} className="[&_span]:text-paper [&_.text-ink]:text-paper [&_.text-ink-3]:text-paper/60" />
          <div>
            <p className="eyebrow text-pine-300">The MahaVipanan thesis</p>
            <h1 className="mt-3 max-w-md font-display text-4xl font-bold leading-tight text-paper">
              Unified Agricultural Intelligence
            </h1>
            <p className="mt-4 max-w-md text-lg leading-relaxed text-paper/70">
              Connecting farmers, FPOs, buyers, logistics, and government through a single deterministic engine.
            </p>
            <div className="mt-8 space-y-3">
              <Proof icon={TrendingUp} text="Highest net realizable price for farmers & FPOs" />
              <Proof icon={ShieldCheck} text="Verified buyers, fraud detection, transparent tracking" />
            </div>
          </div>
          <p className="text-xs text-paper/40">Prototype for Smart India Hackathon 2026 · SIH26132 · Government of Maharashtra</p>
        </div>
      </div>

      {/* sign-in */}
      <div className="flex items-center justify-center p-6 sm:p-10 overflow-y-auto max-h-screen">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden">
            <Logo size={40} />
          </div>
          <div className="mb-2 flex items-center gap-2">
            <h2 className="font-display text-3xl font-bold text-ink">Sign in</h2>
            <DemoDataBadge label="Demo access" />
          </div>
          <p className="mb-6 text-sm text-ink-2">
            Select your role to access the personalized dashboard.
          </p>

          <form onSubmit={submit} className="space-y-6">
            <div className="grid grid-cols-2 gap-3">
              {ROLES.map(role => (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => setSelectedRole(role.id as UserRole)}
                  className={`flex flex-col text-left items-start p-3 rounded-xl border transition-all ${
                    selectedRole === role.id 
                      ? 'border-pine-500 bg-pine-50 ring-1 ring-pine-500/50 shadow-sm'
                      : 'border-line bg-surface hover:border-pine-300 hover:bg-pine-50/50'
                  }`}
                >
                  <role.icon size={20} className={selectedRole === role.id ? 'text-pine-600 mb-2' : 'text-ink-3 mb-2'} />
                  <span className={`font-semibold text-sm ${selectedRole === role.id ? 'text-pine-900' : 'text-ink'}`}>
                    {role.label}
                  </span>
                  <span className="text-[10px] text-ink-3 mt-1 leading-tight">{role.desc}</span>
                </button>
              ))}
            </div>

            <div className="space-y-4 pt-4 border-t border-line">
              <Field
                label="Registered identifier"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                inputMode="text"
                autoComplete="username"
              />
              <Field
                label="OTP / Password"
                defaultValue="••••"
                readOnly
                hint="Demo mode — no OTP is sent. Any value continues."
              />
              <Button type="submit" size="lg" className="w-full bg-pine-600 hover:bg-pine-700 shadow-glow-pine">
                Launch Dashboard <ArrowRight size={17} className="ml-2" />
              </Button>
            </div>
          </form>

          <p className="mt-8 text-center text-xs text-ink-3">
            This is a demonstration prototype. Real backend authorization enforces role boundaries.
          </p>
        </div>
      </div>
    </div>
  )
}

function Proof({ icon: Icon, text }: { icon: typeof TrendingUp; text: string }) {
  return (
    <div className="flex items-center gap-3 text-paper/80">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/10 text-pine-300 ring-1 ring-inset ring-white/10">
        <Icon size={17} />
      </span>
      <span className="text-sm">{text}</span>
    </div>
  )
}

