// Shared Web Speech API helpers. Reused by Chatbot and the Negotiation
// assistant so we don't build two separate voice frameworks.

export const SPEECH_LOCALE: Record<string, string> = {
  en: 'en-IN',
  hi: 'hi-IN',
  mr: 'mr-IN',
  te: 'te-IN',
}

export function langToSpeechLocale(lang: string): string {
  return SPEECH_LOCALE[lang] || 'en-IN'
}

export function isSpeechRecognitionSupported(): boolean {
  return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window
}

export function isSpeechSynthesisSupported(): boolean {
  return 'speechSynthesis' in window
}

/** Starts one-shot speech recognition. Returns the recognition instance so
 * callers can stop() it if needed; onResult/onError/onEnd are wired for you. */
export function startSpeechRecognition(opts: {
  lang: string
  onResult: (transcript: string) => void
  onError?: (error: string) => void
  onEnd?: () => void
}): any | null {
  if (!isSpeechRecognitionSupported()) {
    opts.onError?.('unsupported')
    return null
  }
  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
  const recognition = new SpeechRecognition()
  recognition.lang = langToSpeechLocale(opts.lang)
  recognition.continuous = false
  recognition.interimResults = false

  recognition.onresult = (event: any) => opts.onResult(event.results[0][0].transcript)
  recognition.onerror = (event: any) => opts.onError?.(event.error)
  recognition.onend = () => opts.onEnd?.()

  recognition.start()
  return recognition
}

export function speak(text: string, lang: string, enabled: boolean = true) {
  if (!enabled || !isSpeechSynthesisSupported()) return
  window.speechSynthesis.cancel()
  const utterance = new SpeechSynthesisUtterance(text)
  utterance.lang = langToSpeechLocale(lang)
  window.speechSynthesis.speak(utterance)
}

export function stopSpeaking() {
  if (isSpeechSynthesisSupported()) window.speechSynthesis.cancel()
}
