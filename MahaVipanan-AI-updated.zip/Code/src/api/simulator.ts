

// Use environment variable or fallback to localhost for development
const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000'

export interface CropOption {
  id: string
  name: string
}

export interface SimulatorRequest {
  crop_id: string
  harvest_date?: string
}

export interface SimulatorResponse {
  crop_name: string
  predicted_price_per_q: number
  remaining_shelf_life_days: number
  total_shelf_life_days: number
  status: 'good' | 'warning' | 'expired'
  message: string
}

async function simulatorFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${BASE_URL}${endpoint}`
  const token = sessionStorage.getItem('mv.auth.token')

  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...(options?.headers || {})
    }
  })

  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error(body.detail || body.error || `Request failed with status ${response.status}`)
  }

  return response.json()
}

export const simulatorApi = {
  getCrops: () => simulatorFetch<CropOption[]>('/simulator/crops'),
  predict: (data: SimulatorRequest) => simulatorFetch<SimulatorResponse>('/simulator/predict', {
    method: 'POST',
    body: JSON.stringify(data)
  })
}
