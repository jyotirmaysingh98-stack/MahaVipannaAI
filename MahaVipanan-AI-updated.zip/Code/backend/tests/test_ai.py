import pytest
from unittest.mock import patch
from app.services.ai_explanation import generate_ai_explanation
from app.schemas.core import OpportunityResponse, BuyerResponse, OpportunityMatchScore, ItemizedBreakdown, DecisionAction
from app.models.core import BuyerType

def _mock_op(nrp: float, name: str) -> OpportunityResponse:
    buyer = BuyerResponse(
        id="mock_id",
        name=name,
        type=BuyerType.trader,
        distance_km=10.0,
        gross_price_per_qt=nrp + 100,
        transport_cost_per_qt=10,
        loading_cost_per_qt=10,
        commission_rate=0.0,
        quality_deduction_per_qt=0,
        misc_cost_per_qt=0,
        min_quantity_qt=10,
        max_quantity_qt=100,
        reliability_score=100,
        data_label="DEMO_DATA"
    )
    breakdown = ItemizedBreakdown(
        gross_price=nrp + 100,
        transport_cost=10,
        loading_cost=10,
        commission_amount=0,
        quality_deduction=0,
        misc_cost=0
    )
    score = OpportunityMatchScore(
        total_score=90.0,
        quantity_fit_score=100.0,
        quality_fit_score=100.0,
        nrp_score=90.0,
        payment_terms_score=100.0,
        reliability_score=100.0,
        label="Excellent"
    )
    return OpportunityResponse(
        buyer=buyer,
        rank=1,
        nrp_per_qt=nrp,
        total_nrp=nrp * 10,
        breakdown=breakdown,
        match_score=score,
        freight_override_applied=False
    )

def test_ai_fallback_no_key(monkeypatch):
    monkeypatch.setattr("app.services.ai_explanation.settings.LLM_API_KEY", "")
    top = _mock_op(2000.0, "Best Buyer")
    alt = _mock_op(1800.0, "Alt Buyer")
    
    explanation = generate_ai_explanation(top, alt)
    assert "Buyer Best Buyer is recommended" in explanation
    assert "2000.0/q" in explanation
    assert "200.0 more" in explanation

@patch("app.services.ai_explanation.Anthropic")
def test_ai_fallback_on_exception(mock_anthropic, monkeypatch):
    monkeypatch.setattr("app.services.ai_explanation.settings.LLM_API_KEY", "dummy_key")
    # Make the API client raise an exception (e.g., Timeout)
    mock_anthropic.side_effect = Exception("API Timeout")
    
    top = _mock_op(2000.0, "Best Buyer")
    
    explanation = generate_ai_explanation(top, None)
    assert "Buyer Best Buyer is recommended" in explanation
    assert "2000.0/q" in explanation
