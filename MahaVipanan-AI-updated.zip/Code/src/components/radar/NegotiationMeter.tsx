import { motion } from 'framer-motion'
import { AlertTriangle, CheckCircle2, Scale, TrendingUp } from 'lucide-react'
import { inr } from '@/lib/format'
import { useState } from 'react'
import { cn } from '@/lib/cn'
import { useI18n } from '@/lib/i18n'

interface NegotiationMeterProps {
  currentOffer: number
  minimumSellingPrice: number
  idealSellingPrice: number
  /** When false, hides the local counter-offer simulator input — used when
   * this meter is embedded read-only inside the real Negotiation drawer. */
  interactive?: boolean
}

export function NegotiationMeter({ currentOffer, minimumSellingPrice, idealSellingPrice, interactive = true }: NegotiationMeterProps) {
  const { t } = useI18n()
  const [offer, setOffer] = useState(currentOffer)

  const diff = offer - minimumSellingPrice
  const isBelowMSP = diff < 0
  const isOptimal = offer >= idealSellingPrice

  const minRange = minimumSellingPrice - (minimumSellingPrice * 0.1)
  const maxRange = idealSellingPrice + (idealSellingPrice * 0.1)
  const range = maxRange - minRange
  const percentage = Math.max(0, Math.min(100, ((offer - minRange) / range) * 100))

  const zoneLabel = isBelowMSP ? t('meter.zone.belowMin') : isOptimal ? t('meter.zone.strong') : t('meter.zone.negotiable')
  const ZoneIcon = isBelowMSP ? AlertTriangle : isOptimal ? CheckCircle2 : TrendingUp
  const zoneClasses = isBelowMSP
    ? 'bg-clay-50 text-clay-700 ring-clay-200'
    : isOptimal
      ? 'bg-pine-50 text-pine-700 ring-pine-200'
      : 'bg-amber-50 text-amber-700 ring-amber-200'

  return (
    <div className="rounded-3xl border border-line bg-surface p-6 shadow-card">
      <div className="flex items-start justify-between mb-4 gap-3 flex-wrap">
        <div>
          <h3 className="font-display text-xl font-bold text-ink flex items-center gap-2">
            <Scale size={20} className="text-pine-600" /> {t('meter.title')}
          </h3>
          <p className="text-sm text-ink-3 mt-1">{t('meter.subtitle')}</p>
        </div>
        <div className="text-right">
          <p className="text-xs font-bold uppercase tracking-wider text-ink-3">{t('meter.currentOffer')}</p>
          <p className={cn("tnum font-display text-2xl font-black mt-1", isBelowMSP ? "text-clay-600" : isOptimal ? "text-pine-600" : "text-amber-600")}>
            {inr(offer)}/qt
          </p>
        </div>
      </div>

      {/* Compact inline status badge — replaces the old full-width warning panel */}
      <div className={cn("inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ring-1 mb-4", zoneClasses)}>
        <ZoneIcon size={13} /> {zoneLabel}
      </div>

      <div className="relative h-12 rounded-full overflow-hidden bg-surface-sunk ring-1 ring-inset ring-line/50 flex">
        <div className="w-1/3 bg-gradient-to-r from-clay-500/20 to-amber-500/20" />
        <div className="w-1/3 bg-gradient-to-r from-amber-500/20 to-pine-500/20" />
        <div className="w-1/3 bg-pine-500/20" />

        <div
          className="absolute top-0 bottom-0 w-0.5 bg-clay-500 z-10"
          style={{ left: `${Math.max(0, Math.min(100, ((minimumSellingPrice - minRange) / range) * 100))}%` }}
        />
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-pine-500 z-10"
          style={{ left: `${Math.max(0, Math.min(100, ((idealSellingPrice - minRange) / range) * 100))}%` }}
        />
        <motion.div
          className="absolute top-0 bottom-0 w-1.5 bg-ink rounded-full shadow-md z-20 -ml-1 transition-all"
          animate={{ left: `${percentage}%` }}
          transition={{ type: "spring", stiffness: 100 }}
        />
      </div>

      <div className="flex justify-between mt-2 text-xs font-bold text-ink-3 uppercase tracking-wider">
        <span className="text-clay-600">{t('meter.msp')}: {inr(minimumSellingPrice)}</span>
        <span className="text-pine-600">{t('meter.isp')}: {inr(idealSellingPrice)}</span>
      </div>

      {interactive && (
        <div className="mt-6 pt-6 border-t border-line/50">
          <label className="text-sm font-bold uppercase tracking-wider text-ink-3 mb-2 block">
            {t('meter.simulator.label')}
          </label>
          <input
            type="number"
            value={offer}
            onChange={(e) => setOffer(Number(e.target.value))}
            className="w-full rounded-2xl border-2 border-line bg-surface px-4 py-3 text-lg font-black text-ink focus:border-pine-400 focus:outline-none focus:ring-4 focus:ring-pine-400/20"
          />
        </div>
      )}
    </div>
  )
}
