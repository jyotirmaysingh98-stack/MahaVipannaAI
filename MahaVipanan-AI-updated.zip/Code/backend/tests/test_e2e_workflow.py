from fastapi.testclient import TestClient

def test_complete_e2e_workflow(client: TestClient):
    """
    Simulates the entire hackathon demo workflow.
    """
    # 1. Retrieve FPO dashboard
    res_fpo = client.get("/api/fpo/dashboard")
    assert res_fpo.status_code == 200
    assert res_fpo.json()["data"]["fpo"]["name"] == "Nashik Onion Producers FPO"

    # 2. Create/select lot
    lot_payload = {
        "crop_name": "Onion",
        "harvest_date": "2026-08-30",
        "members": [{"member_name": "Ramesh", "quantity_kg": 5000, "grade": "A"}]
    }
    res_lot = client.post("/api/lots/", json=lot_payload)
    assert res_lot.status_code == 200
    lot_id = res_lot.json()["data"]["id"]

    # 3. Retrieve opportunities
    res_ops = client.get(f"/api/opportunities/{lot_id}")
    assert res_ops.status_code == 200
    ops_data = res_ops.json()["data"]
    
    # Verify ranking and calculation
    ops = ops_data["opportunities"]
    assert len(ops) == 3
    assert ops[0]["rank"] == 1
    assert ops[0]["freight_override_applied"] is False
    
    # 4. Generate AI explanation / Decision
    rec = ops_data["recommendation"]
    assert rec["action"] in ["sell", "hold", "redirect"]
    assert "data_label" in rec
    assert rec["freight_override_applied"] is False
    
    # 5. Apply freight override
    # Let's say FPO negotiates 0 freight cost for the whole truck
    override_payload = {"freight_cost": 0.0}
    res_recalc = client.post(f"/api/opportunities/{lot_id}/recalculate", json=override_payload)
    assert res_recalc.status_code == 200
    
    recalc_data = res_recalc.json()["data"]
    recalc_ops = recalc_data["opportunities"]
    recalc_rec = recalc_data["recommendation"]
    
    # Verify NRP changed appropriately
    assert recalc_ops[0]["freight_override_applied"] is True
    assert recalc_ops[0]["breakdown"]["transport_cost"] == 0.0
    
    if ops[0]["breakdown"]["transport_cost"] > 0:
        # If transport was greater than 0, new NRP must be strictly greater
        assert recalc_ops[0]["nrp_per_qt"] > ops[0]["nrp_per_qt"]
        
    assert recalc_rec["freight_override_applied"] is True
