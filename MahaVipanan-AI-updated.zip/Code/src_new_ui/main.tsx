import '@fontsource-variable/inter'
import '@fontsource-variable/space-grotesk'
import './index.css'

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider } from 'react-router-dom'
import { router } from './App'
import { AppProvider } from './state/AppContext'
import { I18nProvider } from './lib/i18n'
import { ThemeProvider } from './state/ThemeProvider'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider defaultTheme="light">
      <I18nProvider>
        <AppProvider>
          <RouterProvider router={router} />
        </AppProvider>
      </I18nProvider>
    </ThemeProvider>
  </StrictMode>,
)
