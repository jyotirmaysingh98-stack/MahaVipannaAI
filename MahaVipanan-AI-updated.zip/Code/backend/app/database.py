from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from .config import settings

engine = create_engine(
    settings.DATABASE_URL, 
    connect_args={"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Columns added after the original schema shipped. SQLite supports simple
# ADD COLUMN migrations; this keeps an existing demo .db file working without
# requiring a full migration framework (Alembic) for this hackathon project.
_NEW_COLUMNS = {
    "order": [
        ("crop_name", "VARCHAR"),
        ("farmer_user_id", "VARCHAR"),
        ("buyer_user_id", "VARCHAR"),
        ("fpo_user_id", "VARCHAR"),
        ("initiated_by_user_id", "VARCHAR"),
    ],
    "order_tracking": [
        ("latitude", "FLOAT"),
        ("longitude", "FLOAT"),
        ("is_demo", "BOOLEAN DEFAULT 1"),
    ],
    "negotiation": [
        ("created_by_user_id", "VARCHAR"),
        ("created_by_role", "VARCHAR"),
        ("message", "VARCHAR"),
    ],
    "government_scheme": [
        ("state", "VARCHAR"),
        ("district", "VARCHAR"),
        ("crops", "VARCHAR"),
        ("target_role", "VARCHAR"),
        ("status", "VARCHAR DEFAULT 'published'"),
        ("source_key", "VARCHAR"),
        ("source_type", "VARCHAR DEFAULT 'manual'"),
        ("source_last_checked", "DATETIME"),
        ("created_by_user_id", "VARCHAR"),
        ("updated_at", "DATETIME"),
    ],
}

def run_sqlite_migrations():
    """Idempotently add any missing columns to an existing SQLite demo DB."""
    if not settings.DATABASE_URL.startswith("sqlite"):
        return
    with engine.connect() as conn:
        for table, columns in _NEW_COLUMNS.items():
            try:
                existing = {row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table})")}
            except Exception:
                continue  # table doesn't exist yet; create_all will make it with new columns
            for col_name, col_type in columns:
                if col_name not in existing:
                    try:
                        conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}")
                    except Exception:
                        pass
        conn.commit()
