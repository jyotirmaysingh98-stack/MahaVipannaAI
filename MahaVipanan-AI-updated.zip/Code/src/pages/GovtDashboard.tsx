import { motion } from 'framer-motion'
import { Landmark, PieChart, TrendingUp, Users } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { useI18n } from '@/lib/i18n'

export function GovtDashboard() {
  const { t } = useI18n()
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">{t('govt.title')}</h1>
        <p className="mt-1 text-ink-2">{t('govt.subtitle')}</p>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-4"
      >
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-indigo-600/10 text-indigo-600">
              <TrendingUp size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">{t('govt.avgRealization')}</p>
              <p className="text-xl font-bold text-ink">₹1,950/qt</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-pine-600/10 text-pine-600">
              <Users size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">{t('govt.activeFpos')}</p>
              <p className="text-xl font-bold text-ink">1,402</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-amber-600/10 text-amber-600">
              <PieChart size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">{t('govt.totalTraded')}</p>
              <p className="text-xl font-bold text-ink">450k qt</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-clay-600/10 text-clay-600">
              <Landmark size={20} />
            </div>
            <div>
              <p className="text-xs font-medium text-ink-3">{t('govt.schemeUptake')}</p>
              <p className="text-xl font-bold text-ink">68%</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('govt.districtPerformanceMap')}</h2>
          <div className="rounded-2xl glass p-6 text-center h-64 flex flex-col justify-center items-center">
            <p className="text-ink-2">{t('govt.geospatialIntelligenceMap')}</p>
            <p className="text-xs text-ink-3">{t('govt.awaitingMapbox')}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-semibold text-ink">{t('govt.schemesDirectory')}</h2>
            <button className="px-3 py-1.5 bg-pine-600 text-white rounded-lg text-sm font-semibold hover:bg-pine-700 transition-colors">
              {t('govt.newScheme')}
            </button>
          </div>
          <div className="rounded-2xl border border-line bg-surface p-4">
            <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
              {[
                { name: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)', type: 'Insurance', status: 'Active', target: 'All Farmers' },
                { name: 'PM-KISAN Samman Nidhi', type: 'Direct Benefit', status: 'Active', target: 'Small & Marginal' },
                { name: 'Paramparagat Krishi Vikas Yojana (PKVY)', type: 'Subsidy', status: 'Active', target: 'Organic Farmers' },
                { name: 'Agriculture Infrastructure Fund', type: 'Credit', status: 'Draft', target: 'FPOs' },
              ].map((scheme, i) => (
                <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-surface-sunk rounded-xl border border-line hover:border-pine-300 transition-colors">
                  <div>
                    <h3 className="font-bold text-ink text-sm sm:text-base">{scheme.name}</h3>
                    <div className="flex gap-2 mt-1">
                      <span className="text-xs font-medium text-ink-3 bg-surface px-2 py-0.5 rounded-md border border-line">{scheme.type}</span>
                      <span className="text-xs font-medium text-ink-3 bg-surface px-2 py-0.5 rounded-md border border-line">{t('govt.target')}{scheme.target}</span>
                    </div>
                  </div>
                  <div className="mt-3 sm:mt-0 flex items-center gap-4">
                    <span className={`text-xs font-bold px-2 py-1 rounded-md ${
                      scheme.status === 'Active' ? 'bg-pine-100 text-pine-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {scheme.status === 'Active' ? t('farmer.activeCount') : scheme.status}
                    </span>
                    <button className="text-sm font-semibold text-pine-600 hover:text-pine-700 underline underline-offset-2">
                      {t('govt.manage')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
