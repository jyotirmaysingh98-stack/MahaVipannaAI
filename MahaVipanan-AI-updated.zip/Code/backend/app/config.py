import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./mahavipanan.db")
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    DEMO_MODE: bool = os.getenv("DEMO_MODE", "true").lower() == "true"

    # AI provider abstraction (negotiation assistant + chatbot). All optional —
    # the app must keep working with none of these set (deterministic fallback).
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    OPENROUTER_API_KEY: str = os.getenv("OPENROUTER_API_KEY", "")
    OPENROUTER_MODEL: str = os.getenv("OPENROUTER_MODEL", "meta-llama/llama-3.1-8b-instruct:free")
    SECRET_KEY: str = os.getenv("SECRET_KEY", "supersecretkey_change_me")
    CORS_ORIGINS: str = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173,http://localhost:5174,http://localhost:4173,http://127.0.0.1:4173,https://mahavipanan.vercel.app")
    
    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]

settings = Settings()
