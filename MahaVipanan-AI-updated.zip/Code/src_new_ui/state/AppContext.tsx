import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api } from '@/api/client'
import type { Fpo } from '@/api/types'
import { ToastProvider } from '@/components/ui/Toast'

export type UserRole = 'farmer' | 'fpo' | 'buyer' | 'government' | 'admin' | 'delivery' | null

interface AppState {
  fpo: Fpo | null
  fpoLoading: boolean
  /** True when running on the bundled synthetic dataset (offline demo). */
  demoMode: boolean
  isAuthenticated: boolean
  role: UserRole
  login: (selectedRole: UserRole) => void
  logout: () => void
}

const AppContext = createContext<AppState | null>(null)

export function useApp(): AppState {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}

const AUTH_KEY = 'mv.session.v1'
const ROLE_KEY = 'mv.role.v1'

export function AppProvider({ children }: { children: ReactNode }) {
  const [fpo, setFpo] = useState<Fpo | null>(null)
  const [fpoLoading, setFpoLoading] = useState(true)
  
  const [isAuthenticated, setAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(AUTH_KEY) === '1'
    } catch {
      return false
    }
  })

  const [role, setRole] = useState<UserRole>(() => {
    try {
      return (sessionStorage.getItem(ROLE_KEY) as UserRole) || null
    } catch {
      return null
    }
  })

  useEffect(() => {
    let alive = true
    api
        .getDashboard()
        .then((res: any) => {
          if (alive) {
            setFpo(res.data.fpo)
          }
        })
        .catch(console.error)
        .finally(() => alive && setFpoLoading(false))
  }, [])

  const login = useCallback((selectedRole: UserRole) => {
    setAuthenticated(true)
    setRole(selectedRole)
    try {
      sessionStorage.setItem(AUTH_KEY, '1')
      sessionStorage.setItem(ROLE_KEY, selectedRole || 'fpo')
    } catch {
      /* non-fatal */
    }
  }, [])

  const logout = useCallback(() => {
    setAuthenticated(false)
    setRole(null)
    try {
      sessionStorage.removeItem(AUTH_KEY)
      sessionStorage.removeItem(ROLE_KEY)
    } catch {
      /* non-fatal */
    }
  }, [])

  const value = useMemo<AppState>(
    () => ({ fpo, fpoLoading, demoMode: false, isAuthenticated, role, login, logout }),
    [fpo, fpoLoading, isAuthenticated, role, login, logout],
  )

  return (
    <AppContext.Provider value={value}>
      <ToastProvider>{children}</ToastProvider>
    </AppContext.Provider>
  )
}
