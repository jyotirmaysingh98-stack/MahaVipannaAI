import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ShoppingCart, Activity, MapPin, Truck, MessageSquare } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Button } from '@/components/ui/Button'
import { FeedbackModal } from '@/components/ui/FeedbackModal'
import { useI18n } from '@/lib/i18n'

export function BuyerDashboard() {
  const { t } = useI18n()
  const [feedbackOpen, setFeedbackOpen] = useState(false)
  const [feedbackOrderId, setFeedbackOrderId] = useState<string | undefined>()

  const orders = [
    { id: 'ORD-109', crop: 'Onion (Grade A)', qty: '120 qt', status: 'negotiation', fpo: 'Nashik FPO' },
    { id: 'ORD-108', crop: 'Wheat (FAQ)', qty: '500 qt', status: 'in_transit', fpo: 'Pune Farmers' },
    { id: 'ORD-107', crop: 'Tomato', qty: '80 qt', status: 'delivered', fpo: 'Satara Co-op' },
  ]

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">{t('buyer.title')}</h1>
          <p className="mt-1 text-ink-2">{t('buyer.subtitle')}</p>
        </div>
        <Link to="/app/delivery">
          <Button variant="outline" className="gap-2">
            <Truck size={16} /> {t('farmer.trackDeliveries')}
          </Button>
        </Link>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-600/10 text-pine-600">
              <ShoppingCart size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('buyer.activeProcurement')}</p>
              <p className="text-2xl font-bold text-ink">1,250 qt</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-indigo-600/10 text-indigo-600">
              <Activity size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('buyer.liveOrders')}</p>
              <p className="text-2xl font-bold text-ink">3 {t('buyer.inTransitCount')}</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-600/10 text-amber-600">
              <MapPin size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('buyer.sourcingRegions')}</p>
              <p className="text-2xl font-bold text-ink">4 {t('buyer.districtsCount')}</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('buyer.liveOrders')}</h2>
          <div className="rounded-2xl border border-line bg-surface overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-sunk text-ink-3">
                  <tr>
                    <th className="px-4 py-3 font-medium">{t('buyer.orderID')}</th>
                    <th className="px-4 py-3 font-medium">{t('buyer.details')}</th>
                    <th className="px-4 py-3 font-medium">{t('buyer.status')}</th>
                    <th className="px-4 py-3 font-medium">{t('buyer.action')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {orders.map((order) => (
                    <tr key={order.id} className="transition-colors hover:bg-surface-sunk/50">
                      <td className="px-4 py-3 text-ink-3">{order.id}</td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-ink">{order.crop}</div>
                        <div className="text-ink-3 text-xs">{order.qty} • {order.fpo}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium uppercase ${
                          order.status === 'delivered' ? 'bg-pine-600/10 text-pine-600' : 
                          order.status === 'in_transit' ? 'bg-indigo-600/10 text-indigo-600' :
                          'bg-amber-600/10 text-amber-600'
                        }`}>
                          {t(`status.${order.status}`) || order.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {order.status === 'delivered' ? (
                          <button
                            onClick={() => { setFeedbackOrderId(order.id); setFeedbackOpen(true) }}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-pine-600 hover:underline"
                          >
                            <MessageSquare size={12} /> {t('buyer.giveFeedback')}
                          </button>
                        ) : (
                          <span className="text-xs text-ink-3">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('buyer.marketLots')}</h2>
          <div className="rounded-2xl glass p-6 text-center">
            <p className="text-ink-2 text-sm">{t('buyer.marketListingsPlaceholder')}</p>
          </div>
        </div>
      </div>

      <FeedbackModal
        isOpen={feedbackOpen}
        onClose={() => setFeedbackOpen(false)}
        orderId={feedbackOrderId}
        fromUserId="demo-buyer-1"
      />
    </div>
  )
}
