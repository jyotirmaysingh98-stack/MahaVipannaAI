from typing import List
from ..schemas.core import OpportunityResponse, DecisionAction, RecommendationResponse
from .ai_explanation import generate_ai_explanation

MINIMUM_VIABLE_NRP = 1000.0  # A threshold for demonstration purposes

def build_sell_justification(top: OpportunityResponse, alt: OpportunityResponse = None) -> List[str]:
    reasons = [
        f"Offers the highest Net Realizable Price (NRP) of Rs. {top.nrp_per_qt}/q.",
        f"Buyer match score is {top.match_score.label} ({top.match_score.total_score}/100)."
    ]
    if alt:
        delta = round(top.nrp_per_qt - alt.nrp_per_qt, 2)
        reasons.append(f"Provides Rs. {delta}/q more net return than the next best option ({alt.buyer.name}).")
    if top.freight_override_applied:
        reasons.append("Accounts for your negotiated freight override rate.")
        
    return reasons

def generate_decision(ranked_ops: List[OpportunityResponse], hold_feasible: bool = False) -> RecommendationResponse:
    if not ranked_ops:
        return RecommendationResponse(
            action=DecisionAction.hold,
            justification_points=["No matching buyer opportunities available for this lot."],
            ai_explanation="There are no buyers currently matching the lot parameters.",
            freight_override_applied=False
        )

    top = ranked_ops[0]
    alt = ranked_ops[1] if len(ranked_ops) > 1 else None
    
    if top.nrp_per_qt < MINIMUM_VIABLE_NRP:
        if hold_feasible:
            action = DecisionAction.hold
            justification = [f"Best NRP Rs. {top.nrp_per_qt}/q is below acceptable threshold."]
        else:
            action = DecisionAction.redirect
            justification = ["Seek alternative markets. Current best NRP is below target."]
        
        # Simple AI fallback for HOLD/REDIRECT
        ai_exp = "Market conditions are not favorable. Consider holding or seeking alternative markets."
        
        return RecommendationResponse(
            action=action,
            recommended_buyer_name=None,
            recommended_buyer_id=None,
            justification_points=justification,
            ai_explanation=ai_exp,
            freight_override_applied=top.freight_override_applied
        )

    action = DecisionAction.sell
    justification = build_sell_justification(top, alt)
    
    # Generate AI explanation based on structured data
    ai_exp = generate_ai_explanation(top, alt)
    
    return RecommendationResponse(
        action=action,
        recommended_buyer_name=top.buyer.name,
        recommended_buyer_id=top.buyer.id,
        justification_points=justification,
        ai_explanation=ai_exp,
        freight_override_applied=top.freight_override_applied
    )
