/**
 * MahaVipanan AI Frontend Types
 * Strictly aligned with the FastAPI backend contract (FRONTEND_API_CONTRACT.md).
 */

export interface ApiEnvelope<T> {
  success: boolean
  data?: T
  error?: string
  details?: any
  data_label: string
}

// FPO Types
export interface Fpo {
  id: string
  name: string
  district: string
  created_at: string
}

export interface FpoDashboard {
  fpo: Fpo
  active_lots: number
  total_inventory_q: number
}

// Lot Types
export interface LotMember {
  member_name: string
  quantity_kg: number
  grade?: string
}

export interface LotCreatePayload {
  crop_name: string
  harvest_date?: string
  members: LotMember[]
}

export interface LotResponse {
  id: string
  crop_name: string
  total_quantity_q: number
  status: string
  harvest_date?: string
  members: any[]
}

// Opportunity Types
export interface Buyer {
  id: string
  name: string
  type: string
  distance_km: number
  gross_price_per_qt: number
  transport_cost_per_qt: number
  loading_cost_per_qt: number
  commission_rate: number
  quality_deduction_per_qt: number
  misc_cost_per_qt: number
  min_quantity_qt: number
  max_quantity_qt: number
  location?: string
  payment_terms_days?: number
  reliability_score: number
  demand_signal?: string
  data_label: string
}

export interface ItemizedBreakdown {
  gross_price: number
  transport_cost: number
  loading_cost: number
  commission_amount: number
  quality_deduction: number
  misc_cost: number
}

export interface OpportunityMatchScore {
  total_score: number
  quantity_fit_score: number
  quality_fit_score: number
  nrp_score: number
  payment_terms_score: number
  reliability_score: number
  label: string
}

export interface OpportunityResponse {
  buyer: Buyer
  rank: number
  nrp_per_qt: number
  total_nrp: number
  breakdown: ItemizedBreakdown
  match_score: OpportunityMatchScore
  freight_override_applied: boolean
}

export interface DecisionRecommendation {
  action: 'sell' | 'hold' | 'redirect'
  recommended_buyer_name: string | null
  recommended_buyer_id: string | null
  justification_points: string[]
  ai_explanation: string | null
  freight_override_applied: boolean
  data_label: string
}

export interface OpportunitiesData {
  opportunities: OpportunityResponse[]
  recommendation: DecisionRecommendation
}

export interface RecalculatePayload {
  freight_cost: number
}

// --- Negotiation system ---
export type NegotiationRole = 'farmer' | 'fpo' | 'buyer'
export type NegotiationStatus = 'pending' | 'accepted' | 'rejected'
export type OrderStatus = 'offer' | 'negotiation' | 'accepted' | 'transport' | 'pickup' | 'in_transit' | 'delivered' | 'payment'

export interface Counterparty {
  id: string
  name: string | null
  role: NegotiationRole
}

export interface NegotiationRound {
  id: string
  offered_price_per_q: number
  status: NegotiationStatus
  created_by_user_id: string | null
  created_by_role: NegotiationRole | null
  message: string | null
  created_at: string
}

export interface NegotiationOrder {
  id: string
  crop_name: string | null
  quantity_q: number
  status: OrderStatus
  agreed_price_per_q: number | null
  farmer_user_id: string | null
  buyer_user_id: string | null
  fpo_user_id: string | null
  initiated_by_user_id: string | null
  created_at: string
  updated_at: string
  rounds: NegotiationRound[]
}

export interface NegotiationAiSuggestion {
  zone: 'below_min' | 'negotiable' | 'strong' | 'unknown'
  suggested_counter_low: number
  suggested_counter_high: number
  ai_text: string
  ai_source: 'gemini' | 'openrouter' | 'fallback'
}

// --- Government schemes ---
export interface GovernmentScheme {
  id: string
  title: string
  description: string
  benefits: string
  eligibility: string
  deadline: string | null
  official_url: string | null
  state: string | null
  district: string | null
  crops: string | null
  target_role: string | null
  status: string
  source_type: string
  source_last_checked: string | null
  created_at: string
  relevance_score: number
  relevance_label: string
}

export interface SchemeSource {
  key: string
  name: string
  url: string
  last_checked: string | null
}

// --- Orders / tracking ---
export interface OrderSummary {
  id: string
  crop_name: string | null
  status: OrderStatus
  agreed_price_per_q: number | null
  quantity_q: number
  created_at: string
  updated_at: string
}

export interface OrderTrackingPoint {
  id: string
  status: OrderStatus
  location: string | null
  latitude: number | null
  longitude: number | null
  timestamp: string
  notes: string | null
  is_demo: boolean
}
