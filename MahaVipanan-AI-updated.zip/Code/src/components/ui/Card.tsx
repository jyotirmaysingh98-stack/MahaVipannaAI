import { forwardRef, type HTMLAttributes } from 'react'
import { cn } from '@/lib/cn'

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** Adds an interactive lift + spotlight on hover. */
  interactive?: boolean
  /** Frosted-glass surface for elevated panels. */
  glass?: boolean
}

export const Card = forwardRef<HTMLDivElement, CardProps>(function Card(
  { interactive, glass, className, children, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cn(
        glass ? 'glass rounded-2xl' : 'card',
        interactive &&
          'spotlight relative overflow-hidden transition-all duration-300 ease-spring hover:-translate-y-1 hover:shadow-card-lg',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  )
})

export function CardHeader({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('flex items-start justify-between gap-4 p-5 pb-0', className)} {...props}>
      {children}
    </div>
  )
}

export function CardBody({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('p-5', className)} {...props}>
      {children}
    </div>
  )
}
