import { Cpu, FlaskConical, Sparkles } from 'lucide-react'
import { cn } from '@/lib/cn'
import { Badge } from '@/components/ui/Badge'
import { Tooltip } from '@/components/ui/Tooltip'

/**
 * Honest provenance for synthetic data (FR-014/030/031). Never let demo figures
 * read as live market prices.
 */
export function DemoDataBadge({ className, label = 'Demo data' }: { className?: string; label?: string }) {
  return (
    <Tooltip content="Synthetic sample data for demonstration — not live market prices.">
      <Badge tone="amber" icon={<FlaskConical size={12} />} className={cn('cursor-help', className)}>
        {label}
      </Badge>
    </Tooltip>
  )
}

/**
 * The architectural distinction the product is built on: the deterministic
 * engine CALCULATES the recommendation; the AI only EXPLAINS it.
 */
export function SystemCalculatedTag({ className }: { className?: string }) {
  return (
    <Tooltip content="Produced by the deterministic decision engine — fixed formulas, no model, fully reproducible.">
      <span
        className={cn(
          'inline-flex cursor-help items-center gap-1.5 rounded-full bg-teal-50 px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-teal-700 ring-1 ring-inset ring-teal-100',
          className,
        )}
      >
        <Cpu size={12} strokeWidth={2.25} />
        Calculated by system
      </span>
    </Tooltip>
  )
}

export function AiExplainedTag({ className }: { className?: string }) {
  return (
    <Tooltip content="Natural-language explanation of the numbers above. The AI never chooses the recommendation.">
      <span
        className={cn(
          'inline-flex cursor-help items-center gap-1.5 rounded-full bg-indigo-100 px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-indigo-600 ring-1 ring-inset ring-indigo-100',
          className,
        )}
      >
        <Sparkles size={12} strokeWidth={2.25} />
        Explained by AI
      </span>
    </Tooltip>
  )
}
