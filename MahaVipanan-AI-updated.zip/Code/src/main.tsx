import '@fontsource-variable/inter'
import '@fontsource-variable/space-grotesk'
import './index.css'

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider } from 'react-router-dom'
import { router } from './App'
import { AppProvider } from './state/AppContext'
import { ThemeProvider } from './state/ThemeProvider'
import { I18nProvider } from './lib/i18n'
import { NegotiationUIProvider } from './state/NegotiationContext'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider>
      <AppProvider>
        <I18nProvider>
          <NegotiationUIProvider>
            <RouterProvider router={router} />
          </NegotiationUIProvider>
        </I18nProvider>
      </AppProvider>
    </ThemeProvider>
  </StrictMode>,
)
