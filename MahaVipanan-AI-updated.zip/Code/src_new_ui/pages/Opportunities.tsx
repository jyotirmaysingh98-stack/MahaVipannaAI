import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Check,
  ChevronDown,
  Clock,
  Crown,
  MapPin,
  Sparkles,
  Truck,
  Wheat,
} from 'lucide-react'
import { useRadar } from '@/state/useRadar'
import { days, inr, inrCompact, km, perQt, qt } from '@/lib/format'
import type { OpportunityResponse } from '@/api/types'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/States'
import { Button } from '@/components/ui/Button'
import { DemoDataBadge } from '@/components/brand/Provenance'
import { NrpBreakdownModal } from '@/components/radar/NrpBreakdownModal'
import { RecordDecisionModal } from '@/components/radar/RecordDecisionModal'
import { NegotiationMeter } from '@/components/radar/NegotiationMeter'
import { AnimatedNumber } from '@/components/ui/AnimatedNumber'
import { fadeUp, staggerContainer, rankLayout } from '@/lib/motion'
import { cn } from '@/lib/cn'

export function OpportunitiesPage() {
  const { lotId } = useParams<{ lotId: string }>()
  const navigate = useNavigate()
  const { lot, radar, loading, error, overrides, setOverride, clearOverride, reload } = useRadar(lotId)

  const [breakdown, setBreakdown] = useState<OpportunityResponse | null>(null)
  const [recordOpen, setRecordOpen] = useState(false)
  const [recorded, setRecorded] = useState<any | null>(null)
  const [freightOpen, setFreightOpen] = useState(false)

  if (loading) return <RadarSkeleton />
  if (error) return <ErrorState onRetry={reload} />
  if (!lot || !radar)
    return (
      <ErrorState
        title="Lot not found"
        description="This lot has no buyers to evaluate yet."
        onRetry={reload}
      />
    )

  const { recommendation, opportunities } = radar
  const best = opportunities.find(o => o.rank === 1)
  
  const isSell = recommendation.action === 'sell'
  const isHold = recommendation.action === 'hold'

  const actionLabel = isSell ? 'Sell Now' : isHold ? 'Hold Inventory' : 'Redirect to another market'

  return (
    <div className="space-y-8 pb-24 perspective-1000">

      {/* ── Back + lot info ── */}
      <div className="flex flex-wrap items-center justify-between gap-3 relative z-10">
        <button
          onClick={() => navigate('/app')}
          className="flex items-center gap-2 text-sm font-semibold text-ink-2 transition-colors hover:text-pine-600 bg-white/50 px-4 py-2 rounded-xl border border-line backdrop-blur-md shadow-sm"
        >
          <ArrowLeft size={16} /> Dashboard
        </button>
        <DemoDataBadge />
      </div>

      {/* ── Lot header ── */}
      <motion.div 
        initial={{ opacity: 0, y: -20, rotateX: 5 }}
        animate={{ opacity: 1, y: 0, rotateX: 0 }}
        className="flex items-center gap-4 rounded-3xl border border-line bg-surface p-5 shadow-card glass preserve-3d"
      >
        <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-pine-50 text-pine-600 ring-1 ring-inset ring-pine-100 translate-z-10 shadow-inner">
          <Wheat size={28} />
        </div>
        <div className="min-w-0 translate-z-20">
          <p className="text-xs font-bold uppercase tracking-wider text-pine-600">Current lot</p>
          <h1 className="font-display text-2xl font-bold text-ink">{lot.crop_name}</h1>
          <p className="tnum text-sm font-medium text-ink-2">
            {qt(lot.total_quantity_q)} · Grade A · Harvested {lot.harvest_date ?? 'recently'}
          </p>
        </div>
      </motion.div>

      {/* ── Step 1: What should we do? ── */}
      <section className="preserve-3d">
        <StepLabel number={1} label="Action Intelligence" />
        <motion.div
          layout
          className={`mt-4 rounded-3xl border bg-gradient-to-br p-8 shadow-2xl glass-dark preserve-3d relative overflow-hidden`}
        >
          <div className="absolute inset-0 bg-black/40 -z-10" />
          
          <div className="translate-z-20">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 backdrop-blur-md ring-1 ring-white/20 mb-4">
              <Check size={16} className={isSell ? "text-pine-400" : isHold ? "text-amber-400" : "text-indigo-400"} />
              <span className={`text-sm font-bold ${isSell ? "text-pine-300" : isHold ? "text-amber-300" : "text-indigo-300"}`}>{actionLabel}</span>
            </div>

            {recommendation.recommended_buyer_name && (
              <h2 className="text-2xl font-display font-semibold text-white mb-6">
                Highest realistic return found with <span className="text-pine-300">{recommendation.recommended_buyer_name}</span>
              </h2>
            )}

            {/* The big NRP number */}
            {best && (
              <div className="flex flex-wrap items-end gap-10 mb-8 p-6 rounded-2xl bg-white/5 ring-1 ring-white/10 shadow-inner">
                <div>
                  <p className="text-sm font-medium text-white/70">Per quintal (Net)</p>
                  <AnimatedNumber
                    value={best.nrp_per_qt}
                    format={perQt}
                    className="mt-1 font-display text-5xl font-bold tracking-tight text-white drop-shadow-md"
                  />
                  <p className="mt-2 text-xs font-medium text-white/50">
                    Gross Quote {perQt(best.breakdown.gross_price)} − Deductions
                  </p>
                </div>
                <div className="pb-2 border-l border-white/10 pl-10">
                  <p className="text-sm font-medium text-white/70">Total Pool Collection</p>
                  <p className="tnum font-display text-4xl font-bold text-pine-300 drop-shadow-md">
                    {inrCompact(best.total_nrp)}
                  </p>
                </div>
              </div>
            )}

            {/* Why bullets */}
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-semibold text-white/80 mb-3 uppercase tracking-wider">Deterministic Logic</p>
                <ul className="space-y-2">
                  {recommendation.justification_points.map((p, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-white/90">
                      <div className="mt-1 shrink-0 h-4 w-4 rounded-full bg-pine-500/20 flex items-center justify-center ring-1 ring-pine-500/50">
                        <Check size={10} className="text-pine-300" strokeWidth={3} />
                      </div>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* AI explanation */}
              <div className="rounded-2xl border border-indigo-400/30 bg-indigo-900/40 p-5 shadow-inner">
                <p className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-300">
                  <Sparkles size={14} /> AI Context
                </p>
                <p className="text-sm leading-relaxed text-indigo-100/90">{recommendation.ai_explanation}</p>
              </div>
            </div>

            {/* Record decision */}
            <div className="mt-8 flex items-center justify-between gap-4 border-t border-white/10 pt-6">
              {recorded ? (
                <p className="flex items-center gap-2 text-sm font-semibold text-pine-400">
                  <Check size={16} strokeWidth={2.5} /> Recorded: {recorded.buyerName}
                </p>
              ) : (
                <p className="text-sm text-white/60">Log this decision to the FPO ledger.</p>
              )}
              <Button
                size="lg"
                className={recorded ? "bg-white/10 text-white" : "bg-pine-500 hover:bg-pine-600 shadow-glow-pine text-white font-semibold"}
                onClick={() => setRecordOpen(true)}
              >
                {recorded ? 'Update Ledger' : 'Record Decision'}
              </Button>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ── Step 2: Compare all buyers ── */}
      <section className="preserve-3d mt-12">
        <div className="flex justify-between items-end mb-6">
          <StepLabel number={2} label={`Evaluate all ${opportunities.length} buyers`} />
          <p className="text-sm font-medium text-ink-3">Sorted by Net Realizable Price</p>
        </div>
        
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="show"
          className="space-y-4"
        >
          {opportunities.map((o, i) => (
            <BuyerCard
              key={o.buyer.id}
              opportunity={o}
              index={i}
              isRecommended={o.buyer.id === recommendation.recommended_buyer_id}
              onOpenBreakdown={() => setBreakdown(o)}
            />
          ))}
        </motion.div>
      </section>

      {/* ── Step 4: Live Negotiation ── */}
      <section className="mt-12">
        <StepLabel number={4} label="Negotiation Room" />
        <div className="mt-6">
          <NegotiationMeter 
            currentOffer={best ? best.breakdown.gross_price : 2000} 
            minimumSellingPrice={1850} 
            idealSellingPrice={2100} 
          />
        </div>
      </section>

      {/* ── Step 3: Freight correction ── */}
      <section className="mt-12">
        <StepLabel number={3} label="Logistics Override" />
        <p className="mt-2 mb-4 text-sm text-ink-2 max-w-2xl">
          The engine estimates freight dynamically. If you have a confirmed transporter quote, input it below to recalculate the NRP waterfall and rankings live.
        </p>
        <div className="rounded-3xl border border-teal-200 bg-surface shadow-card overflow-hidden transition-all hover:shadow-card-lg">
          <button
            onClick={() => setFreightOpen(v => !v)}
            className="flex w-full items-center justify-between gap-4 p-5 text-left bg-teal-50/50 hover:bg-teal-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-teal-100 text-teal-700 ring-1 ring-teal-200">
                <Truck size={22} />
              </span>
              <div>
                <p className="font-display font-semibold text-lg text-ink">Live Freight Simulator</p>
                <p className="text-sm font-medium text-teal-700">
                  {Object.keys(overrides).length > 0
                    ? `${Object.keys(overrides).length} active override(s) — rankings are artificially adjusted.`
                    : 'Override system freight estimates.'}
                </p>
              </div>
            </div>
            <div className={`p-2 rounded-full bg-white shadow-sm ring-1 ring-line transition-transform duration-300 ${freightOpen ? 'rotate-180' : ''}`}>
              <ChevronDown size={20} className="text-ink-3" />
            </div>
          </button>

          <AnimatePresence initial={false}>
            {freightOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="overflow-hidden bg-white"
              >
                <FreightPanel
                  opportunities={opportunities}
                  lotQtyQt={lot.total_quantity_q}
                  overrides={overrides}
                  setOverride={setOverride}
                  clearOverride={clearOverride}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <NrpBreakdownModal opportunity={breakdown} open={!!breakdown} onClose={() => setBreakdown(null)} />
      <RecordDecisionModal
        open={recordOpen}
        onClose={() => setRecordOpen(false)}
        lot={lot}
        opportunities={opportunities}
        recommendation={recommendation}
        onRecorded={setRecorded}
      />
    </div>
  )
}

function StepLabel({ number, label }: { number: number; label: string }) {
  return (
    <div className="flex items-center gap-4">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-pine-100 text-lg font-bold text-pine-700 ring-1 ring-pine-300 shadow-sm">
        {number}
      </span>
      <h2 className="font-display text-2xl font-bold text-ink">{label}</h2>
    </div>
  )
}

function BuyerCard({ opportunity: o, index, isRecommended, onOpenBreakdown }: any) {
  const [open, setOpen] = useState(false)
  const leader = o.rank === 1

  const d = o.breakdown
  const deductions = [
    { key: 'transport', label: 'Transport / Freight', amount: d.transport_cost, overridden: o.freight_override_applied },
    { key: 'loading', label: 'Loading & handling', amount: d.loading_cost },
    { key: 'commission', label: 'Commission / Mandi fee', amount: d.commission_amount },
    { key: 'quality', label: 'Quality deduction', amount: d.quality_deduction },
    { key: 'misc', label: 'Other costs', amount: d.misc_cost },
  ].filter(x => x.amount > 0)

  return (
    <motion.div
      layout
      variants={fadeUp}
      custom={index}
      transition={{ ...rankLayout, delay: index * 0.05 }}
      className={cn(
        'relative overflow-hidden rounded-3xl border bg-surface transition-all preserve-3d',
        leader
          ? 'border-pine-300 shadow-card-lg ring-2 ring-pine-500/20 z-10'
          : 'border-line shadow-card hover:shadow-card-lg opacity-90 hover:opacity-100',
      )}
    >
      {/* leader accent */}
      <span
        aria-hidden
        className={cn(
          'absolute inset-y-0 left-0 w-2',
          leader ? 'bg-gradient-to-b from-pine-400 to-pine-600' : 'bg-transparent',
        )}
      />

      {/* Recommended banner */}
      {isRecommended && (
        <div className="bg-gradient-to-r from-pine-500 to-pine-600 px-5 py-2 text-xs font-bold uppercase tracking-wider text-white shadow-sm flex items-center gap-2">
          <Check size={14} strokeWidth={3} /> System Recommended
        </div>
      )}

      <div className="p-5 pl-8 sm:p-6 sm:pl-8">
        <div className="flex flex-col sm:flex-row items-start justify-between gap-6">
          <div className="flex items-start gap-4">
            <span
              className={cn(
                'grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-lg font-black shadow-sm',
                leader ? 'bg-pine-100 text-pine-700 ring-1 ring-pine-300' : 'bg-surface-sunk text-ink-3 ring-1 ring-line',
              )}
            >
              {leader ? <Crown size={22} strokeWidth={2.5} /> : o.rank}
            </span>
            <div>
              <h3 className="font-display text-2xl font-bold leading-tight text-ink">{o.buyer.name}</h3>
              <div className="mt-2 flex flex-wrap items-center gap-3 text-sm font-medium text-ink-3">
                <span className="inline-flex items-center gap-1.5 bg-surface-sunk px-2 py-1 rounded-md">
                  <MapPin size={14} /> {o.buyer.location} ({km(o.buyer.distance_km)})
                </span>
                <span className="inline-flex items-center gap-1.5 bg-surface-sunk px-2 py-1 rounded-md">
                  <Clock size={14} /> Pays in {days(o.buyer.payment_terms_days ?? 0)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex gap-4 w-full sm:w-auto">
            <div className="flex-1 sm:flex-none rounded-2xl bg-surface-sunk p-4 text-center border border-line">
              <p className="text-xs font-bold uppercase tracking-wider text-ink-3">Headline Quote</p>
              <p className="tnum mt-1 font-display text-xl font-bold text-ink-3 line-through decoration-clay-400 decoration-2">
                {perQt(o.breakdown.gross_price)}
              </p>
            </div>
            <div className={cn('flex-1 sm:flex-none rounded-2xl p-4 text-center border shadow-inner', leader ? 'bg-pine-50 border-pine-200 shadow-pine-100' : 'bg-white border-line')}>
              <p className={cn('text-xs font-bold uppercase tracking-wider', leader ? 'text-pine-700' : 'text-ink-2')}>
                Actual NRP
              </p>
              <AnimatedNumber
                value={o.nrp_per_qt}
                format={perQt}
                className={cn(
                  'mt-1 font-display text-2xl font-black tracking-tight',
                  leader ? 'text-pine-700' : 'text-ink',
                )}
              />
            </div>
          </div>
        </div>

        {/* Total pool realization */}
        <div className="mt-6 flex items-center justify-between border-t border-line/60 pt-4">
          <p className="tnum text-sm text-ink-2">
            Pool Collection: <strong className="text-ink font-bold text-base">{inrCompact(o.total_nrp)}</strong>
          </p>
          
          <button
            onClick={() => setOpen(v => !v)}
            className="flex items-center gap-2 rounded-xl bg-surface-sunk px-4 py-2 text-sm font-semibold text-ink-2 transition-colors hover:bg-line/50 hover:text-ink"
          >
            <span>NRP Waterfall Details</span>
            <ChevronDown size={16} className={cn('transition-transform duration-300', open && 'rotate-180')} />
          </button>
        </div>

        <AnimatePresence initial={false}>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden"
            >
              <div className="mt-4 rounded-2xl border border-line bg-white p-5 shadow-inner">
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-line/40">
                    <tr>
                      <td className="py-2.5 font-semibold text-ink-2">Gross Quote</td>
                      <td className="tnum py-2.5 text-right font-bold text-ink">
                        {perQt(o.breakdown.gross_price)}
                      </td>
                    </tr>
                    {deductions.map(ded => (
                      <tr key={ded.key}>
                        <td className="py-2.5 text-ink-3 font-medium">
                          − {ded.label}
                          {ded.overridden && (
                            <span className="ml-3 rounded bg-teal-50 px-2 py-0.5 text-xs font-bold uppercase tracking-wider text-teal-700 ring-1 ring-teal-200">
                              Overridden
                            </span>
                          )}
                        </td>
                        <td className="tnum py-2.5 text-right font-semibold text-clay-600">
                          − {inr(ded.amount)}/qt
                        </td>
                      </tr>
                    ))}
                    <tr className="border-t-2 border-line">
                      <td className="pt-3 font-bold text-pine-700 uppercase tracking-wider text-xs">Net Realizable Price (NRP)</td>
                      <td className="tnum pt-3 text-right text-lg font-black text-pine-700">{perQt(o.nrp_per_qt)}</td>
                    </tr>
                  </tbody>
                </table>
                {onOpenBreakdown && (
                  <Button
                    variant="ghost"
                    onClick={onOpenBreakdown}
                    className="mt-4 w-full text-sm font-bold text-pine-600 bg-pine-50 hover:bg-pine-100"
                  >
                    Open Visual Waterfall Chart <ArrowRight size={16} className="ml-2" />
                  </Button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}

function FreightPanel({ opportunities, lotQtyQt, overrides, setOverride, clearOverride }: any) {
  const [selectedId, setSelectedId] = useState(opportunities[0]?.buyer.id ?? '')
  const selected = opportunities.find((o: any) => o.buyer.id === selectedId) ?? opportunities[0]
  const estimate = selected?.buyer.transport_cost_per_qt ?? 0
  const active = selected ? overrides[selected.buyer.id] : undefined
  const [draft, setDraft] = useState(active ?? estimate)
  const max = Math.max(300, Math.ceil((estimate * 2.5) / 50) * 50)

  const commit = (v: number) => {
    const clamped = Math.max(0, Math.round(v))
    setDraft(clamped)
    if (selected) setOverride(selected.buyer.id, clamped)
  }

  if (!selected) return null

  return (
    <div className="p-6 space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="mb-2 block text-sm font-bold uppercase tracking-wider text-ink-3">
            Target Buyer
          </label>
          <select
            value={selectedId}
            onChange={e => {
              setSelectedId(e.target.value)
              const o = opportunities.find((o:any) => o.buyer.id === e.target.value)
              setDraft(overrides[e.target.value] ?? o?.buyer.transport_cost_per_qt ?? 0)
            }}
            className="w-full rounded-2xl border-2 border-line bg-surface px-4 py-3 text-base font-semibold text-ink focus:border-teal-400 focus:outline-none focus:ring-4 focus:ring-teal-400/20"
          >
            {opportunities.map((o:any) => (
              <option key={o.buyer.id} value={o.buyer.id}>
                {o.buyer.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold uppercase tracking-wider text-ink-3">
            System Estimate
          </label>
          <div className="flex h-[52px] items-center justify-between rounded-2xl bg-surface-sunk px-4 ring-1 ring-inset ring-line text-sm border-l-4 border-l-line">
            <span className="text-ink-2 font-medium">Default Freight</span>
            <span className="tnum font-bold text-lg text-ink">{perQt(estimate)}</span>
          </div>
        </div>
      </div>

      <div className="pt-2">
        <div className="flex items-center justify-between mb-2">
          <label className="text-sm font-bold uppercase tracking-wider text-teal-700">
            Override Transport Cost (₹/qt)
          </label>
          <span className="text-xs font-semibold text-ink-3 bg-surface-sunk px-2 py-1 rounded-md">Total Truck: {inrCompact(draft * lotQtyQt)}</span>
        </div>
        
        <div className="flex items-center gap-4">
          <input
            type="range"
            min={0}
            max={max}
            step={5}
            value={Math.min(draft, max)}
            onChange={e => commit(Number(e.target.value))}
            className="h-3 w-full cursor-pointer appearance-none rounded-full bg-teal-100 accent-teal-500 shadow-inner"
          />
          <input
            type="number"
            min={0}
            value={draft}
            onChange={e => commit(Number(e.target.value))}
            className="w-32 rounded-2xl border-2 border-teal-200 bg-white px-4 py-3 text-xl font-black text-teal-700 shadow-sm focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/20 text-center"
          />
        </div>
      </div>

      {active !== undefined && Math.round(active) !== Math.round(estimate) && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-center justify-between rounded-2xl bg-teal-500 text-white p-4 shadow-md"
        >
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xl">
              <Check size={20} />
            </div>
            <p className="text-sm font-medium">
              <strong className="font-bold">{selected.buyer.name}</strong> adjusted to{' '}
              <strong className="tnum font-bold text-lg">{perQt(active)}</strong> freight. Rankings are live.
            </p>
          </div>
          <button
            onClick={() => { clearOverride(selected.buyer.id); setDraft(estimate) }}
            className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm font-bold transition-colors hover:bg-white/20"
          >
            <RotateCcw size={16} /> Reset
          </button>
        </motion.div>
      )}
    </div>
  )
}

function RadarSkeleton() {
  return (
    <div className="space-y-8">
      <Skeleton className="h-10 w-64 rounded-xl" />
      <Skeleton className="h-28 w-full rounded-3xl" />
      <Skeleton className="h-64 w-full rounded-3xl" />
      <div className="space-y-4">
        {[0, 1, 2].map(i => (
          <Skeleton key={i} className="h-44 w-full rounded-3xl" />
        ))}
      </div>
    </div>
  )
}
