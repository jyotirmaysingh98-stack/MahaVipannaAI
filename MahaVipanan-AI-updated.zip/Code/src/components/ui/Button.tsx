import { forwardRef, type ButtonHTMLAttributes } from 'react'
import { cn } from '@/lib/cn'

type Variant = 'primary' | 'secondary' | 'ghost' | 'subtle' | 'outline'
type Size = 'sm' | 'md' | 'lg'

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
}

const base =
  'relative inline-flex items-center justify-center gap-2 font-medium rounded-xl select-none ' +
  'transition-all duration-200 ease-spring active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 ' +
  'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2'

const variants: Record<Variant, string> = {
  primary:
    'bg-pine-500 text-white shadow-[0_6px_20px_-8px_rgba(21,115,79,0.6)] hover:bg-pine-600 hover:shadow-[0_10px_28px_-8px_rgba(21,115,79,0.7)] hover:-translate-y-0.5 outline-pine-600',
  secondary:
    'bg-surface text-ink border border-line-strong shadow-card hover:border-pine-300 hover:text-pine-600 hover:-translate-y-0.5 outline-pine-500',
  ghost: 'text-ink-2 hover:bg-black/[0.04] hover:text-ink outline-pine-500',
  subtle: 'bg-pine-50 text-pine-700 hover:bg-pine-100 outline-pine-500',
  outline: 'bg-transparent text-ink border border-line-strong hover:border-pine-300 hover:text-pine-600 outline-pine-500',
}

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-sm',
  md: 'h-11 px-5 text-sm',
  lg: 'h-12 px-6 text-base',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', className, children, ...props },
  ref,
) {
  return (
    <button ref={ref} className={cn(base, variants[variant], sizes[size], className)} {...props}>
      {children}
    </button>
  )
})
