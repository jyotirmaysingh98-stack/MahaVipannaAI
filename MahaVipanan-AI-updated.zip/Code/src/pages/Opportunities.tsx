import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Clock,
  Crown,
  MapPin,
  RotateCcw,
  Sparkles,
  Truck,
  Wheat,
} from 'lucide-react'
import { useRadar } from '@/state/useRadar'
import { days, inr, inrCompact, km, perQt, qt } from '@/lib/format'
import type { OpportunityResponse } from '@/api/types'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/States'
import { Button } from '@/components/ui/Button'

import { NrpBreakdownModal } from '@/components/radar/NrpBreakdownModal'
import { RecordDecisionModal } from '@/components/radar/RecordDecisionModal'
import { AnimatedNumber } from '@/components/ui/AnimatedNumber'
import { fadeUp, staggerContainer, rankLayout } from '@/lib/motion'
import { cn } from '@/lib/cn'
import { useI18n } from '@/lib/i18n'

/**
 * Market Opportunity Radar — completely redesigned for clarity.
 * Plain language, stepped layout, no jargon.
 */
export function OpportunitiesPage() {
  const { t } = useI18n()
  const { lotId } = useParams<{ lotId: string }>()
  const navigate = useNavigate()
  const { lot, radar, loading, error, overrides, setOverride, clearOverride, reload } = useRadar(lotId)

  const [breakdown, setBreakdown] = useState<OpportunityResponse | null>(null)
  const [recordOpen, setRecordOpen] = useState(false)
  const [recorded, setRecorded] = useState<any | null>(null)
  const [freightOpen, setFreightOpen] = useState(false)

  if (loading) return <RadarSkeleton />
  if (error) return <ErrorState onRetry={reload} />
  if (!lot || !radar)
    return (
      <ErrorState
        title={t('opps.lotNotFound')}
        description={t('opps.noBuyers')}
        onRetry={reload}
      />
    )

  const { recommendation, opportunities } = radar
  const best = opportunities.find(o => o.rank === 1)
  const actionLabel =
    recommendation.action === 'sell'
      ? `✅ ${t('opps.sellNow')}`
      : recommendation.action === 'hold'
      ? `⏳ ${t('opps.hold')}`
      : `🔀 ${t('opps.redirect')}`

  const actionColor =
    recommendation.action === 'sell'
      ? 'from-pine-500/10 to-pine-500/5 border-pine-300'
      : recommendation.action === 'hold'
      ? 'from-amber-500/10 to-amber-500/5 border-amber-300'
      : 'from-indigo-500/10 to-indigo-500/5 border-indigo-300'

  const actionText =
    recommendation.action === 'sell'
      ? 'text-pine-700'
      : recommendation.action === 'hold'
      ? 'text-amber-700'
      : 'text-indigo-700'

  return (
    <div className="space-y-6">

      {/* ── Back + lot info ── */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={() => navigate('/app')}
          className="flex items-center gap-2 text-sm text-ink-2 transition-colors hover:text-ink"
        >
          <ArrowLeft size={16} /> {t('opps.backToDashboard')}
        </button>
        
      </div>

      {/* ── Lot header ── */}
      <div className="flex items-center gap-3 rounded-2xl border border-line bg-surface p-4 shadow-card">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-pine-50 text-pine-600 ring-1 ring-inset ring-pine-100">
          <Wheat size={22} />
        </span>
        <div className="min-w-0">
          <p className="text-xs font-medium text-ink-3">{t('opps.currentLot')}</p>
          <h1 className="font-display text-xl font-bold text-ink">{lot.crop_name}</h1>
          <p className="tnum text-sm text-ink-2">
            {qt(lot.total_quantity_q)} · Grade A · {t('farmer.harvested')} {lot.harvest_date ?? 'recently'}
          </p>
        </div>
      </div>

      {/* ── Step 1: What should we do? ── */}
      <section>
        <StepLabel number={1} label={t('opps.whatShouldFpoDo')} />
        <motion.div
          layout
          className={`mt-3 rounded-2xl border bg-gradient-to-br ${actionColor} p-5 shadow-card`}
        >
          <p className={`text-xl font-bold ${actionText}`}>{actionLabel}</p>
          {recommendation.recommended_buyer_name && (
            <p className="mt-1 text-sm text-ink-2">
              {t('opps.sellTo')} <span className="font-semibold text-ink">{recommendation.recommended_buyer_name}</span>
            </p>
          )}

          {/* The big NRP number */}
          {best && (
            <div className="mt-4 flex flex-wrap items-end gap-6">
              <div>
                <p className="text-xs font-medium text-ink-3">{t('opps.moneyKeepsPerQt')}</p>
                <AnimatedNumber
                  value={best.nrp_per_qt}
                  format={perQt}
                  className={`mt-0.5 font-display text-5xl font-bold tracking-tight ${actionText}`}
                />
                <p className="mt-0.5 text-xs text-ink-3">
                  (Quoted {perQt(best.breakdown.gross_price)} − all costs = this)
                </p>
              </div>
              <div className="pb-1">
                <p className="text-xs font-medium text-ink-3">{t('opps.totalPoolCollects')}</p>
                <p className={`tnum font-display text-3xl font-bold ${actionText}`}>
                  {inrCompact(best.total_nrp)}
                </p>
              </div>
            </div>
          )}

          {/* Why bullets — plain language */}
          <ul className="mt-4 space-y-1.5">
            {recommendation.justification_points.map((p, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-ink-2">
                <Check size={15} className="mt-0.5 shrink-0 text-pine-500" strokeWidth={2.5} />
                <span>{p}</span>
              </li>
            ))}
          </ul>

          {/* AI explanation */}
          <div className="mt-4 rounded-xl border border-indigo-100 bg-indigo-50/60 p-3.5">
            <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold text-indigo-600">
              <Sparkles size={12} /> {t('opps.aiExplanation')}
            </p>
            <p className="text-sm leading-relaxed text-ink-2">{recommendation.ai_explanation}</p>
          </div>

          {/* Record decision */}
          <div className="mt-4 flex items-center justify-between gap-3 border-t border-line/50 pt-4">
            {recorded ? (
              <p className="flex items-center gap-2 text-sm text-pine-700">
                <Check size={15} strokeWidth={2.5} /> {t('opps.recorded')} {recorded.buyerName}
              </p>
            ) : (
              <p className="text-sm text-ink-3">{t('opps.recordDecisionDesc')}</p>
            )}
            <Button
              size="sm"
              variant={recorded ? 'secondary' : 'primary'}
              onClick={() => setRecordOpen(true)}
            >
              {recorded ? t('opps.update') : t('opps.recordDecision')}
            </Button>
          </div>
        </motion.div>
      </section>

      {/* ── Step 2: Compare all buyers ── */}
      <section>
        <StepLabel number={2} label={t('opps.compareAllBuyers')} />
        <p className="mt-1 mb-3 text-sm text-ink-3">
          {t('opps.sortedByMoney')}
        </p>
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="show"
          className="space-y-3"
        >
          {opportunities.map((o, i) => (
            <BuyerCard
              key={o.buyer.id}
              opportunity={o}
              index={i}
              isRecommended={o.buyer.id === recommendation.recommended_buyer_id}
              onOpenBreakdown={() => setBreakdown(o)}
            />
          ))}
        </motion.div>
      </section>

      {/* ── Step 3: Freight correction ── */}
      <section>
        <StepLabel number={3} label={t('opps.knowRealTransport')} />
        <p className="mt-1 mb-3 text-sm text-ink-3">
          {t('opps.systemEstimates')}
        </p>
        <div className="rounded-2xl border border-teal-100 bg-teal-50/50 shadow-card">
          <button
            onClick={() => setFreightOpen(v => !v)}
            className="flex w-full items-center justify-between gap-3 p-4 text-left"
          >
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-teal-500 text-white">
                <Truck size={17} />
              </span>
              <div>
                <p className="font-semibold text-ink">{t('opps.correctFreight')}</p>
                <p className="text-xs text-ink-3">
                  {Object.keys(overrides).length > 0
                    ? `${Object.keys(overrides).length} ${t('opps.overridesActive')}`
                    : t('opps.enterRealCost')}
                </p>
              </div>
            </div>
            <ChevronDown
              size={18}
              className={cn('text-ink-3 transition-transform duration-300', freightOpen && 'rotate-180')}
            />
          </button>

          <AnimatePresence initial={false}>
            {freightOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="overflow-hidden"
              >
                <FreightPanel
                  opportunities={opportunities}
                  lotQtyQt={lot.total_quantity_q}
                  overrides={overrides}
                  setOverride={setOverride}
                  clearOverride={clearOverride}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <NrpBreakdownModal opportunity={breakdown} open={!!breakdown} onClose={() => setBreakdown(null)} />
      <RecordDecisionModal
        open={recordOpen}
        onClose={() => setRecordOpen(false)}
        lot={lot}
        opportunities={opportunities}
        recommendation={recommendation}
        onRecorded={setRecorded}
      />
    </div>
  )
}

/* ── Step label ── */
function StepLabel({ number, label }: { number: number; label: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-pine-500 text-sm font-bold text-white">
        {number}
      </span>
      <h2 className="font-display text-lg font-semibold text-ink">{label}</h2>
    </div>
  )
}

/* ── Buyer card — clean, human-readable ── */

function BuyerCard({
  opportunity: o,
  index,
  isRecommended,
  onOpenBreakdown,
}: {
  opportunity: OpportunityResponse
  index: number
  isRecommended?: boolean
  onOpenBreakdown?: () => void
}) {
  const [open, setOpen] = useState(false)
  const leader = o.rank === 1
  const { t } = useI18n()

  const d = o.breakdown
  const deductions = [
    { key: 'transport', label: 'Transport / Freight', amount: d.transport_cost, overridden: o.freight_override_applied },
    { key: 'loading', label: 'Loading & handling', amount: d.loading_cost },
    { key: 'commission', label: 'Commission / Mandi fee', amount: d.commission_amount },
    { key: 'quality', label: 'Quality deduction', amount: d.quality_deduction },
    { key: 'misc', label: 'Other costs', amount: d.misc_cost },
  ].filter(x => x.amount > 0)

  return (
    <motion.div
      layout
      variants={fadeUp}
      custom={index}
      transition={{ ...rankLayout, delay: index * 0.04 }}
      className={cn(
        'relative overflow-hidden rounded-2xl border bg-surface transition-shadow',
        leader
          ? 'border-pine-300 shadow-card-lg ring-1 ring-pine-500/15'
          : 'border-line shadow-card hover:shadow-card-lg',
      )}
    >
      {/* leader accent */}
      <span
        aria-hidden
        className={cn(
          'absolute inset-y-0 left-0 w-1',
          leader ? 'bg-gradient-to-b from-pine-400 to-pine-600' : 'bg-transparent',
        )}
      />

      {/* Recommended banner */}
      {isRecommended && (
        <div className="border-b border-pine-100 bg-pine-500 px-4 py-1.5 text-xs font-semibold text-white">
          {t('opps.recommendedBanner')}
        </div>
      )}

      <div className="p-4 pl-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span
              className={cn(
                'grid h-9 w-9 shrink-0 place-items-center rounded-xl text-sm font-bold',
                leader ? 'bg-pine-500 text-white' : 'bg-surface-sunk text-ink-2 ring-1 ring-inset ring-line',
              )}
            >
              {leader ? <Crown size={15} strokeWidth={2.5} /> : o.rank}
            </span>
            <div>
              <h3 className="font-display text-lg font-semibold leading-tight text-ink">{o.buyer.name}</h3>
              <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-ink-3">
                <span className="inline-flex items-center gap-1">
                  <MapPin size={11} /> {o.buyer.location} · {km(o.buyer.distance_km)}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock size={11} /> {t('opps.paymentIn')} {days(o.buyer.payment_terms_days ?? 0)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* The two key numbers, side by side */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-xl bg-surface-sunk/60 p-3 text-center">
            <p className="text-[0.68rem] font-medium text-ink-3">{t('opps.theyQuote')}</p>
            <p className="tnum mt-0.5 font-display text-xl font-bold text-ink-2 line-through decoration-clay-400 decoration-2">
              {perQt(o.breakdown.gross_price)}
            </p>
          </div>
          <div className={cn('rounded-xl p-3 text-center', leader ? 'bg-pine-50 ring-1 ring-pine-200' : 'bg-surface-sunk/60')}>
            <p className={cn('text-[0.68rem] font-medium', leader ? 'text-pine-600' : 'text-ink-3')}>
              {t('opps.youKeep')}
            </p>
            <AnimatedNumber
              value={o.nrp_per_qt}
              format={perQt}
              className={cn(
                'mt-0.5 font-display text-xl font-bold tracking-tight',
                leader ? 'text-pine-700' : 'text-ink',
              )}
            />
          </div>
        </div>

        {/* Total pool realization */}
        <p className="tnum mt-2 text-center text-xs text-ink-3">
          {t('opps.totalPoolCollects')} <span className="font-semibold text-ink">{inrCompact(o.total_nrp)}</span>
        </p>

        {/* Expand deductions */}
        <button
          onClick={() => setOpen(v => !v)}
          className="mt-3 flex w-full items-center justify-between rounded-lg px-2 py-2 text-sm text-ink-3 transition-colors hover:bg-black/[0.04] hover:text-ink"
        >
          <span>{t('opps.howCalculated')}</span>
          <ChevronDown size={15} className={cn('transition-transform duration-300', open && 'rotate-180')} />
        </button>

        <AnimatePresence initial={false}>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden"
            >
              <div className="mt-1 rounded-xl border border-line bg-surface-sunk/50 p-3">
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-line/50">
                    <tr>
                      <td className="py-1.5 text-ink-2">{t('market.grossPrice')}</td>
                      <td className="tnum py-1.5 text-right font-medium text-amber-700">
                        {perQt(o.breakdown.gross_price)}
                      </td>
                    </tr>
                    {deductions.map(ded => (
                      <tr key={ded.key}>
                        <td className="py-1.5 text-ink-3">
                          − {ded.label}
                          {ded.overridden && (
                            <span className="ml-2 rounded bg-teal-50 px-1.5 py-0.5 text-[0.62rem] font-semibold text-teal-700 ring-1 ring-teal-200">
                              {t('market.yourCost')}
                            </span>
                          )}
                        </td>
                        <td className="tnum py-1.5 text-right font-medium text-clay-600">
                          − {inr(ded.amount)}/qt
                        </td>
                      </tr>
                    ))}
                    <tr className="border-t border-line font-semibold">
                      <td className="pt-2.5 text-pine-700">= {t('market.moneyYouKeep')}</td>
                      <td className="tnum pt-2.5 text-right text-pine-700">{perQt(o.nrp_per_qt)}</td>
                    </tr>
                  </tbody>
                </table>
                {onOpenBreakdown && (
                  <button
                    onClick={onOpenBreakdown}
                    className="mt-2 text-xs font-medium text-pine-600 hover:underline"
                  >
                    View full chart →
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}

/* ── Inline freight panel ── */
function FreightPanel({
  opportunities,
  lotQtyQt,
  overrides,
  setOverride,
  clearOverride,
}: {
  opportunities: OpportunityResponse[]
  lotQtyQt: number
  overrides: Record<string, number>
  setOverride: (id: string, val: number) => void
  clearOverride: (id: string) => void
}) {
  const [selectedId, setSelectedId] = useState(opportunities[0]?.buyer.id ?? '')
  const selected = opportunities.find(o => o.buyer.id === selectedId) ?? opportunities[0]
  const estimate = selected?.buyer.transport_cost_per_qt ?? 0
  const active = selected ? overrides[selected.buyer.id] : undefined
  const [draft, setDraft] = useState(active ?? estimate)
  const max = Math.max(300, Math.ceil((estimate * 2.5) / 50) * 50)

  const commit = (v: number) => {
    const clamped = Math.max(0, Math.round(v))
    setDraft(clamped)
    if (selected) setOverride(selected.buyer.id, clamped)
  }

  if (!selected) return null

  return (
    <div className="border-t border-teal-100 p-4 space-y-4">
      {/* Buyer selector */}
      <div>
        <label className="mb-1 block text-sm font-medium text-ink-2">
          Which buyer's transport cost do you want to correct?
        </label>
        <select
          value={selectedId}
          onChange={e => {
            setSelectedId(e.target.value)
            const o = opportunities.find(o => o.buyer.id === e.target.value)
            setDraft(overrides[e.target.value] ?? o?.buyer.transport_cost_per_qt ?? 0)
          }}
          className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink shadow-sm focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30"
        >
          {opportunities.map(o => (
            <option key={o.buyer.id} value={o.buyer.id}>
              {o.buyer.name}
            </option>
          ))}
        </select>
      </div>

      {/* Current estimate info */}
      <div className="flex items-center justify-between rounded-xl bg-surface p-3 ring-1 ring-inset ring-line text-sm">
        <span className="text-ink-2">System estimate for <span className="font-medium text-ink">{selected.buyer.name}</span></span>
        <span className="tnum font-semibold text-ink">{perQt(estimate)}</span>
      </div>

      {/* Slider + input */}
      <div>
        <label className="mb-2 block text-sm font-medium text-ink-2">
          Your real transport cost per quintal
        </label>
        <div className="flex items-center gap-3">
          <input
            type="number"
            min={0}
            value={draft}
            onChange={e => commit(Number(e.target.value))}
            className="w-28 rounded-xl border border-line bg-surface px-3 py-2 text-sm font-semibold text-ink shadow-sm focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30"
          />
          <span className="text-sm text-ink-3">₹/quintal</span>
          <span className="text-xs text-ink-3">or {inrCompact(draft * lotQtyQt)}/full truck</span>
        </div>
        <input
          type="range"
          min={0}
          max={max}
          step={5}
          value={Math.min(draft, max)}
          onChange={e => commit(Number(e.target.value))}
          className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full bg-teal-100 accent-teal-500"
        />
        <div className="mt-1 flex justify-between text-[0.68rem] text-ink-3">
          <span>₹0</span>
          <span className="tnum">Estimate: {perQt(estimate)}</span>
          <span>₹{max}</span>
        </div>
      </div>

      {/* Active override indicator */}
      {active !== undefined && Math.round(active) !== Math.round(estimate) && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between rounded-xl bg-teal-50 p-3 ring-1 ring-inset ring-teal-200"
        >
          <p className="text-sm text-teal-800">
            <span className="font-semibold">{selected.buyer.name}</span> is now using{' '}
            <span className="tnum font-semibold">{perQt(active)}</span> freight — rankings updated.
          </p>
          <button
            onClick={() => { clearOverride(selected.buyer.id); setDraft(estimate) }}
            className="ml-3 inline-flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-teal-700 transition-colors hover:bg-teal-100"
          >
            <RotateCcw size={12} /> Reset
          </button>
        </motion.div>
      )}
    </div>
  )
}

/* ── Loading skeleton ── */
function RadarSkeleton() {
  return (
    <div className="space-y-5">
      <Skeleton className="h-6 w-48" />
      <Skeleton className="h-20 w-full rounded-2xl" />
      <Skeleton className="h-48 w-full rounded-2xl" />
      <div className="space-y-3">
        {[0, 1, 2].map(i => (
          <Skeleton key={i} className="h-36 w-full rounded-2xl" />
        ))}
      </div>
    </div>
  )
}
