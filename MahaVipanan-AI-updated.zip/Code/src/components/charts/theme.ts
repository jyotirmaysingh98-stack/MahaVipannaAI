/** Shared chart tokens — validated categorical palette (see dataviz validation). */
export const CHART = {
  gross: '#E0A32E', // amber — quoted price (large fill only)
  net: '#15734F', // pine — net realizable (the number that matters)
  netSoft: '#4B9066',
  clay: '#A8442C', // deductions / erosion
  indigo: '#3A4FB0', // 3rd categorical series
  grid: '#ECECE4',
  axis: '#767E70',
  ink: '#1A2419',
} as const
