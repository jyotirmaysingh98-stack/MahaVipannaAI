import { useState } from 'react'
import { useLocation, useNavigate, Link } from 'react-router-dom'
import { ArrowRight, ShieldCheck, TrendingUp } from 'lucide-react'
import { useApp } from '@/state/AppContext'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { ThemeToggle } from '@/components/ui/ThemeToggle'
import { api } from '@/api/client'
import { useI18n } from '@/lib/i18n'

export function LoginPage() {
  const { login } = useApp()
  const { t } = useI18n()
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as { from?: string })?.from ?? '/app'
  const [phoneOrEmail, setPhoneOrEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)
    
    const isEmail = phoneOrEmail.includes('@')
    const payload = isEmail 
      ? { email: phoneOrEmail, password } 
      : { phone: phoneOrEmail, password }
    
    try {
      const res: any = await api.login(payload)
      if (res.success) {
        login(res.user.role, res.token, res.user.id, res.user.name)
        const targetPath = from === '/app' ? `/app/${res.user.role}` : from
        navigate(targetPath, { replace: true })
      } else {
        setError(res.error || t('auth.error.failed'))
      }
    } catch (err: any) {
      setError(err.message || t('auth.error.network'))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* thesis panel */}
      <div className="relative hidden overflow-hidden bg-[#1A2419] lg:block">
        <div className="absolute inset-0 bg-field-mesh opacity-40" />
        <div className="absolute -right-24 top-1/3 h-96 w-96 rounded-full bg-pine-500/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo size={44} className="[&_span]:text-white [&_.text-ink]:text-white [&_.text-ink-3]:text-white/60" />
          <div>
            <p className="eyebrow text-pine-300">{t('auth.thesis.eyebrow')}</p>
            <h1 className="mt-3 max-w-md font-display text-4xl font-bold leading-tight text-white">
              {t('auth.thesis.title')}
            </h1>
            <p className="mt-4 max-w-md text-lg leading-relaxed text-white/70">
              {t('auth.thesis.subtitle')}
            </p>
            <div className="mt-8 space-y-3">
              <Proof icon={TrendingUp} text={t('auth.thesis.proof1')} />
              <Proof icon={ShieldCheck} text={t('auth.thesis.proof2')} />
            </div>
          </div>
          <p className="text-xs text-white/40">{t('auth.thesis.footer')}</p>
        </div>
      </div>

      {/* sign-in */}
      <div className="relative flex justify-center p-6 sm:p-10">
        <div className="absolute top-6 right-6">
          <ThemeToggle />
        </div>
        <div className="w-full max-w-md pt-12 pb-12 lg:pt-24">
          <div className="mb-8 lg:hidden">
            <Logo size={40} />
          </div>
          <div className="mb-2 flex items-center gap-2">
            <h2 className="font-display text-3xl font-bold text-ink">{t('auth.title')}</h2>
          </div>
          <p className="mb-6 text-sm text-ink-2">
            {t('auth.subtitle')}
          </p>

          <form onSubmit={submit} className="space-y-6">
            <div className="space-y-4">
              <Field
                label={t('auth.emailOrPhone')}
                value={phoneOrEmail}
                onChange={(e) => setPhoneOrEmail(e.target.value)}
                inputMode="text"
                autoComplete="username"
                required
              />
              <Field
                label={t('auth.password')}
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
              
              {error && (
                <div className="p-3 text-sm rounded-lg bg-red-600/10 text-red-600 border border-red-600/20">
                  {error}
                </div>
              )}

              <Button 
                type="submit" 
                size="lg" 
                disabled={isLoading}
                className="w-full bg-pine-600 hover:bg-pine-700 shadow-glow-pine"
              >
                {isLoading ? t('auth.authenticating') : t('common.signIn')} <ArrowRight size={17} className="ml-2" />
              </Button>
            </div>
          </form>

          <p className="mt-8 text-center text-sm text-ink-3">
            {t('auth.newToMaha')}{' '}
            <Link to="/signup" className="text-pine-600 font-medium hover:underline">
              {t('auth.createAccount')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}

function Proof({ icon: Icon, text }: { icon: typeof TrendingUp; text: string }) {
  return (
    <div className="flex items-center gap-3 text-white/80">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/10 text-pine-300 ring-1 ring-inset ring-white/10">
        <Icon size={17} />
      </span>
      <span className="text-sm">{text}</span>
    </div>
  )
}
