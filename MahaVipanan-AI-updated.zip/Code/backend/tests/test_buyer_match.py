from app.services.buyer_match import (
    score_quantity_fit, score_payment_terms, normalize_nrp,
    score_quality_fit, calculate_match_score
)
from app.models.core import Buyer, ProduceLot

def test_score_quantity_fit():
    assert score_quantity_fit(50.0, 10.0, 100.0) == 1.0
    assert score_quantity_fit(5.0, 10.0, 100.0) == 0.0
    assert score_quantity_fit(150.0, 10.0, 100.0) == 0.7

def test_score_payment_terms():
    assert score_payment_terms(0) == 1.0
    assert score_payment_terms(20) == 0.5
    assert score_payment_terms(40) == 0.0
    assert score_payment_terms(60) == 0.0 # maxes out at 0

def test_normalize_nrp():
    nrps = [1500.0, 1800.0, 2000.0]
    assert normalize_nrp(2000.0, nrps) == 1.0
    assert normalize_nrp(1000.0, nrps) == 0.5
    assert normalize_nrp(0.0, nrps) == 0.0
    assert normalize_nrp(-100.0, nrps) == 0.0
    assert normalize_nrp(1500.0, []) == 0.0

def test_score_quality_fit():
    assert score_quality_fit("A", "A") == 1.0
    assert score_quality_fit("A", "B") == 1.0
    assert score_quality_fit("B", "A") == 0.5
    assert score_quality_fit(None, "A") == 1.0
    assert score_quality_fit("C", "A") == 0.5

def test_calculate_match_score():
    buyer = Buyer(
        min_quantity_qt=10.0,
        max_quantity_qt=100.0,
        payment_days=0,
        reliability_score=100.0
    )
    lot = ProduceLot(total_quantity_q=50.0)
    nrps = [2000.0, 1800.0]
    
    match_score = calculate_match_score(buyer, lot, nrps, 2000.0)
    
    # Check max score possible
    # q_fit: 1.0 * 0.25 = 0.25
    # qual_fit: 1.0 * 0.25 = 0.25
    # nrp: 1.0 * 0.30 = 0.30
    # pay: 1.0 * 0.10 = 0.10
    # rel: 1.0 * 0.10 = 0.10
    # Total = 1.0 -> 100%
    assert match_score.total_score == 100.0
    assert match_score.label == "Excellent"

def test_calculate_match_score_poor():
    buyer = Buyer(
        min_quantity_qt=10.0,
        max_quantity_qt=100.0,
        payment_days=40,
        reliability_score=0.0
    )
    lot = ProduceLot(total_quantity_q=5.0) # q_fit = 0.0
    nrps = [2000.0, 1800.0]
    
    match_score = calculate_match_score(buyer, lot, nrps, 500.0)
    
    # q_fit = 0.0
    # qual_fit = 1.0 (default) * 0.25
    # nrp = 500/2000 = 0.25 * 0.30 = 0.075
    # pay = 0.0
    # rel = 0.0
    # Total = 0.25 + 0.075 = 0.325 = 32.5%
    
    assert match_score.total_score == 32.5
    assert match_score.label == "Poor"
