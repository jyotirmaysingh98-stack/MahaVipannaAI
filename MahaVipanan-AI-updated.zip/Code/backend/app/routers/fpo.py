from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models.core import FPO, ProduceLot, LotStatus
from ..schemas.core import FPOResponse

router = APIRouter(prefix="/api/fpo", tags=["FPO"])

@router.get("/dashboard", response_model=dict)
def get_dashboard(db: Session = Depends(get_db)):
    # For MVP, just get the first FPO
    fpo = db.query(FPO).first()
    if not fpo:
        raise HTTPException(status_code=404, detail="No demo FPO found. Please seed the database.")
        
    active_lots_count = db.query(ProduceLot).filter(
        ProduceLot.fpo_id == fpo.id, 
        ProduceLot.status == LotStatus.ready
    ).count()
    
    total_inventory = db.query(ProduceLot.total_quantity_q).filter(
        ProduceLot.fpo_id == fpo.id, 
        ProduceLot.status == LotStatus.ready
    ).all()
    
    total_q = sum([t[0] for t in total_inventory])
    
    return {
        "success": True,
        "data": {
            "fpo": FPOResponse.model_validate(fpo),
            "active_lots": active_lots_count,
            "total_inventory_q": total_q,
        },
        "data_label": "DEMO_DATA"
    }
