import { useEffect, useState } from 'react'

import { inrCompact, perQt } from '@/lib/format'
import type { DecisionRecommendation, LotResponse, OpportunityResponse } from '@/api/types'
import { Button } from '@/components/ui/Button'
import { Modal } from '@/components/ui/Modal'
import { Select } from '@/components/ui/Field'
import { useToast } from '@/components/ui/Toast'

/**
 * Records what the pool actually decided (FR-013) — the recommended channel or a
 * deliberate override. Kept honest: whether the FPO followed the recommendation
 * is stored as-is, so the History screen can show real follow-through, not a
 * flattering number.
 */
export function RecordDecisionModal({
  open,
  onClose,
  lot,
  opportunities,
  recommendation,
  onRecorded,
}: {
  open: boolean
  onClose: () => void
  lot: LotResponse
  opportunities: OpportunityResponse[]
  recommendation: DecisionRecommendation
  onRecorded: (record: any) => void
}) {
  const eligible = opportunities
  const bestId = recommendation.recommended_buyer_id!
  const [buyerId, setBuyerId] = useState(bestId)
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (open) {
      setBuyerId(bestId)
      setNote('')
    }
  }, [open, bestId])

  const selected = eligible.find((o) => o.buyer.id === buyerId) ?? eligible[0]
  const followed = recommendation.action !== 'hold' && selected.buyer.id === bestId

  const submit = async () => {
    setSaving(true)
    const record = {
      id: `dec-${Date.now()}`,
      lotId: lot.id,
      lotCode: lot.id,
      crop: lot.crop_name,
      buyerId: selected.buyer.id,
      buyerName: selected.buyer.name,
      recommendation: recommendation.action,
      followedRecommendation: followed,
      nrpPerQt: Math.round(selected.nrp_per_qt),
      totalRealization: selected.total_nrp,
      quantityQt: lot.total_quantity_q,
      recordedAt: new Date().toISOString(),
      note: note.trim() || undefined,
      dataSource: 'real',
    }
    try {
      // Mocking record decision since backend contract doesn't have this endpoint
      await new Promise(r => setTimeout(r, 400))
      onRecorded(record)
      toast({ tone: 'success', title: 'Decision recorded', description: `${lot.id} → ${selected.buyer.name}` })
      onClose()
    } catch {
      toast({ tone: 'info', title: 'Could not record', description: 'Please try again.' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Record this decision"
      description={`${lot.id} · ${lot.crop_name} · ${lot.total_quantity_q} qt`}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? 'Recording…' : 'Record decision (Demo Only)'}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-3 text-xs text-amber-600">
          <strong>Demo Only:</strong> The recording functionality is a frontend simulation. No data is saved to the backend database.
        </div>
        <Select label="Selling to" value={buyerId} onChange={(e) => setBuyerId(e.target.value)}>
          {eligible.map((o) => (
            <option key={o.buyer.id} value={o.buyer.id}>
              {o.buyer.name} — {perQt(o.nrp_per_qt)} net
            </option>
          ))}
        </Select>

        <div className="rounded-xl bg-surface-sunk/60 p-4 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-ink-2">Net realizable</span>
            <span className="tnum font-semibold text-pine-700">{perQt(selected.nrp_per_qt)}</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-ink-2">Pool realizes</span>
            <span className="tnum font-semibold text-ink">{inrCompact(selected.total_nrp)}</span>
          </div>
          <p className="mt-2 border-t border-line pt-2 text-xs text-ink-3">
            {followed
              ? 'This matches the engine recommendation.'
              : 'Recorded as an override of the recommendation — that is fine, and tracked honestly.'}
          </p>
        </div>

        <div>
          <label htmlFor="decision-note" className="mb-1.5 block text-sm font-medium text-ink-2">
            Note <span className="text-ink-3">(optional)</span>
          </label>
          <textarea
            id="decision-note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={2}
            placeholder="e.g. Buyer confirmed pickup Thursday."
            className="w-full rounded-xl border border-line-strong bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-3 transition-all focus:border-pine-400 focus:outline-none focus:ring-4 focus:ring-pine-500/10"
          />
        </div>
      </div>
    </Modal>
  )
}
