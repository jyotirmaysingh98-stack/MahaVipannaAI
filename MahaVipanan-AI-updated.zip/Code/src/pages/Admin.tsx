import { useState } from 'react'
import { motion } from 'framer-motion'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { ShieldAlert, FileWarning, Search, Ban, CheckCircle2, AlertTriangle, Warehouse } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { formatDate } from '@/lib/format'
import { useI18n } from '@/lib/i18n'

type TabType = 'users' | 'complaints' | 'fraud' | 'warehouse'

export function AdminPage() {
  const { t } = useI18n()
  const [activeTab, setActiveTab] = useState<TabType>('users')

  return (
    <div className="pb-24">
      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={fadeUp} className="mb-6 flex justify-between items-end">
          <div>
            <h1 className="font-display text-4xl font-bold tracking-tight text-ink">{t('admin.title')}</h1>
            <p className="mt-2 text-ink-3">{t('admin.subtitle')}</p>
          </div>
          <div className="flex bg-surface-sunk p-1.5 rounded-xl border border-line overflow-x-auto max-w-full">
            <button onClick={() => setActiveTab('users')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'users' ? 'bg-surface shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>{t('admin.usersAndBans')}</button>
            <button onClick={() => setActiveTab('complaints')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'complaints' ? 'bg-surface shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>{t('admin.complaints')}</button>
            <button onClick={() => setActiveTab('fraud')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'fraud' ? 'bg-surface shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>{t('admin.fraudEngine')}</button>
            <button onClick={() => setActiveTab('warehouse')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === 'warehouse' ? 'bg-surface shadow-sm text-ink' : 'text-ink-3 hover:text-ink'}`}>{t('admin.warehouses')}</button>
          </div>
        </motion.div>

        {activeTab === 'users' && (
          <motion.div variants={fadeUp} className="space-y-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-3" />
                <input type="text" placeholder={t('admin.searchPlaceholder') as any} className="w-full bg-surface border border-line rounded-2xl pl-12 pr-4 py-3 text-sm focus:outline-pine-500" />
              </div>
              <Button variant="secondary" className="bg-surface">{t('admin.filterActive')}</Button>
            </div>
            
            <div className="glass rounded-3xl overflow-hidden border border-line">
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-sunk/80 border-b border-line text-ink-3">
                  <tr>
                    <th className="p-4 font-semibold">{t('admin.userEntity')}</th>
                    <th className="p-4 font-semibold">{t('admin.type')}</th>
                    <th className="p-4 font-semibold">{t('admin.joined')}</th>
                    <th className="p-4 font-semibold">{t('admin.status')}</th>
                    <th className="p-4 font-semibold text-right">{t('admin.actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/50">
                  <tr className="bg-surface/40 hover:bg-surface/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Nashik Exports Ltd</td>
                    <td className="p-4 text-ink-2">Buyer</td>
                    <td className="p-4 text-ink-2">{formatDate('2026-01-15')}</td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-pine-100 text-pine-700 text-xs font-bold ring-1 ring-pine-200">{t('farmer.activeCount')}</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-clay-600 hover:bg-clay-50"><Ban size={14} className="mr-1.5" /> {t('admin.suspend')}</Button>
                    </td>
                  </tr>
                  <tr className="bg-surface/40 hover:bg-surface/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Ramesh Patel (FPO)</td>
                    <td className="p-4 text-ink-2">FPO Admin</td>
                    <td className="p-4 text-ink-2">{formatDate('2026-03-22')}</td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-clay-100 text-clay-700 text-xs font-bold ring-1 ring-clay-200">Suspended</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-pine-600 hover:bg-pine-50"><CheckCircle2 size={14} className="mr-1.5" /> {t('admin.reactivate')}</Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {activeTab === 'complaints' && (
          <motion.div variants={fadeUp} className="grid lg:grid-cols-2 gap-6">
            <div className="glass rounded-3xl p-6 border-line">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display font-semibold text-lg flex items-center gap-2"><FileWarning size={18} className="text-amber-500" /> {t('admin.pendingDisputes')}</h3>
                <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs font-bold">2 {t('admin.actionRequired')}</span>
              </div>
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-surface border border-line shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold text-ink-3">Ticket #9201</span>
                    <span className="text-xs text-ink-3">{formatDate('2026-09-02')}</span>
                  </div>
                  <p className="font-semibold text-ink">Quality mismatch on arrival</p>
                  <p className="text-sm text-ink-2 mt-1">Buyer claims Grade B delivered instead of Grade A.</p>
                  <div className="mt-4 flex gap-2">
                    <Button size="sm" className="bg-amber-600 text-white w-full">{t('admin.investigate')}</Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'fraud' && (
          <motion.div variants={fadeUp} className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="glass rounded-3xl p-6 border-clay-200">
                <ShieldAlert size={32} className="text-clay-500 mb-4" />
                <h3 className="font-display font-bold text-xl text-ink">{t('admin.priceManipulation')}</h3>
                <p className="text-sm text-ink-2 mt-2">Engine detected abnormally low bids from an IP cluster in Pune.</p>
                <Button size="sm" className="mt-4 w-full bg-clay-600 text-white">{t('admin.reviewFlaggedBids')}</Button>
              </div>
              <div className="glass rounded-3xl p-6 border-amber-200">
                <AlertTriangle size={32} className="text-amber-500 mb-4" />
                <h3 className="font-display font-bold text-xl text-ink">{t('admin.ghostProfiles')}</h3>
                <p className="text-sm text-ink-2 mt-2">12 buyer profiles created today without GSTIN verification.</p>
                <Button size="sm" className="mt-4 w-full bg-amber-600 text-white">{t('admin.requireKyc')}</Button>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'warehouse' && (
          <motion.div variants={fadeUp} className="space-y-6">
            <div className="glass rounded-3xl p-6 border-line overflow-hidden">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display font-semibold text-lg flex items-center gap-2"><Warehouse size={18} className="text-pine-600" /> {t('admin.storageCapacityNetwork')}</h3>
                <Button size="sm">{t('admin.addFacility')}</Button>
              </div>
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-sunk/80 border-b border-line text-ink-3">
                  <tr>
                    <th className="p-4 font-semibold">{t('admin.facilityName')}</th>
                    <th className="p-4 font-semibold">{t('admin.location')}</th>
                    <th className="p-4 font-semibold">{t('admin.capacityUtilization')}</th>
                    <th className="p-4 font-semibold">{t('admin.condition')}</th>
                    <th className="p-4 font-semibold text-right">{t('admin.actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/50">
                  <tr className="bg-surface/40 hover:bg-surface/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Central Govt Silo A</td>
                    <td className="p-4 text-ink-2">Nashik, MH</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-full bg-line rounded-full overflow-hidden max-w-[100px]">
                          <div className="h-full bg-amber-500 w-[85%]"></div>
                        </div>
                        <span className="text-xs font-semibold text-ink-2">85%</span>
                      </div>
                    </td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-pine-100 text-pine-700 text-xs font-bold ring-1 ring-pine-200">Optimal</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-ink-2">{t('govt.manage')}</Button>
                    </td>
                  </tr>
                  <tr className="bg-surface/40 hover:bg-surface/80 transition-colors">
                    <td className="p-4 font-medium text-ink">Private Cold Storage 2</td>
                    <td className="p-4 text-ink-2">Pune, MH</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-full bg-line rounded-full overflow-hidden max-w-[100px]">
                          <div className="h-full bg-clay-500 w-[98%]"></div>
                        </div>
                        <span className="text-xs font-semibold text-clay-600">98%</span>
                      </div>
                    </td>
                    <td className="p-4"><span className="px-2.5 py-1 rounded-md bg-clay-100 text-clay-700 text-xs font-bold ring-1 ring-clay-200">Full</span></td>
                    <td className="p-4 text-right">
                      <Button variant="ghost" size="sm" className="text-ink-2">{t('govt.manage')}</Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}
