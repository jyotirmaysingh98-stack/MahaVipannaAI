import { clsx, type ClassValue } from 'clsx'

/** Tailwind-friendly conditional class joining. */
export function cn(...inputs: ClassValue[]): string {
  return clsx(inputs)
}
