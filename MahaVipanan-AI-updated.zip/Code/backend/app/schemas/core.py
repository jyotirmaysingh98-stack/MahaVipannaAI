from pydantic import BaseModel, Field, ConfigDict
from typing import List, Dict, Optional, Any
from datetime import date, datetime
from enum import Enum

class UserRole(str, Enum):
    fpo = "fpo"
    farmer = "farmer"
    buyer = "buyer"
    admin = "admin"
    government = "government"
    delivery = "delivery"

class CropUnit(str, Enum):
    quintal = "quintal"

class LotStatus(str, Enum):
    draft = "draft"
    ready = "ready"
    sold = "sold"
    held = "held"

class DecisionAction(str, Enum):
    sell = "sell"
    hold = "hold"
    redirect = "redirect"

class OrderStatus(str, Enum):
    offer = "offer"
    negotiation = "negotiation"
    accepted = "accepted"
    transport = "transport"
    pickup = "pickup"
    in_transit = "in_transit"
    delivered = "delivered"
    payment = "payment"

class WarehouseStatus(str, Enum):
    stored = "stored"
    ongoing = "ongoing"
    sold = "sold"

class NegotiationStatus(str, Enum):
    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"

# FPO & Member Schemas
class FPOResponse(BaseModel):
    id: str
    name: str
    district: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

# Lot Schemas
class LotMemberCreate(BaseModel):
    member_name: str
    quantity_kg: float = Field(..., gt=0)
    grade: Optional[str] = None

class LotMemberResponse(LotMemberCreate):
    id: str
    member_id: Optional[str] = None
    
    model_config = ConfigDict(from_attributes=True)

class ProduceLotCreate(BaseModel):
    crop_name: str
    harvest_date: Optional[date] = None
    members: List[LotMemberCreate]

class ProduceLotResponse(BaseModel):
    id: str
    fpo_id: str
    crop_id: str
    total_quantity_q: float
    total_quantity_kg: float
    grade_summary: Optional[str] = None
    status: LotStatus
    harvest_date: Optional[date] = None
    members: List[LotMemberResponse] = []
    
    model_config = ConfigDict(from_attributes=True)

# Buyer & Market Schemas
class BuyerResponse(BaseModel):
    id: str
    name: str
    type: str
    location: Optional[str] = None
    distance_km: float
    gross_price_per_qt: float
    transport_cost_per_qt: float
    loading_cost_per_qt: float
    commission_rate: float
    quality_deduction_per_qt: float
    misc_cost_per_qt: float
    payment_terms: Optional[str] = None
    min_quantity_qt: float
    max_quantity_qt: float
    reliability_score: float
    demand_signal: Optional[str] = None
    data_label: str = "DEMO_DATA"

    model_config = ConfigDict(from_attributes=True)

# NRP & Opportunity Schemas
class ItemizedBreakdown(BaseModel):
    gross_price: float
    transport_cost: float
    loading_cost: float
    commission_amount: float
    quality_deduction: float
    misc_cost: float

class OpportunityMatchScore(BaseModel):
    total_score: float
    quantity_fit_score: float
    quality_fit_score: float
    nrp_score: float
    payment_terms_score: float
    reliability_score: float
    label: str

class OpportunityResponse(BaseModel):
    buyer: BuyerResponse
    rank: int
    nrp_per_qt: float
    total_nrp: float
    breakdown: ItemizedBreakdown
    match_score: OpportunityMatchScore
    freight_override_applied: bool

class NRPCalculationResponse(BaseModel):
    lot_id: str
    opportunities: List[OpportunityResponse]

# Decision Engine Schemas
class RecommendationResponse(BaseModel):
    action: DecisionAction
    recommended_buyer_name: Optional[str] = None
    recommended_buyer_id: Optional[str] = None
    justification_points: List[str]
    ai_explanation: str
    freight_override_applied: bool
    data_label: str = "DEMO_DATA"

class FreightOverrideRequest(BaseModel):
    freight_cost: float = Field(..., ge=0)

# New Schemas
class UserLogin(BaseModel):
    email: Optional[str] = None
    phone: Optional[str] = None
    password: str

class UserResponse(BaseModel):
    id: str
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    role: UserRole
    fpo_id: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class OrderCreate(BaseModel):
    lot_id: str
    buyer_id: str
    agreed_price_per_q: float
    quantity_q: float

class OrderResponse(BaseModel):
    id: str
    lot_id: str
    buyer_id: str
    fpo_id: str
    status: OrderStatus
    agreed_price_per_q: float
    quantity_q: float
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)

class GovernmentSchemeCreate(BaseModel):
    title: str
    description: str
    benefits: str
    eligibility: str
    deadline: Optional[date] = None
    official_url: Optional[str] = None
    state: Optional[str] = None
    district: Optional[str] = None
    crops: Optional[str] = None  # comma-separated
    target_role: Optional[str] = None  # farmer / fpo / buyer / all
    status: Optional[str] = "published"
    source_key: Optional[str] = None

class GovernmentSchemeResponse(GovernmentSchemeCreate):
    id: str
    created_at: datetime
    source_type: Optional[str] = "manual"
    source_last_checked: Optional[datetime] = None
    relevance_score: Optional[int] = None
    relevance_label: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

# --- Negotiation schemas ---

class CounterpartyResponse(BaseModel):
    id: str
    name: Optional[str] = None
    role: str

class NegotiationRoundResponse(BaseModel):
    id: str
    offered_price_per_q: float
    status: NegotiationStatus
    created_by_user_id: Optional[str] = None
    created_by_role: Optional[str] = None
    message: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class NegotiationOrderResponse(BaseModel):
    id: str
    crop_name: Optional[str] = None
    quantity_q: float
    status: OrderStatus
    agreed_price_per_q: Optional[float] = None
    farmer_user_id: Optional[str] = None
    buyer_user_id: Optional[str] = None
    fpo_user_id: Optional[str] = None
    initiated_by_user_id: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    rounds: List[NegotiationRoundResponse] = []

    model_config = ConfigDict(from_attributes=True)

class NegotiationCreateRequest(BaseModel):
    counterparty_user_id: str
    crop_name: str
    quantity_q: float = Field(..., gt=0)
    offer_price_per_q: float = Field(..., gt=0)
    lot_id: Optional[str] = None

class NegotiationCounterRequest(BaseModel):
    price_per_q: float = Field(..., gt=0)
    message: Optional[str] = None

class NegotiationAiAssistRequest(BaseModel):
    minimum_selling_price: Optional[float] = None
    ideal_selling_price: Optional[float] = None
    lang: Optional[str] = "en"

# --- Order tracking schemas ---

class OrderTrackingCreate(BaseModel):
    status: OrderStatus
    location: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    notes: Optional[str] = None
    is_demo: bool = True

class OrderTrackingPointResponse(BaseModel):
    id: str
    status: OrderStatus
    location: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    timestamp: datetime
    notes: Optional[str] = None
    is_demo: bool = True

    model_config = ConfigDict(from_attributes=True)
