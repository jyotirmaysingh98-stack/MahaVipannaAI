import type { Config } from 'tailwindcss'

/**
 * MahaVipanan AI — design tokens: "The Ledger & The Field".
 *
 * Light-first, projector-legible premium B2B surface (UI_UX.md warns against
 * dark/government aesthetics). Colour is SEMANTIC, validated for colour-blind
 * safety via the dataviz palette validator — do not add chart series hues here
 * without re-validating:
 *   amber  = gross / quoted price (the seductive headline number)
 *   pine   = net realizable price / the best real option
 *   clay   = deductions / value erosion
 *   teal   = system intelligence (calculated-by-engine UI accent, never a chart
 *            series adjacent to pine)
 *   indigo = 3rd categorical chart series only
 */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: 'var(--color-paper)',
        surface: {
          DEFAULT: 'var(--color-surface)',
          sunk: 'var(--color-surface-sunk)',
          raised: 'var(--color-surface)',
        },
        line: {
          DEFAULT: 'var(--color-line)',
          strong: 'var(--color-line-strong)',
        },
        ink: {
          DEFAULT: 'var(--color-ink)',
          2: 'var(--color-ink-2)',
          3: 'var(--color-ink-3)',
        },
        pine: {
          50: '#EEF5EF',
          100: '#D6E7DA',
          200: '#AECFB6',
          300: '#7FB18C',
          400: '#4B9066',
          500: '#15734F',
          600: '#0F5C3F',
          700: '#0C4A33',
          900: '#0F2E1D',
        },
        amber: {
          50: '#FBF3E2',
          100: '#F6E4BE',
          200: '#EFCE86',
          300: '#E8B94F',
          400: '#E0A32E',
          500: '#C6871A',
          600: '#B87817',
          700: '#8F5E12',
        },
        clay: {
          50: '#F7E7E1',
          100: '#F0D1C6',
          300: '#D08C74',
          500: '#A8442C',
          600: '#8F3A25',
          700: '#73301F',
        },
        teal: {
          50: '#E4F1F2',
          100: '#D3EBEE',
          300: '#7FC2C9',
          500: '#0E7C86',
          600: '#0B646C',
          700: '#094F56',
        },
        indigo: {
          100: '#DEE2F5',
          500: '#3A4FB0',
          600: '#2E3F8C',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk Variable"', '"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['"Inter Variable"', 'Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display-xl': ['clamp(2.75rem, 5vw, 4.25rem)', { lineHeight: '1.02', letterSpacing: '-0.03em' }],
        'display-lg': ['clamp(2.25rem, 3.6vw, 3.25rem)', { lineHeight: '1.05', letterSpacing: '-0.025em' }],
        'display-md': ['clamp(1.75rem, 2.4vw, 2.25rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
      },
      boxShadow: {
        card: '0 1px 2px rgba(26,36,25,0.04), 0 8px 24px -14px rgba(26,36,25,0.14)',
        'card-lg': '0 2px 4px rgba(26,36,25,0.05), 0 28px 56px -28px rgba(26,36,25,0.22)',
        float: '0 12px 40px -12px rgba(26,36,25,0.24)',
        'glow-pine': '0 0 0 1px rgba(21,115,79,0.18), 0 8px 30px -8px rgba(21,115,79,0.35)',
        'glow-amber': '0 0 0 1px rgba(224,163,46,0.25), 0 8px 30px -8px rgba(224,163,46,0.4)',
        'glow-teal': '0 0 0 1px rgba(14,124,134,0.2), 0 6px 24px -8px rgba(14,124,134,0.35)',
        'inset-line': 'inset 0 0 0 1px rgba(231,231,222,0.9)',
      },
      borderRadius: {
        xl: '0.875rem',
        '2xl': '1.125rem',
        '3xl': '1.5rem',
      },
      backgroundImage: {
        'field-mesh':
          'radial-gradient(60% 50% at 0% 0%, rgba(21,115,79,0.06), transparent 60%), radial-gradient(55% 45% at 100% 0%, rgba(224,163,46,0.07), transparent 55%), radial-gradient(45% 60% at 85% 100%, rgba(14,124,134,0.045), transparent 60%)',
      },
      transitionTimingFunction: {
        spring: 'cubic-bezier(0.22, 1, 0.36, 1)',
        'out-quart': 'cubic-bezier(0.25, 1, 0.5, 1)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '100%': { transform: 'translateX(100%)' },
        },
        'pulse-ring': {
          '0%': { boxShadow: '0 0 0 0 rgba(14,124,134,0.35)' },
          '70%': { boxShadow: '0 0 0 8px rgba(14,124,134,0)' },
          '100%': { boxShadow: '0 0 0 0 rgba(14,124,134,0)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.5s var(--ease-spring, cubic-bezier(0.22,1,0.36,1)) both',
        shimmer: 'shimmer 1.6s infinite',
        'pulse-ring': 'pulse-ring 2.2s ease-out infinite',
      },
    },
  },
  plugins: [],
} satisfies Config
