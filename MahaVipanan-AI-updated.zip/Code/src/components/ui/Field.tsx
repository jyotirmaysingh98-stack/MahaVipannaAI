import { forwardRef, type InputHTMLAttributes, type ReactNode } from 'react'
import { cn } from '@/lib/cn'

const fieldBase =
  'w-full rounded-xl border border-line-strong bg-surface px-3.5 text-ink placeholder:text-ink-3 ' +
  'transition-all duration-200 focus:border-pine-400 focus:outline-none focus:ring-4 focus:ring-pine-500/10 ' +
  'disabled:opacity-60'

export interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  hint?: ReactNode
  /** Adornment rendered inside the field on the left (e.g. ₹). */
  prefixNode?: ReactNode
  suffix?: ReactNode
  containerClassName?: string
}

export const Field = forwardRef<HTMLInputElement, FieldProps>(function Field(
  { label, hint, prefixNode, suffix, className, containerClassName, id, ...props },
  ref,
) {
  const inputId = id ?? props.name
  return (
    <div className={cn('w-full', containerClassName)}>
      {label && (
        <label htmlFor={inputId} className="mb-1.5 block text-sm font-medium text-ink-2">
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        {prefixNode && <span className="pointer-events-none absolute left-3.5 text-sm text-ink-3">{prefixNode}</span>}
        <input
          ref={ref}
          id={inputId}
          className={cn(fieldBase, 'h-11', prefixNode && 'pl-8', suffix && 'pr-12', className)}
          {...props}
        />
        {suffix && <span className="pointer-events-none absolute right-3.5 text-sm text-ink-3">{suffix}</span>}
      </div>
      {hint && <p className="mt-1.5 text-xs text-ink-3">{hint}</p>}
    </div>
  )
})

export function Select({
  label,
  hint,
  className,
  containerClassName,
  children,
  id,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string; hint?: ReactNode; containerClassName?: string }) {
  const selectId = id ?? props.name
  return (
    <div className={cn('w-full', containerClassName)}>
      {label && (
        <label htmlFor={selectId} className="mb-1.5 block text-sm font-medium text-ink-2">
          {label}
        </label>
      )}
      <select id={selectId} className={cn(fieldBase, 'h-11 appearance-none pr-9', className)} {...props}>
        {children}
      </select>
      {hint && <p className="mt-1.5 text-xs text-ink-3">{hint}</p>}
    </div>
  )
}
