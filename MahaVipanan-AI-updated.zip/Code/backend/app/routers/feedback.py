from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from ..database import get_db
from ..models.core import Feedback, generate_uuid

feedback_router = APIRouter(prefix="/api/feedback", tags=["Feedback"])

class FeedbackCreate(BaseModel):
    from_user_id: str
    to_user_id: Optional[str] = None
    to_buyer_id: Optional[str] = None
    order_id: Optional[str] = None
    rating: int
    comments: Optional[str] = None

class FeedbackResponse(BaseModel):
    success: bool
    data: Optional[dict] = None
    error: Optional[str] = None

@feedback_router.post("", response_model=FeedbackResponse)
def submit_feedback(payload: FeedbackCreate, db: Session = Depends(get_db)):
    """Submit feedback for a completed order/service."""
    if payload.rating < 1 or payload.rating > 5:
        return FeedbackResponse(success=False, error="Rating must be between 1 and 5")

    # Check for duplicate feedback
    existing = db.query(Feedback).filter(
        Feedback.from_user_id == payload.from_user_id,
        Feedback.order_id == payload.order_id
    ).first()
    if existing:
        return FeedbackResponse(success=False, error="Feedback already submitted for this order")

    fb = Feedback(
        id=generate_uuid(),
        from_user_id=payload.from_user_id,
        to_user_id=payload.to_user_id,
        to_buyer_id=payload.to_buyer_id,
        order_id=payload.order_id,
        rating=payload.rating,
        comments=payload.comments
    )
    db.add(fb)
    db.commit()
    db.refresh(fb)

    return FeedbackResponse(success=True, data={
        "id": fb.id,
        "rating": fb.rating,
        "comments": fb.comments,
        "created_at": str(fb.created_at)
    })

@feedback_router.get("")
def get_feedback(user_id: Optional[str] = None, order_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Get feedback entries, optionally filtered by user or order."""
    query = db.query(Feedback)
    if user_id:
        query = query.filter(Feedback.from_user_id == user_id)
    if order_id:
        query = query.filter(Feedback.order_id == order_id)
    
    results = query.order_by(Feedback.created_at.desc()).all()
    return {
        "success": True,
        "data": [
            {
                "id": fb.id,
                "from_user_id": fb.from_user_id,
                "order_id": fb.order_id,
                "rating": fb.rating,
                "comments": fb.comments,
                "created_at": str(fb.created_at)
            }
            for fb in results
        ]
    }
