import {
  ApiEnvelope,
  FpoDashboard,
  LotResponse,
  LotCreatePayload,
  OpportunitiesData,
  RecalculatePayload,
  Counterparty,
  NegotiationOrder,
  NegotiationAiSuggestion,
  GovernmentScheme,
  SchemeSource,
  OrderSummary,
  OrderTrackingPoint
} from './types'

// Use environment variable or fallback to localhost for development
const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000'

class ApiError extends Error {
  constructor(public message: string, public status?: number) {
    super(message)
    this.name = 'ApiError'
  }
}

async function request<T>(endpoint: string, options?: RequestInit): Promise<ApiEnvelope<T>> {
  const url = `${BASE_URL}${endpoint}`
  
  try {
    const token = sessionStorage.getItem('mv.auth.token')
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        ...(options?.headers || {})
      }
    })

    const data = await response.json()

    if (!response.ok || !data.success) {
      throw new ApiError(data.error || 'An error occurred', response.status)
    }

    return data as ApiEnvelope<T>
  } catch (error) {
    if (error instanceof ApiError) throw error
    throw new ApiError('Network error or backend unavailable')
  }
}

export const api = {
  login: (payload: any) => request<any>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),
  
  signup: (payload: any) => request<any>('/api/auth/signup', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),

  getDashboard: () => request<FpoDashboard>('/api/fpo/dashboard'),
  
  getLots: () => request<LotResponse[]>('/api/lots/'),
  
  getLot: (id: string) => request<LotResponse>(`/api/lots/${id}`),
  
  deleteLot: (id: string) => request<any>(`/api/lots/${id}`, { method: 'DELETE' }),
  
  sendMessage: (message: string, lang?: string) => request<{reply: string}>('/api/chat/message', {
    method: 'POST',
    body: JSON.stringify({ message, lang })
  }),

  // --- Negotiations ---
  listNegotiations: () => request<NegotiationOrder[]>('/api/negotiations'),
  getNegotiation: (id: string) => request<NegotiationOrder>(`/api/negotiations/${id}`),
  listCounterparties: (role: string) => request<Counterparty[]>(`/api/negotiations/counterparties?role=${role}`),
  createNegotiation: (payload: { counterparty_user_id: string; crop_name: string; quantity_q: number; offer_price_per_q: number }) =>
    request<NegotiationOrder>('/api/negotiations', { method: 'POST', body: JSON.stringify(payload) }),
  counterNegotiation: (orderId: string, payload: { price_per_q: number; message?: string }) =>
    request<NegotiationOrder>(`/api/negotiations/${orderId}/counter`, { method: 'POST', body: JSON.stringify(payload) }),
  acceptNegotiation: (orderId: string) => request<NegotiationOrder>(`/api/negotiations/${orderId}/accept`, { method: 'POST' }),
  rejectNegotiation: (orderId: string) => request<NegotiationOrder>(`/api/negotiations/${orderId}/reject`, { method: 'POST' }),
  aiAssistNegotiation: (orderId: string, payload: { minimum_selling_price?: number; ideal_selling_price?: number; lang?: string }) =>
    request<NegotiationAiSuggestion>(`/api/negotiations/${orderId}/ai-assist`, { method: 'POST', body: JSON.stringify(payload) }),

  // --- Government schemes ---
  listSchemes: (params?: { state?: string; crop?: string }) => {
    const qs = new URLSearchParams(params as any).toString()
    return request<GovernmentScheme[]>(`/api/schemes/${qs ? `?${qs}` : ''}`)
  },
  createScheme: (payload: Partial<GovernmentScheme>) => request<GovernmentScheme>('/api/schemes/', { method: 'POST', body: JSON.stringify(payload) }),
  updateScheme: (id: string, payload: Partial<GovernmentScheme>) => request<GovernmentScheme>(`/api/schemes/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  getSchemeSources: () => request<SchemeSource[]>('/api/schemes/sources'),
  syncSchemeSources: () => request<{ sources: any[]; synced_at: string | null }>('/api/schemes/sync', { method: 'POST' }),

  // --- Orders / tracking ---
  listOrders: () => request<OrderSummary[]>('/api/orders/'),
  getOrderTracking: (orderId: string) => request<OrderTrackingPoint[]>(`/api/orders/${orderId}/tracking`),
  advanceDemoTracking: (orderId: string) => request<OrderTrackingPoint>(`/api/orders/${orderId}/tracking/advance-demo`, { method: 'POST' }),
  
  createLot: (payload: LotCreatePayload) => 
    request<LotResponse>('/api/lots/', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
    
  getOpportunities: (lotId: string) => 
    request<OpportunitiesData>(`/api/opportunities/${lotId}`),
    
  recalculateFreight: (lotId: string, payload: RecalculatePayload) =>
    request<OpportunitiesData>(`/api/opportunities/${lotId}/recalculate`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  submitFeedback: (payload: { from_user_id: string; order_id?: string; rating: number; comments?: string }) =>
    request<{ id: string; rating: number; comments: string; created_at: string }>('/api/feedback', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  getFeedback: (userId?: string, orderId?: string) => {
    const params = new URLSearchParams()
    if (userId) params.set('user_id', userId)
    if (orderId) params.set('order_id', orderId)
    return request<any[]>(`/api/feedback?${params.toString()}`)
  }
}
