from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import date
from pydantic import BaseModel
from typing import Optional

from ..database import get_db
from ..models.core import Crop, PriceRecord

router = APIRouter(prefix="/simulator", tags=["simulator"])

class SimulatorRequest(BaseModel):
    crop_id: str
    harvest_date: Optional[date] = None

class SimulatorResponse(BaseModel):
    crop_name: str
    predicted_price_per_q: float
    remaining_shelf_life_days: int
    total_shelf_life_days: int
    status: str
    message: str

@router.post("/predict", response_model=SimulatorResponse)
def predict_price_and_shelf_life(req: SimulatorRequest, db: Session = Depends(get_db)):
    crop = db.query(Crop).filter(Crop.id == req.crop_id).first()
    if not crop:
        raise HTTPException(status_code=404, detail="Crop not found")
        
    harvest = req.harvest_date or date.today()
    days_since_harvest = (date.today() - harvest).days
    total_shelf_life = crop.perishability_window_days or 14 # default fallback
    
    remaining_days = max(0, total_shelf_life - days_since_harvest)
    
    if remaining_days > total_shelf_life * 0.5:
        status = "good"
        message = "Optimal freshness. Expected to fetch premium market price."
        decay_factor = 1.0
    elif remaining_days > 0:
        status = "warning"
        message = "Approaching end of shelf life. Potential price degradation."
        decay_factor = 0.8
    else:
        status = "expired"
        message = "Shelf life exceeded. High risk of rejection or severe price cuts."
        decay_factor = 0.4
        
    # Get base price from recent PriceRecords (or fallback)
    recent_price = db.query(PriceRecord).filter(PriceRecord.crop_id == req.crop_id).order_by(PriceRecord.observed_on.desc()).first()
    base_price = recent_price.price_per_q if recent_price else 2500.0
    
    predicted_price = base_price * decay_factor
    
    return SimulatorResponse(
        crop_name=crop.name,
        predicted_price_per_q=round(predicted_price, 2),
        remaining_shelf_life_days=remaining_days,
        total_shelf_life_days=total_shelf_life,
        status=status,
        message=message
    )

@router.get("/crops")
def get_crops_for_simulator(db: Session = Depends(get_db)):
    crops = db.query(Crop).all()
    return [{"id": c.id, "name": c.name} for c in crops]
