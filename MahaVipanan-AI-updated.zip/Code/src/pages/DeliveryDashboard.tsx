import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Truck, Clock, Loader2, ArrowRight } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { useI18n } from '@/lib/i18n'
import { api } from '@/api/client'
import type { OrderSummary, OrderTrackingPoint } from '@/api/types'
import { TrackingMap } from '@/components/map/TrackingMap'
import { useToast } from '@/components/ui/Toast'

export function DeliveryDashboard() {
  const { t } = useI18n()
  const toast = useToast()
  const [orders, setOrders] = useState<OrderSummary[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [tracking, setTracking] = useState<OrderTrackingPoint[]>([])
  const [loading, setLoading] = useState(true)
  const [advancing, setAdvancing] = useState(false)

  const load = () => {
    setLoading(true)
    api.listOrders().then(res => {
      const data = res.data || []
      setOrders(data)
      if (data.length > 0) setSelected(data[0].id)
    }).catch(() => {}).finally(() => setLoading(false))
  }
  useEffect(load, [])

  useEffect(() => {
    if (!selected) return
    api.getOrderTracking(selected).then(res => setTracking(res.data || [])).catch(() => setTracking([]))
  }, [selected])

  const advance = async () => {
    if (!selected) return
    setAdvancing(true)
    try {
      await api.advanceDemoTracking(selected)
      const res = await api.getOrderTracking(selected)
      setTracking(res.data || [])
      toast.toast({ title: t('delivery.advanced'), tone: 'success' })
    } catch (e: any) {
      toast.toast({ title: e.message || t('delivery.advanceFailed'), tone: 'info' })
    } finally {
      setAdvancing(false)
    }
  }

  const inTransitCount = orders.filter(o => o.status === 'accepted' || o.status === 'pickup' || o.status === 'in_transit').length
  const deliveredCount = orders.filter(o => o.status === 'delivered').length

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">{t('delivery.title')}</h1>
        <p className="mt-1 text-ink-2">{t('delivery.subtitle')}</p>
      </div>

      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="grid gap-6 md:grid-cols-3">
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-50 text-pine-600"><Truck size={24} /></div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('delivery.assignedOrders')}</p>
              <p className="text-2xl font-bold text-ink">{orders.length}</p>
            </div>
          </div>
        </motion.div>
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-50 text-amber-600"><Clock size={24} /></div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('delivery.pendingPickups')}</p>
              <p className="text-2xl font-bold text-ink">{inTransitCount}</p>
            </div>
          </div>
        </motion.div>
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-50 text-pine-600"><Truck size={24} /></div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('delivery.delivered')}</p>
              <p className="text-2xl font-bold text-ink">{deliveredCount}</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('delivery.currentRoute')}</h2>
          <TrackingMap points={tracking} height={280} />
          {selected && tracking.length > 0 && tracking[tracking.length - 1].status !== 'delivered' && (
            <button onClick={advance} disabled={advancing}
              className="flex items-center gap-2 rounded-xl bg-pine-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-pine-700 disabled:opacity-60">
              {advancing ? <Loader2 className="animate-spin" size={16} /> : <ArrowRight size={16} />} {t('delivery.advanceRoute')}
            </button>
          )}
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">{t('delivery.taskList')}</h2>
          <div className="rounded-2xl border border-line bg-surface p-4 space-y-2 max-h-[340px] overflow-y-auto">
            {loading && <div className="flex justify-center py-8"><Loader2 className="animate-spin text-pine-600" /></div>}
            {!loading && orders.length === 0 && <p className="text-center text-sm text-ink-3 py-8">{t('delivery.empty')}</p>}
            {orders.map(o => (
              <button
                key={o.id}
                onClick={() => setSelected(o.id)}
                className={`w-full flex justify-between items-center rounded-xl px-4 py-3 text-left transition-colors ${selected === o.id ? 'bg-pine-50 ring-1 ring-pine-200' : 'hover:bg-surface-sunk'}`}
              >
                <div>
                  <p className="font-semibold text-ink">{o.crop_name || t('negotiation.produce')}</p>
                  <p className="text-xs text-ink-3">{o.quantity_q} qt</p>
                </div>
                <span className="text-xs font-bold uppercase text-pine-700">{t(`order.status.${o.status}`)}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
