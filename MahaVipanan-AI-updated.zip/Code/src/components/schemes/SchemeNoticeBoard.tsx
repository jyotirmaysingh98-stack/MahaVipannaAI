import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Landmark, ChevronRight, ExternalLink, X, RefreshCcw, Loader2 } from 'lucide-react'
import { cn } from '@/lib/cn'
import { useI18n } from '@/lib/i18n'
import { useApp } from '@/state/AppContext'
import { api } from '@/api/client'
import type { GovernmentScheme, SchemeSource } from '@/api/types'
import { useToast } from '@/components/ui/Toast'

export function SchemeNoticeBoard() {
  const { t } = useI18n()
  const { role } = useApp()
  const toast = useToast()
  const [open, setOpen] = useState(false)
  const [schemes, setSchemes] = useState<GovernmentScheme[]>([])
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [sources, setSources] = useState<SchemeSource[]>([])
  const [syncing, setSyncing] = useState(false)

  const isGovt = role === 'government' || role === 'admin'
  const eligible = ['farmer', 'fpo', 'buyer', 'government', 'admin'].includes(role || '')

  useEffect(() => {
    if (!eligible) return
    api.listSchemes().then(res => setSchemes(res.data || [])).catch(() => {})
    if (isGovt) api.getSchemeSources().then(res => setSources(res.data || [])).catch(() => {})
  }, [eligible, isGovt])

  if (!eligible) return null

  const relevantCount = schemes.filter(s => s.relevance_label !== 'General scheme').length

  const syncNow = async () => {
    setSyncing(true)
    try {
      await api.syncSchemeSources()
      const [schemesRes, sourcesRes] = await Promise.all([api.listSchemes(), api.getSchemeSources()])
      setSchemes(schemesRes.data || [])
      setSources(sourcesRes.data || [])
      toast.toast({ title: t('schemes.syncDone'), tone: 'success' })
    } catch (e: any) {
      toast.toast({ title: e.message || t('schemes.syncFailed'), tone: 'info' })
    } finally {
      setSyncing(false)
    }
  }

  return (
    <>
      {/* Persistent edge tab */}
      <button
        onClick={() => setOpen(true)}
        className="fixed right-0 top-1/3 z-40 flex items-center gap-1.5 rounded-l-2xl bg-ink px-3 py-3 text-white shadow-lg hover:bg-ink/90"
      >
        <Landmark size={16} />
        {relevantCount > 0 && (
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-clay-500 text-[10px] font-bold">{relevantCount}</span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40 }}
            className="fixed right-0 top-0 z-50 flex h-full w-full max-w-[400px] flex-col overflow-hidden border-l border-line bg-surface shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-line bg-ink px-5 py-4 text-white">
              <div className="flex items-center gap-2">
                <Landmark size={18} />
                <h3 className="font-display font-bold">{t('schemes.title')}</h3>
              </div>
              <button onClick={() => setOpen(false)} className="rounded-full p-2 hover:bg-white/20"><X size={18} /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {isGovt && (
                <div className="rounded-2xl border border-line bg-surface-sunk p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase text-ink-3">{t('schemes.govtSourceStatus')}</span>
                    <button onClick={syncNow} disabled={syncing} className="flex items-center gap-1 rounded-full bg-pine-600 px-3 py-1 text-[11px] font-bold text-white hover:bg-pine-700 disabled:opacity-60">
                      {syncing ? <Loader2 size={12} className="animate-spin" /> : <RefreshCcw size={12} />} {t('schemes.refresh')}
                    </button>
                  </div>
                  <div className="space-y-1">
                    {sources.map(s => (
                      <div key={s.key} className="flex items-center justify-between text-[11px] text-ink-3">
                        <span>{s.name}</span>
                        <span>{s.last_checked ? new Date(s.last_checked).toLocaleTimeString() : t('schemes.neverSynced')}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {schemes.length === 0 && <p className="text-center text-sm text-ink-3 py-10">{t('schemes.empty')}</p>}

              {schemes.map(s => (
                <div key={s.id} className="rounded-2xl border border-line bg-surface shadow-sm overflow-hidden">
                  <button onClick={() => setExpandedId(expandedId === s.id ? null : s.id)} className="w-full flex items-center justify-between p-3 text-left">
                    <div>
                      <p className="font-bold text-sm text-ink">{s.title}</p>
                      <span className={cn('inline-block mt-1 rounded-full px-2 py-0.5 text-[10px] font-bold',
                        s.relevance_label === 'Relevant to you' ? 'bg-pine-50 text-pine-700' : s.relevance_label === 'Potentially relevant' ? 'bg-amber-50 text-amber-700' : 'bg-surface-sunk text-ink-3')}>
                        {t(`schemes.relevance.${s.relevance_label === 'Relevant to you' ? 'relevant' : s.relevance_label === 'Potentially relevant' ? 'potential' : 'general'}`)}
                      </span>
                    </div>
                    <ChevronRight size={16} className={cn('shrink-0 transition-transform text-ink-3', expandedId === s.id && 'rotate-90')} />
                  </button>
                  {expandedId === s.id && (
                    <div className="px-3 pb-3 space-y-2 text-sm text-ink-3">
                      <p>{s.description}</p>
                      <p><span className="font-bold text-ink">{t('schemes.benefits')}:</span> {s.benefits}</p>
                      <p><span className="font-bold text-ink">{t('schemes.eligibility')}:</span> {s.eligibility}</p>
                      {s.deadline && <p><span className="font-bold text-ink">{t('schemes.deadline')}:</span> {s.deadline}</p>}
                      {s.official_url && (
                        <a href={s.official_url} target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-xl bg-pine-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-pine-700">
                          {t('schemes.visitOfficial')} <ExternalLink size={12} />
                        </a>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
