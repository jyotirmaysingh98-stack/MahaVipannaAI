import { useCountUp } from '@/lib/hooks'
import { cn } from '@/lib/cn'

/**
 * Eases to `value` and formats each frame. Used for hero net-realization figures
 * and KPI tiles. Snaps instantly under reduced motion (handled in useCountUp).
 */
export function AnimatedNumber({
  value,
  format,
  className,
  duration,
}: {
  value: number
  format: (n: number) => string
  className?: string
  duration?: number
}) {
  const display = useCountUp(value, { duration })
  return <span className={cn('tnum tabular-nums', className)}>{format(display)}</span>
}
