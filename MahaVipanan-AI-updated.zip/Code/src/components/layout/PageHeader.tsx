import type { ReactNode } from 'react'
import { ChevronRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { cn } from '@/lib/cn'

export interface Crumb {
  label: string
  to?: string
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  crumbs,
  className,
}: {
  eyebrow?: string
  title: ReactNode
  description?: ReactNode
  actions?: ReactNode
  crumbs?: Crumb[]
  className?: string
}) {
  return (
    <div className={cn('mb-6', className)}>
      {crumbs && crumbs.length > 0 && (
        <nav className="mb-3 flex items-center gap-1 text-xs text-ink-3" aria-label="Breadcrumb">
          {crumbs.map((c, i) => (
            <span key={i} className="flex items-center gap-1">
              {i > 0 && <ChevronRight size={12} className="text-line-strong" />}
              {c.to ? (
                <Link to={c.to} className="transition-colors hover:text-pine-600">
                  {c.label}
                </Link>
              ) : (
                <span className="text-ink-2">{c.label}</span>
              )}
            </span>
          ))}
        </nav>
      )}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          {eyebrow && <p className="eyebrow mb-1.5">{eyebrow}</p>}
          <h1 className="text-display-md font-semibold text-ink">{title}</h1>
          {description && <p className="mt-2 max-w-2xl text-[0.95rem] leading-relaxed text-ink-2">{description}</p>}
        </div>
        {actions && <div className="flex shrink-0 items-center gap-2.5">{actions}</div>}
      </div>
    </div>
  )
}
