import { motion } from 'framer-motion'
import { Tractor, Sprout, HandCoins, TrendingUp } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { NegotiationMeter } from '@/components/radar/NegotiationMeter'

export function FarmerDashboard() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">My Farm & Lots</h1>
        <p className="mt-1 text-ink-2">Manage your produce, track negotiations, and check schemes.</p>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-50 text-pine-600">
              <Sprout size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Active Lots</p>
              <p className="text-2xl font-bold text-ink">3 Lots</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-indigo-50 text-indigo-600">
              <HandCoins size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Ongoing Negotiations</p>
              <p className="text-2xl font-bold text-ink">1 Active</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-50 text-amber-600">
              <Tractor size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">Subsidies Eligible</p>
              <p className="text-2xl font-bold text-ink">2 Schemes</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">Active Negotiation</h2>
          <NegotiationMeter currentOffer={1750} minimumSellingPrice={1800} idealSellingPrice={1950} />
        </div>

        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-ink">Market Price Alerts</h2>
          <div className="rounded-2xl border border-pine-200 bg-pine-50 p-6 flex gap-4">
            <TrendingUp className="text-pine-600 shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-pine-900">Onion prices up 5%</h3>
              <p className="text-sm text-pine-700 mt-1">Average market realization is currently higher. Consider selling soon.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
