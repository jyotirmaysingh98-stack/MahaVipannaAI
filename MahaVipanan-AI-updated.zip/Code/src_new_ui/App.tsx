import { useEffect, useState } from 'react'
import { createBrowserRouter, Navigate, useNavigate } from 'react-router-dom'
import { LandingPage } from './pages/Landing'
import { LoginPage } from './pages/Login'
import { DashboardPage } from './pages/Dashboard'
import { OpportunitiesPage } from './pages/Opportunities'
import { OrdersPage } from './pages/Orders'
import { AdminPage } from './pages/Admin'
import { SchemesPage } from './pages/Schemes'
import { FarmerDashboard } from './pages/FarmerDashboard'
import { BuyerDashboard } from './pages/BuyerDashboard'
import { DeliveryDashboard } from './pages/DeliveryDashboard'
import { GovtDashboard } from './pages/GovtDashboard'
import { AppShell } from './components/layout/AppShell'
import { NotFoundPage } from './pages/NotFound'
import { useApp } from './state/AppContext'
import { api } from './api/client'
import { Skeleton } from './components/ui/Skeleton'

function Protected({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, fpoLoading } = useApp()
  if (fpoLoading) return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="space-y-3 w-64">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
    </div>
  )
  if (!isAuthenticated) return <Navigate to="/login" replace />
  return <>{children}</>
}

function RoleRedirect() {
  const { role } = useApp()
  if (!role) return <Navigate to="/login" replace />
  return <Navigate to={`/app/${role}`} replace />
}

function LotListRedirect() {
  const navigate = useNavigate()
  const [error, setError] = useState(false)

  useEffect(() => {
    api.getLots()
      .then((res) => {
        const lots = res.data
        if (lots && lots.length > 0) {
          navigate(`/app/fpo/lots/${lots[0].id}`, { replace: true })
        } else {
          navigate('/app/fpo', { replace: true })
        }
      })
      .catch(() => setError(true))
  }, [navigate])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <p className="text-lg font-semibold text-ink">Could not load lots</p>
        <p className="mt-2 text-sm text-ink-3">Make sure the backend is running.</p>
      </div>
    )
  }

  return (
    <div className="space-y-3 py-8">
      <Skeleton className="h-8 w-56" />
      <Skeleton className="h-4 w-96" />
      <Skeleton className="mt-4 h-48 w-full rounded-2xl" />
    </div>
  )
}

export const router = createBrowserRouter([
  { path: '/', element: <LandingPage /> },
  { path: '/login', element: <LoginPage /> },
  {
    path: '/app',
    element: <Protected><AppShell /></Protected>,
    errorElement: <NotFoundPage />,
    children: [
      { index: true, element: <RoleRedirect /> },
      
      // FPO Routes (Primary)
      { path: 'fpo', element: <DashboardPage /> },
      { path: 'fpo/lots', element: <LotListRedirect /> },
      { path: 'fpo/lots/:lotId', element: <OpportunitiesPage /> },
      { path: 'fpo/orders', element: <OrdersPage /> },
      
      // Farmer Routes
      { path: 'farmer', element: <FarmerDashboard /> },
      
      // Buyer Routes
      { path: 'buyer', element: <BuyerDashboard /> },
      
      // Delivery Routes
      { path: 'delivery', element: <DeliveryDashboard /> },
      
      // Government Routes
      { path: 'government', element: <GovtDashboard /> },
      
      // Shared / Admin Routes
      { path: 'admin', element: <AdminPage /> },
      { path: 'schemes', element: <SchemesPage /> },
    ]
  },
  { path: '*', element: <NotFoundPage /> }
])
