# MahaVipanan AI 🌾

> **Smart India Hackathon 2026 | SIH26132**  
> Theme: Agriculture, FoodTech & Rural Development · Track: Software

A decision-intelligence platform for **Farmer Producer Organisations (FPOs)** that ranks every buyer by **True Net Realizable Price (NRP)** — what the pool *actually keeps* after freight, commission, loading, and deductions — not just the headline quoted price.

---

## The Core Problem

FPO directors face a recurring trap: the buyer who quotes the highest price per quintal is often *not* the one who nets the most money for the pool. Transport, commission, loading fees, and quality deductions silently eat into the gross price. MahaVipanan AI makes every deduction visible and does the math automatically.

**Example from the demo data:**
- FreshMart quotes **₹2100/qt** → nets **₹1850/qt** after deductions
- Nashik Exports quotes **₹2050/qt** → nets **₹1920/qt** after deductions

The winner by NRP is **not** the winner by gross price.

---

## How It Works

```
Lot Data (crop, qty, grade)
     ↓
NRP Engine (deterministic formula per buyer)
     ↓
Buyer Matching (quantity fit, quality fit, reliability, payment terms)
     ↓
Ranking (sorted strictly by NRP)
     ↓
Decision Engine → SELL / HOLD / REDIRECT
     ↓
Claude AI (explains the decision in plain language — does NOT decide)
```

**The intelligence is deterministic.** The AI layer only translates numbers into words.

---

## Features

| Feature | Description |
|---|---|
| **NRP Calculation** | Gross − Transport − Loading − Commission − Quality − Misc |
| **Buyer Ranking** | Sorted by maximum net kept per quintal |
| **Match Score** | 5-factor buyer fit score (quantity, quality, NRP, payment terms, reliability) |
| **Freight What-If** | Enter the real transporter quote; the ranking re-sorts live |
| **SELL/HOLD/REDIRECT** | Deterministic rule-based decision |
| **AI Explanation** | Claude summarizes *why* — does not decide |
| **FPO Dashboard** | Active lots, total inventory at a glance |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React + TypeScript + Vite + Tailwind CSS |
| Backend | FastAPI (Python 3.12) |
| Database | SQLite (dev) — swap to PostgreSQL for production |
| AI | Anthropic Claude (claude-3-haiku), with deterministic fallback |
| Animation | Framer Motion |
| Deployment | Docker-ready |

---

## Quick Start

### Prerequisites
- Node.js 18+
- Python 3.12+
- Git

### 1. Clone

```bash
git clone https://github.com/your-org/mahavipanan-ai.git
cd mahavipanan-ai
```

### 2. Backend Setup

```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
```

### 3. Configure Environment

```bash
# Copy example and edit
cp .env.example backend/.env
```

Edit `backend/.env`:
```env
DATABASE_URL=sqlite:///./mahavipanan.db
LLM_API_KEY=your_anthropic_api_key_here   # Optional — fallback text used if blank
DEMO_MODE=true
SECRET_KEY=change_me_in_production
CORS_ORIGINS=http://localhost:5173,http://localhost:4173
```

> **Note:** If `LLM_API_KEY` is blank, the backend uses a deterministic template for AI explanations. The NRP/ranking/decision logic is unaffected.

### 4. Seed Database

```bash
cd backend
python seed_db.py
```

### 5. Start Backend

```bash
cd backend
uvicorn app.main:app --reload --port 8000
```

Backend will be live at: http://localhost:8000  
Swagger docs: http://localhost:8000/docs

### 6. Frontend Setup

```bash
# From project root
npm install
```

Edit `.env.local` (create from `.env.example`):
```env
VITE_API_BASE_URL=http://localhost:8000
VITE_DEMO_MODE=false
```

### 7. Start Frontend

```bash
npm run dev
```

Frontend will be live at: http://localhost:5173

---

## Demo Walkthrough

1. Visit `http://localhost:5173`
2. Click **"Open the live demo"** → Sign in (demo mode, no real auth)
3. You land on the **Market Opportunity Radar** for the first seeded lot
4. See buyers ranked by **Net Realizable Price** (not quoted price)
5. Expand any buyer card → view itemized deductions
6. Use **"Correct the freight"** panel → enter a real transporter cost → watch the ranking re-sort live
7. See the **SELL** recommendation change if freight correction flips the winner
8. Read the **AI explanation** (Anthropic Claude) in the "In plain words" section
9. Click **"Record decision"** → note this is a demo-only UI action (no backend storage)

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Backend health + DB status |
| GET | `/api/fpo/dashboard` | FPO stats, active lots, total inventory |
| GET | `/api/lots/` | All lots for the FPO |
| POST | `/api/lots/` | Create a new lot |
| GET | `/api/lots/{id}` | Single lot detail |
| GET | `/api/opportunities/{lot_id}` | Full ranked buyer list + decision |
| POST | `/api/opportunities/{lot_id}/recalculate` | Recalculate with freight override |

Full interactive docs: `http://localhost:8000/docs`

---

## Running Tests

```bash
cd backend
python -m pytest -v
```

**22/22 tests pass** covering:
- NRP Engine (formula correctness, freight override)
- Buyer Matching (5 scoring dimensions)
- Decision Engine (SELL/HOLD/REDIRECT paths)
- AI Explanation (fallback logic)
- API Integration (all endpoints, validation, 404)
- End-to-End Workflow

---

## Project Structure

```
mahavipanan-ai/
├── backend/                    # FastAPI backend
│   ├── app/
│   │   ├── main.py            # FastAPI app + CORS + error handlers
│   │   ├── config.py          # Settings (env vars)
│   │   ├── database.py        # SQLAlchemy setup
│   │   ├── models/            # SQLAlchemy ORM models
│   │   ├── schemas/           # Pydantic request/response schemas
│   │   ├── routers/           # API route handlers
│   │   ├── services/
│   │   │   ├── nrp_engine.py       # NRP calculation (deterministic)
│   │   │   ├── buyer_matcher.py    # Match scoring
│   │   │   ├── decision_engine.py  # SELL/HOLD/REDIRECT logic
│   │   │   └── ai_explanation.py   # Claude API + fallback
│   │   └── seed/              # Seed data
│   ├── tests/                 # 22 pytest tests
│   ├── seed_db.py             # DB seeder script
│   ├── requirements.txt
│   └── Dockerfile
├── src/                       # React + TypeScript frontend
│   ├── api/                   # API client + TypeScript types
│   ├── components/
│   │   ├── radar/             # Core product components
│   │   ├── charts/            # NRP waterfall + buyer comparison
│   │   ├── layout/            # AppShell, TopNav, PageHeader
│   │   ├── ui/                # Design system primitives
│   │   ├── brand/             # Logo, provenance badges
│   │   └── domain/            # FPO-specific badges + chips
│   ├── pages/                 # Landing, Login, Opportunities
│   ├── state/                 # AppContext + useRadar hook
│   └── lib/                   # Formatting, motion, utilities
├── .env.example               # Frontend env template
├── backend/.env.example       # Backend env template
├── .gitignore
└── FRONTEND_API_CONTRACT.md   # Definitive API schema
```

---

## Security Notes

- **No secrets in frontend** — Claude API key is a backend-only secret
- **No hardcoded credentials** — all sensitive values come from env vars
- **`.env` files are gitignored** — `.env.example` contains only placeholders
- **CORS** — configured per environment via `CORS_ORIGINS` env var

---

## Known Limitations (MVP)

- **Record Decision** — frontend-only simulation; no backend storage endpoint
- **Analytics / History** — UI stubs, not implemented in this MVP
- **Authentication** — demo phone + OTP bypass; no real auth in prototype
- **Database** — SQLite for demo; swap to PostgreSQL for production

---

## SIH 2026 Context

- **Problem Statement:** SIH26132
- **Theme:** Agriculture, FoodTech & Rural Development
- **Track:** Software
- **Primary User:** FPO Director / Board Secretary
- **Hackathon:** Smart India Hackathon 2026, Government of India

All buyer data, prices, and scores shown in the demo are **synthetic sample data** and do not represent any real market or individual.

---

## License

Prototype submitted for Smart India Hackathon 2026. Not for production use.
