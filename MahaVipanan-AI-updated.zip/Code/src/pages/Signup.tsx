import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, ShieldCheck, TrendingUp, Tractor, Building2, Landmark, Briefcase } from 'lucide-react'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { ThemeToggle } from '@/components/ui/ThemeToggle'
import { api } from '@/api/client'
import type { UserRole } from '@/state/AppContext'
import { useI18n } from '@/lib/i18n'

export function SignupPage() {
  const navigate = useNavigate()
  const { t } = useI18n()

  const ROLES = [
    { id: 'fpo', label: t('role.fpo'), icon: Building2, desc: t('auth.roleDesc.fpo') },
    { id: 'farmer', label: t('role.farmer'), icon: Tractor, desc: t('auth.roleDesc.farmer') },
    { id: 'buyer', label: t('role.buyer'), icon: Briefcase, desc: t('auth.roleDesc.buyer') },
    { id: 'government', label: t('role.government'), icon: Landmark, desc: t('auth.roleDesc.government') },
    { id: 'admin', label: t('role.admin'), icon: ShieldCheck, desc: t('auth.roleDesc.admin') },
  ] as const
  
  const [name, setName] = useState('')
  const [phoneOrEmail, setPhoneOrEmail] = useState('')
  const [password, setPassword] = useState('')
  const [selectedRole, setSelectedRole] = useState<UserRole>('fpo')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)
    
    const isEmail = phoneOrEmail.includes('@')
    const payload = {
      name,
      email: isEmail ? phoneOrEmail : undefined,
      phone: !isEmail ? phoneOrEmail : undefined,
      password,
      role: selectedRole
    }
    
    try {
      const res = await api.signup(payload)
      if (res.success) {
        // Redirect to login upon successful signup
        navigate('/login', { replace: true })
      } else {
        setError(res.error || t('auth.error.failedSignup'))
      }
    } catch (err: any) {
      setError(err.message || t('auth.error.registration'))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* thesis panel */}
      <div className="relative hidden overflow-hidden bg-[#1A2419] lg:block">
        <div className="absolute inset-0 bg-field-mesh opacity-40" />
        <div className="absolute -right-24 top-1/3 h-96 w-96 rounded-full bg-pine-500/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo size={44} className="[&_span]:text-white [&_.text-ink]:text-white [&_.text-ink-3]:text-white/60" />
          <div>
            <p className="eyebrow text-pine-300">{t('auth.signupThesis.eyebrow')}</p>
            <h1 className="mt-3 max-w-md font-display text-4xl font-bold leading-tight text-white">
              {t('auth.signupThesis.title')}
            </h1>
            <p className="mt-4 max-w-md text-lg leading-relaxed text-white/70">
              {t('auth.signupThesis.subtitle')}
            </p>
            <div className="mt-8 space-y-3">
              <Proof icon={TrendingUp} text={t('auth.thesis.proof1')} />
              <Proof icon={ShieldCheck} text={t('auth.thesis.proof2')} />
            </div>
          </div>
          <p className="text-xs text-white/40">{t('auth.thesis.footer')}</p>
        </div>
      </div>

      {/* sign-up */}
      <div className="relative flex justify-center p-6 sm:p-10">
        <div className="absolute top-6 right-6">
          <ThemeToggle />
        </div>
        <div className="w-full max-w-md pt-8 pb-12">
          <div className="mb-8 lg:hidden">
            <Logo size={40} />
          </div>
          <div className="mb-2 flex items-center gap-2">
            <h2 className="font-display text-3xl font-bold text-ink">{t('auth.createAccount')}</h2>
          </div>
          <p className="mb-6 text-sm text-ink-2">
            {t('auth.selectRole')}
          </p>

          <form onSubmit={submit} className="space-y-6">
            <div className="grid grid-cols-2 gap-3">
              {ROLES.map(role => (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => setSelectedRole(role.id as UserRole)}
                  className={`flex flex-col text-left items-start p-3 rounded-xl border transition-all ${
                    selectedRole === role.id 
                      ? 'border-pine-500 bg-pine-600/10 ring-1 ring-pine-500/50 shadow-sm'
                      : 'border-line bg-surface hover:border-pine-300 hover:bg-pine-600/5'
                  }`}
                >
                  <role.icon size={20} className={selectedRole === role.id ? 'text-pine-600 mb-2' : 'text-ink-3 mb-2'} />
                  <span className={`font-semibold text-sm ${selectedRole === role.id ? 'text-pine-600' : 'text-ink'}`}>
                    {role.label}
                  </span>
                  <span className="text-[10px] text-ink-3 mt-1 leading-tight">{role.desc}</span>
                </button>
              ))}
            </div>

            <div className="space-y-4 pt-4 border-t border-line">
              <Field
                label={t('auth.fullName')}
                value={name}
                onChange={(e) => setName(e.target.value)}
                inputMode="text"
                autoComplete="name"
                required
              />
              <Field
                label={t('auth.emailOrPhone')}
                value={phoneOrEmail}
                onChange={(e) => setPhoneOrEmail(e.target.value)}
                inputMode="text"
                autoComplete="username"
                required
              />
              <Field
                label={t('auth.password')}
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                required
              />
              
              {error && (
                <div className="p-3 text-sm rounded-lg bg-red-600/10 text-red-600 border border-red-600/20">
                  {error}
                </div>
              )}

              <Button 
                type="submit" 
                size="lg" 
                disabled={isLoading}
                className="w-full bg-pine-600 hover:bg-pine-700 shadow-glow-pine"
              >
                {isLoading ? t('auth.creatingAccount') : t('common.signUp')} <ArrowRight size={17} className="ml-2" />
              </Button>
            </div>
          </form>

          <p className="mt-8 text-center text-sm text-ink-3">
            {t('auth.alreadyHaveAccount')}{' '}
            <Link to="/login" className="text-pine-600 font-medium hover:underline">
              {t('common.signIn')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}

function Proof({ icon: Icon, text }: { icon: typeof TrendingUp; text: string }) {
  return (
    <div className="flex items-center gap-3 text-white/80">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/10 text-pine-300 ring-1 ring-inset ring-white/10">
        <Icon size={17} />
      </span>
      <span className="text-sm">{text}</span>
    </div>
  )
}
